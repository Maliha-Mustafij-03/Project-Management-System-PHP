<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

$sql = "SELECT * FROM emp_training_total_participent ";
    $query = $dbh->prepare($sql);
    $query->execute();
$data = $query->fetchAll(PDO::FETCH_ASSOC);

$sql1 = "SELECT count(title) as total_training, SUM(partcipent) as total_participent FROM emp_training_total_participent ";
    $query1 = $dbh->prepare($sql1);
    $query1->execute();
$data1 = $query1->fetch(PDO::FETCH_ASSOC);

$en_to_bn_digits = array (
    0 => '০',
    1 => '১',
    2 => '২',
    3 => '৩',
    4 => '৪',
    5 => '৫',
    6 => '৬',
    7 => '৭',
    8 => '৮',
    9 => '৯',
);

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    
    <link rel="stylesheet" type="text/css" href="datatable/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/dataTables.bootstrap.min.css" />

    <style>
        /* Global Styles */
        
        h1 {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            background-color: #007bff;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            position: relative;
            top: 0;
        }
        .marquee-container {
            background: linear-gradient(45deg, #1e3c72, #2a5298); /* Gradient background */
            padding: 10px 10px 10px 10px;
            font-weight: bold;
            font-size: 22px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);  /* Soft shadow for depth */
            margin-bottom: 15px;
            overflow: hidden;  /* Hide overflow for clean scroll effect */
            color: yellow;
            text-align: left;
        }

        .marquee-container a{
            color: yellow;
            float: right;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Training Module</h1>
        <!-- <a href="http://172.16.243.112/asset/auth/login" class="pull-right blinking-link package-overview">Asset Module</a> -->
        <div class="marquee-container">
            <p><?= 'সর্বমোট '.strtr($data1['total_training'],$en_to_bn_digits).' টি ট্রেনিং এ '.strtr($data1['total_participent'],$en_to_bn_digits).' জন জনবলকে প্রশিক্ষণ প্রদান করা হয়েছে।' ?>
                <a target="_blank" href="viewtraining.php">প্রশিক্ষণার্থী তালিকা</a>
            </p>
        </div>

        <!-- Assets Table -->
        <div class="table-responsive">
            
            <table class="table table-bordered table-striped" id="userTable">
            <thead>
              <tr>
                <th>No.</th>
                <th>Type</th>
                <th>Title</th>
                <th>Total Participent</th>
                <th>From Date</th>
                <th>To Date</th>
                <!-- <th>Duration</th> -->
                <th>Venue</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if($data): ?>
                <?php foreach($data as $key => $value): 
                    $bday = new DateTime($value['duration_from']); 
                    $today = new Datetime($value['duration_to']);
                    $diff = $today->diff($bday);
                    //$diff = $diff->d;
                ?>
                <tr>
                  <td><?= $key+1 ?></td>
                  <td><?= $value['type_name'] ?></td>
                  <td><?= $value['title_name'] ?></td>
                  <td><?= $value['partcipent'] ?></td>
                  <td><?= $value['duration_from'] ?></td>
                  <td><?= $value['duration_to'] ?></td>
                  <!-- <td><i><?//= $diff->d.' days' ?></i></td> -->
                  <td><?= $value['venue_name'] ?></td>
                  <td>Complete</td>
                </tr>
                <?php endforeach ?>
                <?php endif; ?>
              </tbody>
            </table>
        </div>
    </div>
</body>
    <script src="datatable/js/dataTables.bootstrap.min.js"></script>
    <script src="datatable/js/jquery.dataTables.min.js"></script>
    <script src="datatable/js/dataTables.buttons.min.js"></script>
    <script src="datatable/js/jszip.min.js"></script>
    <script src="datatable/js/buttons.html5.min.js"></script>
    <script src="datatable/js/buttons.print.min.js"></script>
</html>

<script type="text/javascript">

$(document).ready(function(){

    $('#userTable').DataTable({
        dom: 'lBfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'print'
        ]
    });

});



</script>
