<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Handle form submission for editing news
if (isset($_POST['update'])) {
    $newsId = $_POST['news_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    
    $sql = "UPDATE urgent_news SET title=:title, description=:description WHERE id=:newsId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':title', $title, PDO::PARAM_STR);
    $query->bindParam(':description', $description, PDO::PARAM_STR);
    $query->bindParam(':newsId', $newsId, PDO::PARAM_INT);
    $query->execute();
    
    echo "<script>alert('News updated successfully'); window.location.href='news-details.php?id=".$newsId."';</script>";
}

// Handle deletion of news
if (isset($_POST['delete'])) {
    $newsId = $_POST['news_id'];
    
    $sql = "DELETE FROM urgent_news WHERE id=:newsId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':newsId', $newsId, PDO::PARAM_INT);
    $query->execute();
    
    echo "<script>alert('News deleted successfully'); window.location.href='index.php';</script>";
}

// Fetch the news item
if (isset($_GET['id'])) {
    $newsId = $_GET['id'];
    $sql = "SELECT id, title, description FROM urgent_news WHERE id=:newsId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':newsId', $newsId, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_OBJ);
} else {
    echo "<script>alert('No news ID provided'); window.location.href='index.php';</script>";
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>News Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    
 
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }

        .news-details {
            padding: 50px;
            background-color: #f9f9f9;
            margin: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .news-details h2 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .news-details p {
            font-size: 24px;
            line-height: 1.5;
        }

        .news-details .form-group {
            margin-bottom: 20px;
        }

        .news-details input, .news-details textarea {
            width: 100%;
            padding: 10px;
            font-size: 18px;
        }

        .news-details button, .news-details a.btn {
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            display: inline-block;
            text-align: center;
            border: none;
            border-radius: 5px;
        }

        .news-details .update-btn {
            background-color: #007bff;
            color: #fff;
            margin-right: 10px;
        }

        .news-details .update-btn:hover {
            background-color: #0056b3;
        }

        .news-details .delete-btn {
            background-color: #dc3545;
            color: #fff;
        }

        .news-details .delete-btn:hover {
            background-color: #c82333;
        }

        .news-details .cancel-btn {
            background-color: #6c757d;
            color: #fff;
        }

        .news-details .cancel-btn:hover {
            background-color: #5a6268;
        }
    </style>
    <script>
        $(document).ready(function() {
            $('#editForm').hide();
            
            $('#editButton').click(function() {
                $('#editForm').toggle();
                $('#viewDetails').toggle();
            });

            $('#cancelButton').click(function() {
                $('#editForm').hide();
                $('#viewDetails').show();
            });
        });
    </script>
</head>
<body>
    <?php include('includes/header.php');?>

    
<div class="container">
    <div class="news-details">
        <div id="viewDetails">
            <h2><?php echo htmlentities($result->title); ?></h2>
            <p><?php echo htmlentities($result->description); ?></p>
             <!--<button id="editButton" class="update-btn">Edit</button>-->
        </div>
        <!--
        
        <div id="editForm">
            <form method="POST" action="">
                <input type="hidden" name="news_id" value="<?php echo htmlentities($result->id); ?>">
                <input type="text" name="title" value="<?php echo htmlentities($result->title); ?>">
                <textarea name="description"><?php echo htmlentities($result->description); ?></textarea>
                <button type="submit" name="update" class="update-btn">Update</button>
                <button type="submit" name="delete" class="delete-btn">Delete</button>
                <button type="button" id="cancelButton" class="cancel-btn">Cancel</button>
            </form>
        </div>
    </div>
</div>
-->


    <?php include('includes/footer.php');?>

    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
