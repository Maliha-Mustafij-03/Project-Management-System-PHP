<?php
session_start();
include('includes/config.php');

// Initialize variables to avoid notices
$error = "";
$msg = "";
$searchQuery = "";
$filter = "today"; // Default to "Today" if no filter is applied

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit;
}

// Handle radio button filter
if (isset($_POST['filter'])) {
    $filter = $_POST['filter'];
}

// Handle search query safely
if (isset($_POST['search_query'])) {
    $searchQuery = $_POST['search_query'];
}

// Build SQL query based on filter (today's reports or all reports)
if ($filter == "today") {
    $sql = "SELECT * FROM hr_reports WHERE 
            (report_date LIKE :searchQuery OR 
            department LIKE :searchQuery OR 
            title LIKE :searchQuery OR 
            description LIKE :searchQuery) 
            AND DATE(created_at) = CURDATE() 
            ORDER BY report_date DESC"; // Sort by report_date in descending order
} else {
    $sql = "SELECT * FROM hr_reports WHERE 
            report_date LIKE :searchQuery OR 
            department LIKE :searchQuery OR 
            title LIKE :searchQuery OR 
            description LIKE :searchQuery
            ORDER BY report_date DESC"; // Sort by report_date in descending order
}

$query = $dbh->prepare($sql);
$query->bindValue(':searchQuery', '%' . $searchQuery . '%', PDO::PARAM_STR);
$query->execute();
$reports = $query->fetchAll(PDO::FETCH_ASSOC);

// Fetch today's reports (for marquee) sorted by created_at descending
$todayReports = [];
$todaySql = "SELECT title FROM hr_reports WHERE DATE(created_at) = CURDATE() ORDER BY created_at DESC";
$todayQuery = $dbh->prepare($todaySql);
$todayQuery->execute();
$todayReports = $todayQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HR Reports</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type="text/css" />
    
    <style>
        /* New modern and vibrant Marquee Design */
        .marquee-container {
            background: linear-gradient(45deg, #1e3c72, #2a5298); /* Gradient background */
            padding: 5px 0;  /* Padding for top/bottom */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);  /* Soft shadow for depth */
            border-radius: 15px;  /* Rounded corners for a smooth look */
            margin-bottom: 20px;
            overflow: hidden;  /* Hide overflow for clean scroll effect */
        }

        .marquee {
            font-family: 'Roboto', sans-serif;  /* Clean, modern font */
            font-size: 36px;  /* Large font size for readability */
            font-weight: 700;  /* Bold text for emphasis */
            color: #f9f9f9;  /* Light text color for contrast */
            text-shadow: 3px 3px 8px rgba(0, 0, 0, 0.7); /* Text shadow for depth */
            line-height: 1.8;  /* Line height for easy reading */
            white-space: nowrap;
            display: inline-block;
            animation: marquee 50s linear infinite;  /* Slow scrolling animation */
            overflow: hidden; /* Hide overflow */
            position: relative;
            visibility: hidden; /* Initially hidden */
        }

        @keyframes marquee {
            0% {
                transform: translateX(100%);  /* Start from the right */
            }
            100% {
                transform: translateX(-100%); /* Move all the way to the left */
            }
        }

        /* Marquee Wrapper */
        .marquee-wrapper {
            position: relative;
            width: 100%;
            height: 80px;  /* Set height for the marquee container */
        }

        .marquee-wrapper .marquee-content {
            display: flex;
            align-items: center;
        }

        .marquee-wrapper .marquee-content span {
            margin-right: 50px;  /* Space between the items */
        }

        /* Styling for the links inside the marquee */
        .marquee a {
            text-decoration: none;
            color: #ffbc00;  /* Gold color for the links */
            font-weight: bold;
            transition: color 0.3s ease, transform 0.3s ease;  /* Smooth transition */
        }

        .marquee a:hover {
            color: white;  /* Light blue on hover */
            text-decoration: underline;
            transform: scale(1.1);  /* Slight zoom on hover for emphasis */
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .marquee {
                font-size: 30px;  /* Slightly smaller text on mobile */
            }
        }

        /* Styling for the search and filter options */
        .radio-buttons {
            margin-bottom: 20px;
        }

        .radio-buttons label {
            font-weight: 600;
            color: #333;
            margin-right: 15px;
        }
    </style>
</head>

<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="main.php">হোম</a><i class="fa fa-angle-right"></i>এইচআর রিপোর্ট</li>
        </ol>

        <!-- New Fresh Marquee Section for Today's Reports -->
        <div class="container marquee-container">
            <div class="marquee-wrapper">
                <div class="marquee" id="marquee">
                    <?php
                    $totalReports = count($todayReports);
                    foreach ($todayReports as $index => $report) {
                        echo "<span><a href='#'>" . htmlentities($report['title']) . "</a></span>";
                        if ($index < $totalReports - 1) {
                            // Add a small logo after each line except the last one
                            echo " <img src='ECS.png' alt='ECS Logo' style='width: 20px; height: 20px; margin: 0 10px; vertical-align: middle;'> ";
                        }
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Radio Buttons for Filtering -->
        <div class="container radio-buttons">
            <form method="POST">
                <label><input type="radio" name="filter" value="today" <?php echo ($filter == 'today') ? 'checked' : ''; ?>> Today's Reports</label>
                <label><input type="radio" name="filter" value="all" <?php echo ($filter == 'all') ? 'checked' : ''; ?>> All Reports</label>
                <button type="submit" name="search" class="btn btn-primary">Filter</button>
            </form>
        </div>

        <!-- Search Form -->
        <div class="container search-form">
            <form method="POST">
                <div class="form-group">
                    <label for="search_query">রিপোর্ট অনুসন্ধান করুন</label>
                    <input type="text" id="search_query" name="search_query" class="form-control" value="<?php echo htmlentities($searchQuery); ?>" placeholder="রিপোর্টের তারিখ, বিভাগ, মীটিং এর শিরোনাম, মীটিং এর বর্ণনা দিয়ে অনুসন্ধান করুন" required>
                </div>
                <button type="submit" name="search" class="btn btn-primary">অনুসন্ধান</button>
            </form>
        </div>

        <!-- Results Section -->
        <div class="container">
            <h2>এইচআর রিপোর্ট</h2>
            
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>রিপোর্টের তারিখ</th>
                            <th>বিভাগ</th>
                            <th>মীটিং এর শিরোনাম</th>
                            <th>মীটিং এর বর্ণনা</th>
                            <th>সংযুক্তি(পিডিএফ)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $report) { ?>
                            <tr>
                                <td><?php echo htmlentities($report['report_date']); ?></td>
                                <td><?php echo htmlentities($report['department']); ?></td>
                                <td><?php echo htmlentities($report['title']); ?></td>
                                <td><?php echo htmlentities($report['description']); ?></td>
                                <td>
                                    <?php
                                    $attachments = explode(',', $report['attachments']);
                                    foreach ($attachments as $attachment) {
                                        if ($attachment) {
                                            // Prepend 'admin/' before the attachment link
                                            $attachmentPath = 'admin/' . $attachment;
                                            echo "<a href='$attachmentPath' target='_blank' class='btn btn-info btn-sm'>View PDF</a><br>";
                                        }
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php include('includes/footer.php'); ?>
    </div>

    <div class="clearfix"></div>

    <script>
        // Ensure marquee starts immediately on page load by using visibility instead of animation
        $(document).ready(function() {
            $('#marquee').css('visibility', 'visible');  // Make the marquee visible immediately
            $('#marquee').css('animation', 'marquee 50s linear infinite');  // Start the marquee animation
        });
    </script>

</body>
</html>
