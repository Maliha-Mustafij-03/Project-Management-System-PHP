<?php
session_start();
include('includes/config.php'); // Include the database configuration file

$errorMessage = ""; // Initialize error message variable

// Check if the form is submitted
if (isset($_POST['signup'])) {
    // Assign user input to variables
    $fname = $_POST['fname'];
    $mnumber = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); // Ensure to hash the password
    $usertype = $_POST['usertype']; // Capture the selected user type

    // Prepare the SQL query with placeholders
    $sql = "INSERT INTO tblusers (FullName, MobileNumber, EmailId, Password, UserType) VALUES (:fname, :mnumber, :email, :password, :usertype)";
    
    // Prepare the query using PDO
    $query = $dbh->prepare($sql);

    // Bind parameters
    $query->bindParam(':fname', $fname, PDO::PARAM_STR);
    $query->bindParam(':mnumber', $mnumber, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->bindParam(':usertype', $usertype, PDO::PARAM_STR); // Bind the user type

    // Execute the query
    $query->execute();

    // Get the last inserted ID to confirm success
    $lastInsertId = $dbh->lastInsertId();

    // Check if insertion was successful
    if ($lastInsertId) {
        $_SESSION['msg'] = "You have successfully registered. Now you can log in.";
        header('location:admin/dashboard.php');
        exit;
    } else {
        $_SESSION['msg'] = "Something went wrong. Please try again.";
        header('location:thankyou.php');
        exit;
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | NCS/GD</title>
    <style>
        /* Styling for the sign-up page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Main wrapper */
        .main-wthree {
            background: url('images/bluesky.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Container for the registration form */
        .container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Form styling */
        .sin-w3-agile {
            padding: 40px;
            text-align: center;
        }

        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        .username, .mobilenumber, .email, .password-agileits, .user-type {
            margin-bottom: 20px;
        }

        .username span, .mobilenumber span, .email span, .password-agileits span, .user-type span {
            display: block;
            text-align: left;
            font-size: 14px;
            margin-bottom: 5px;
        }

        /* Add red star for required fields */
        .required:after {
            content: " *";
            color: red;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="tel"], select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }

        /* Submit button styling */
        .register-w3 input[type="submit"] {
            width: 100%;
            background-color: #5cb85c;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }

        .register-w3 input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        .back {
            margin-top: 20px;
        }

        .back a {
            color: #337ab7;
            font-size: 14px;
            text-decoration: none;
        }

        .back a:hover {
            text-decoration: underline;
        }

        div[style="color: red; margin-top: 10px;"] {
            font-size: 14px;
            color: red;
        }
    </style>
</head>
<body>
    <div class="main-wthree">
        <div class="container">
            <div class="sin-w3-agile">
                <h2>Register</h2>
                <form method="post">
                    <div class="username">
                        <span class="username required">Full Name:</span>
                        <input type="text" name="fname" class="name" required="true" placeholder="Enter your full name">
                    </div>

                    <div class="mobilenumber">
                        <span class="mobilenumber required">Mobile Number:</span>
                        <input type="tel" name="mobilenumber" class="mobilenumber" required="true" placeholder="Enter your mobile number">
                    </div>

                    <div class="email">
                        <span class="email required">Email:</span>
                        <input type="email" name="email" class="email" required="true" placeholder="Enter your email">
                    </div>

                    <div class="user-type">
                        <span class="user-type required">User Type:</span>
                        <select name="usertype" required="true">
                            <option value="">Select User Type</option>
                            <option value="Procurement">Procurement</option>
                            <option value="Communication">Communication</option>
                            <option value="Smartcard Expatriate">Smartcard Expatriate</option>
                            <option value="Smartcard Statistics">Smartcard Statistics</option>
                            <option value="PD Dept">PD Dept</option>
                            <option value="Finance">Finance</option>
                            <option value="HR">HR</option>
                            <option value="View">View</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>

                    <div class="password-agileits">
                        <span class="password required">Password:</span>
                        <input type="password" name="password" class="password" required="true" placeholder="Enter your password">
                    </div>

                    <div class="register-w3">
                        <input type="submit" name="signup" value="Sign Up">
                    </div>

                    <!-- Display error or success message -->
                    <?php if (isset($_SESSION['msg'])) { ?>
                        <div style="color: green; margin-top: 10px;"><?php echo $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
                    <?php } ?>
                </form>

                <!-- Back Button -->
                <div class="back">
                    <button onclick="window.history.back();" class="btn btn-secondary">Go Back</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
