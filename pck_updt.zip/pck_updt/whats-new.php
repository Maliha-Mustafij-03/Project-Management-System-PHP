<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>What's New - PD Sir's Commitment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Arial' rel='stylesheet' type='text/css'>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
        }
        .page-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar-menu {
            background: #343a40;
            color: #fff;
            padding: 10px;
            width: 250px;
            height: 100vh;
            position: fixed;
        }
        .page-content {
            margin-left: 250px; /* Adjust for sidebar width */
            padding: 20px;
            flex: 1;
        }
        .header-main {
            background-color: #343a40;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .breadcrumb {
            background-color: #e9ecef;
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .breadcrumb-item a {
            color: #343a40;
        }
        .urgent-news {
            background-color: #ffffff;
            padding: 20px;
            border-left: 5px solid #343a40;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
            border-radius: 4px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        .news-item {
            background-color: #ffffff;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            border-radius: 4px;
        }
        .news-content h5 {
            font-size: 16px;
            font-weight: bold;
            margin-top: 0;
        }
        .news-content p {
            font-size: 12px;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Sidebar -->
        <?php include('includes/sidebarmenu.php'); ?>

        <!-- Page Content -->
        <div class="page-content">
            <!-- Header -->
            <?php include('includes/header.php'); ?>

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="main.php">Home</a><i class="fa fa-angle-right"></i>PD Sir's Commitment</li>
            </ol>

            <!-- Urgent News Section -->
            <div class="urgent-news">
             PD Sir's Commitment
            </div>

            <!-- News Items -->
            <?php 
            $sql = "SELECT id, title, description FROM urgent_news ORDER BY created_at DESC";
            $query = $dbh->prepare($sql);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);
            if ($query->rowCount() > 0) {
                foreach ($results as $result) {
                    ?>
                    <div class="news-item">
                        <div class="news-content">
                            <h5><?php echo htmlentities($result->title); ?></h5>
                            <p><?php echo htmlentities($result->description); ?></p>
                        </div>
                    </div>
                    <?php 
                }
            } else {
                echo "<p>No urgent news available.</p>";
            }
            ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>

    <!-- JavaScript -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
