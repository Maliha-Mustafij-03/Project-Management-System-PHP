<?php
session_start();
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}


// Check if form is submitted for creating a new package
if (isset($_POST['create'])) {
    $Source_of_fund = $_POST['Source_of_fund'];
    $Total_Cost = $_POST['Total_Cost'];
    $Cumulative_Cost = $_POST['Cumulative_Cost'];
    $Last_date_of_Cumulative_Cost = $_POST['Last_date_of_Cumulative_Cost'];
    $Cumulative_Cost_percentage = $_POST['Cumulative_Cost_percentage'];
    $Annual_dpp_budget = $_POST['Annual_dpp_budget'];
    $Financial_year = $_POST['Financial_year'];
    $Current_fy_progress = $_POST['Current_fy_progress'];
    $Last_date_of_fy_cost = $_POST['Last_date_of_fy_cost'];
    $current_fy_progress_per = $_POST['current_fy_progress_per'];
    


    // Insert new package information into the database
    echo $sql = "INSERT INTO financial_progress (Source_of_fund, Total_Cost, Cumulative_Cost, Last_date_of_Cumulative_Cost, Cumulative_Cost_percentage, Annual_dpp_budget, Financial_year, Current_fy_progress, Last_date_of_fy_cost, current_fy_progress_per) VALUES (:Source_of_fund, :Total_Cost, :Cumulative_Cost, :Last_date_of_Cumulative_Cost, :Cumulative_Cost_percentage, :Annual_dpp_budget, :Financial_year, :Current_fy_progress, :Last_date_of_fy_cost, :current_fy_progress_per)";

    $query = $dbh->prepare($sql);
    $query->bindParam(':Source_of_fund', $Source_of_fund, PDO::PARAM_STR);
    $query->bindParam(':Total_Cost', $Total_Cost, PDO::PARAM_STR);
    $query->bindParam(':Cumulative_Cost', $Cumulative_Cost, PDO::PARAM_STR);
    $query->bindParam(':Last_date_of_Cumulative_Cost', $Last_date_of_Cumulative_Cost, PDO::PARAM_STR);
    $query->bindParam(':Cumulative_Cost_percentage', $Cumulative_Cost_percentage, PDO::PARAM_STR);
    $query->bindParam(':Annual_dpp_budget', $Annual_dpp_budget, PDO::PARAM_STR);
    $query->bindParam(':Financial_year', $Financial_year, PDO::PARAM_STR);
    $query->bindParam(':Current_fy_progress', $Current_fy_progress, PDO::PARAM_STR);
    $query->bindParam(':Last_date_of_fy_cost', $Last_date_of_fy_cost, PDO::PARAM_STR);
    $query->bindParam(':current_fy_progress_per', $current_fy_progress_per, PDO::PARAM_STR);

    if ($query->execute()) {
        $msg = "Data Created Successfully";
        header("Location:Report.php");
    } else {
        $error = "Something went wrong. Please try again";
        header("Location: MonitoringAndEvaluation.php");
    }
}
?>
