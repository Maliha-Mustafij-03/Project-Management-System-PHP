<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Delete functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tblsmartcards WHERE id = :delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    $msg = "Smartcard Deleted Successfully";
}

// Pagination setup
$limit = 10; // Records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page
$start_from = ($page - 1) * $limit; // Starting record for the query

// Search functionality
$search = "";
if (isset($_POST['search'])) {
    $search = $_POST['search_query'];
    // Search query across all columns
    $sql = "SELECT * FROM tblsmartcards WHERE 
                ক্রম_নং LIKE :search_query OR 
                নাম LIKE :search_query OR 
                মোট_আবেদন LIKE :search_query OR 
                মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ LIKE :search_query OR 
                তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন LIKE :search_query OR 
                তদন্ত_সম্পন্ন_এপ্রুভ LIKE :search_query OR 
                বাতিল LIKE :search_query OR 
                মোট LIKE :search_query OR 
                উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন LIKE :search_query OR 
                মিশন_থেকে_আপলোড_অপেক্ষাধীন LIKE :search_query OR 
                আপলোড LIKE :search_query OR 
                প্রিন্ট_করার_উপযোগী LIKE :search_query OR 
                প্রিন্টেড LIKE :search_query OR 
                তারিখ LIKE :search_query LIMIT :start_from, :limit";
    $query = $dbh->prepare($sql);
    $query->bindValue(':search_query', '%' . $search . '%');
    $query->bindValue(':start_from', $start_from, PDO::PARAM_INT);
    $query->bindValue(':limit', $limit, PDO::PARAM_INT);
    $query->execute();
} else {
    // Fetch all smartcards from the database if no search is done
    $sql = "SELECT * FROM tblsmartcards LIMIT :start_from, :limit";
    $query = $dbh->prepare($sql);
    $query->bindValue(':start_from', $start_from, PDO::PARAM_INT);
    $query->bindValue(':limit', $limit, PDO::PARAM_INT);
    $query->execute();
}

$smartcards = $query->fetchAll(PDO::FETCH_ASSOC);

// Get total records for pagination
if (empty($search)) {
    $sql_count = "SELECT COUNT(*) FROM tblsmartcards";
    $query_count = $dbh->prepare($sql_count);
    $query_count->execute();
    $total_records = $query_count->fetchColumn();
} else {
    $sql_count = "SELECT COUNT(*) FROM tblsmartcards WHERE 
                    ক্রম_নং LIKE :search_query OR 
                    নাম LIKE :search_query OR 
                    মোট_আবেদন LIKE :search_query OR 
                    মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ LIKE :search_query OR 
                    তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন LIKE :search_query OR 
                    তদন্ত_সম্পন্ন_এপ্রুভ LIKE :search_query OR 
                    বাতিল LIKE :search_query OR 
                    মোট LIKE :search_query OR 
                    উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন LIKE :search_query OR 
                    মিশন_থেকে_আপলোড_অপেক্ষাধীন LIKE :search_query OR 
                    আপলোড LIKE :search_query OR 
                    প্রিন্ট_করার_উপযোগী LIKE :search_query OR 
                    প্রিন্টেড LIKE :search_query OR 
                    তারিখ LIKE :search_query";
    $query_count = $dbh->prepare($sql_count);
    $query_count->bindValue(':search_query', '%' . $search . '%');
    $query_count->execute();
    $total_records = $query_count->fetchColumn();
}

// Calculate total pages
$total_pages = ceil($total_records / $limit);

// Pagination controls
$pagination = "";
if ($total_pages > 1) {
    if ($page > 1) {
        $pagination .= '<a href="manage-smartcards.php?page=' . ($page - 1) . '" class="btn btn-primary">Previous</a> ';
    }
    for ($i = 1; $i <= $total_pages; $i++) {
        if ($i == $page) {
            $pagination .= '<span class="btn btn-secondary">' . $i . '</span> ';
        } else {
            $pagination .= '<a href="manageprobas.php?page=' . $i . '" class="btn btn-primary">' . $i . '</a> ';
        }
    }
    if ($page < $total_pages) {
        $pagination .= '<a href="manageprobas.php?page=' . ($page + 1) . '" class="btn btn-primary">Next</a>';
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS-GD | Manage Smartcards</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-size: 18px;
        }
        .container {
            padding-top: 60px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */

        .table th, .table td {
            font-size: 16px;
        }

        .table th {
            background-color: #f8f9fa;
            text-align: center;
        }

        .table td {
            text-align: center;
        }

        .search-bar {
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
        }

        .alert {
            text-align: center;
            font-size: 18px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
        }

        .pagination-container {
            text-align: center;
            margin-top: 20px;
        }

        .pagination-container a, .pagination-container span {
            margin: 0 5px;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
        }

        .pagination-container .active {
            background-color: #555;
        }

        /* For Scrollable Table */
        .table-responsive {
            max-height: calc(100vh - 250px); /* Full height minus space for header and search */
            overflow-y: auto;
        }

        .container {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .pagination-container {
            margin-top: auto;
        }

    </style>
</head>
<body>
    

    <div class="container">
        <?php include('includes/header.php'); ?>
    <?php include('includes/sidebarmenu.php'); ?>
        <h1>Manage Smartcards</h1>
        
        <!-- Search Form -->
        <div class="search-bar">
            <form method="POST" class="form-inline">
                <input type="text" name="search_query" class="form-control" value="<?php echo htmlentities($search); ?>" placeholder="Search by any data">
                <button type="submit" name="search" class="btn btn-primary ml-2 btn-custom">Search</button>
            </form>
        </div>

        <?php if(isset($msg)) { ?>
            <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
        <?php } ?>

        <!-- Smartcards Table with Scroll -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        
                        <th>নাম</th>
                        <th>মোট আবেদন</th>
                        <th>মিশন অফিসে বায়োমেট্রিক গ্রহণ</th>
                        <th>তদন্ত সম্পন্ন,এপ্রুভ এর অপেক্ষাধীন</th>
                        <th>তদন্ত সম্পন্ন,এপ্রুভ</th>
                        <th>বাতিল</th>
                        <th>মোট</th>
                        <th>উপজেলা/থানা নির্বাচন অফিস কর্তৃক তদন্ত প্রক্রিয়াধীন</th>
                        <th>মিশন থেকে আপলোড অপেক্ষাধীন</th>
                        <th>আপলোড</th>
                        <th>প্রিন্ট করার উপযোগী</th>
                        <th>প্রিন্টেড</th>
                        <th>তারিখ</th>
                        <th>অপশন</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($smartcards as $smartcard) { ?>
                        <tr>
                            
                            <td><?php echo htmlentities($smartcard['নাম']); ?></td>
                            <td><?php echo htmlentities($smartcard['মোট_আবেদন']); ?></td>
                            <td><?php echo htmlentities($smartcard['মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ']); ?></td>
                            <td><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ']); ?></td>
                            <td><?php echo htmlentities($smartcard['বাতিল']); ?></td>
                            <td><?php echo htmlentities($smartcard['মোট']); ?></td>
                            <td><?php echo htmlentities($smartcard['উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['মিশন_থেকে_আপলোড_অপেক্ষাধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['আপলোড']); ?></td>
                            <td><?php echo htmlentities($smartcard['প্রিন্ট_করার_উপযোগী']); ?></td>
                            <td><?php echo htmlentities($smartcard['প্রিন্টেড']); ?></td>
                            <td><?php echo htmlentities($smartcard['তারিখ']); ?></td>
                            <td class="action-buttons">
                                <a href="editprobas.php?id=<?php echo $smartcard['id']; ?>" class="btn btn-warning btn-sm btn-custom">এডিট</a>
                                <?php if(strlen($_SESSION['alogin']) != 0) { ?>
                                    <a href="?delete_id=<?php echo $smartcard['id']; ?>" class="btn btn-danger btn-sm btn-custom" onclick="return confirm('Are you sure you want to delete this?')">মুছুন</a>
                                </td>
                            <?php } ?>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination Controls -->
        <div class="pagination-container">
            <?php echo $pagination; ?>
        </div>

    </div>
</body>
</html>
