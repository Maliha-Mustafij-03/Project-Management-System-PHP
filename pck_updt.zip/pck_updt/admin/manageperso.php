<?php 
session_start(); 
error_reporting(0); 
include('includes/config.php'); 
include('includes/sidebarmenu.php'); 

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {     
    header('location:index.php');     
    exit; 
}

// Handle record deletion
if (isset($_GET['delete'])) {     
    $id = $_GET['delete']; 

    // Delete the details for the parent record and its associated data
    $sqlDeleteDetails = "DELETE FROM smart_nid_print_more_details WHERE parent_id = :parent_id";     
    $queryDeleteDetails = $dbh->prepare($sqlDeleteDetails);     
    $queryDeleteDetails->bindParam(':parent_id', $id, PDO::PARAM_INT);     
    $queryDeleteDetails->execute(); 

    $sqlDeleteSubCategory = "DELETE FROM smart_nid_print_details WHERE parent_id = :parent_id";     
    $queryDeleteSubCategory = $dbh->prepare($sqlDeleteSubCategory);     
    $queryDeleteSubCategory->bindParam(':parent_id', $id, PDO::PARAM_INT);     
    $queryDeleteSubCategory->execute(); 

    $sqlDeleteParent = "DELETE FROM smart_nid_print_distribution WHERE id = :id";     
    $queryDeleteParent = $dbh->prepare($sqlDeleteParent);     
    $queryDeleteParent->bindParam(':id', $id, PDO::PARAM_INT);     
    $queryDeleteParent->execute(); 

    $msg = "Record Deleted Successfully"; 
}

// Search functionality
$search = ""; 
if (isset($_POST['search'])) {     
    $search = $_POST['search']; 
}

// Fetch records from smart_nid_print_distribution table, including search filter
$sql = "SELECT * FROM smart_nid_print_distribution 
        WHERE category LIKE :search 
        OR id LIKE :search 
        OR EXISTS (
            SELECT 1 
            FROM smart_nid_print_details 
            WHERE parent_id = smart_nid_print_distribution.id 
            AND sub_category LIKE :search
        )
        OR EXISTS (
            SELECT 1 
            FROM smart_nid_print_more_details 
            WHERE parent_id IN (SELECT id FROM smart_nid_print_details WHERE parent_id = smart_nid_print_distribution.id) 
            AND additional_info LIKE :search
        )
        ORDER BY id DESC";

$query = $dbh->prepare($sql); 
$query->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR); 
$query->execute(); 
$results = $query->fetchAll(PDO::FETCH_ASSOC); 
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ ম্যানেজমেন্ট</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <style>
        /* Page container to allow scrolling of content */
        .page-container {
            display: flex;
            height: 100vh; /* Full height of the viewport */
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #f8f9fa;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            padding-top: 60px; /* To make space for the header */
        }

        /* Main content area */
        .main-content {
            margin-left: 250px; /* Push the content right to make space for the sidebar */
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto; /* Allow scrolling in the content area */
        }

        .mother-grid-inner {
            margin: 0 auto;
            width: 100%;
        }

        /* Scrollbar customization */
        .main-content {
            height: calc(100vh - 60px); /* Deduct header height */
            overflow-y: auto;
        }

        /* Ensuring table text is large enough and well formatted */
        body {
            font-size: 18px;
        }

        .table th, .table td {
            font-size: 16px;
            text-align: center;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .table td {
            text-align: center;
        }

        .search-bar {
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
        }

        .alert {
            text-align: center;
            font-size: 18px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
        }
    </style>

    <script>
        $(document).ready(function() {
            // Initialize niceScroll
            $(".main-content").niceScroll({
                cursorcolor: "#ccc",
                cursorwidth: "8px",
                cursorborder: "none",
                cursorborderradius: "5px",
            });
        });
    </script>
</head>
<body>

<div class="page-container">
    <!-- Sidebar -->
    <div class="sidebar">
        <?php include('includes/sidebarmenu.php'); ?>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <div class="mother-grid-inner">
            <?php include('includes/header.php'); ?>
            <div class="clearfix"></div>
        </div>

        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</li>
        </ol>

        <div class="grid-form">
            <div class="grid-form1">
                <h3>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</h3>

                <!-- Search Form -->
                <form method="post" class="form-inline">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control" placeholder="তথ্য দিয়ে অনুসন্ধান করুন" value="<?php echo htmlentities($search); ?>" />
                    </div>
                    <button type="submit" class="btn btn-info">অনুসন্ধান</button>
                </form>

                <?php if ($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?></div>
                <?php } ?>

                <table class="table">
                    <thead>
                        <tr>
                            <th>বিবরণ</th>
                            <th>সাব ক্যাটাগরি</th>
                            <th>মোট পরিমান</th>
                            <th>অ্যাকশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($results as $result) {
                            // Fetch subcategory data associated with the parent record
                            $sqlSubCategory = "SELECT * FROM smart_nid_print_details WHERE parent_id = :parent_id";
                            $querySubCategory = $dbh->prepare($sqlSubCategory);
                            $querySubCategory->bindParam(':parent_id', $result['id'], PDO::PARAM_INT);
                            $querySubCategory->execute();
                            $subCategories = $querySubCategory->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                            <tr>
                                <td><?php echo htmlentities($result['category']); ?></td>
                                <td>
                                    <?php
                                    // Display subcategories associated with the current record
                                    foreach ($subCategories as $subCategory) {
                                        echo "<p>" . htmlentities($subCategory['sub_category']) . "</p>";
                                        
                                        // Fetch and display more details (additional info, count) under each subcategory
                                        $sqlMoreDetails = "SELECT * FROM smart_nid_print_more_details WHERE parent_id = :parent_id AND sub_category = :sub_category";
                                        $queryMoreDetails = $dbh->prepare($sqlMoreDetails);
                                        $queryMoreDetails->bindParam(':parent_id', $result['id'], PDO::PARAM_INT);
                                        $queryMoreDetails->bindParam(':sub_category', $subCategory['sub_category'], PDO::PARAM_STR);
                                        $queryMoreDetails->execute();
                                        $moreDetails = $queryMoreDetails->fetchAll(PDO::FETCH_ASSOC);

                                        // Display the additional info and counts
                                        foreach ($moreDetails as $detail) {
                                            echo "<p>তথ্য: " . htmlentities($detail['additional_info']) . " | পরিমান: " . htmlentities($detail['count']) . "</p>";
                                        }
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    // Calculate and display the total count for each subcategory
                                    foreach ($subCategories as $subCategory) {
                                        $totalCount = 0;

                                        // Fetch more details to sum the count
                                        $sqlMoreDetails = "SELECT * FROM smart_nid_print_more_details WHERE parent_id = :parent_id AND sub_category = :sub_category";
                                        $queryMoreDetails = $dbh->prepare($sqlMoreDetails);
                                        $queryMoreDetails->bindParam(':parent_id', $result['id'], PDO::PARAM_INT);
                                        $queryMoreDetails->bindParam(':sub_category', $subCategory['sub_category'], PDO::PARAM_STR);
                                        $queryMoreDetails->execute();
                                        $moreDetails = $queryMoreDetails->fetchAll(PDO::FETCH_ASSOC);

                                        // Sum up the count for the subcategory
                                        foreach ($moreDetails as $detail) {
                                            $totalCount += $detail['count'];
                                        }

                                        echo "<p>মোট পরিমান: " . $totalCount . "</p>";
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="editperso.php?id=<?php echo $result['id']; ?>" class="btn btn-primary">এডিট করুন</a>
                                    <?php if (isset($_SESSION['alogin'])) { ?>
                                        <a href="?delete=<?php echo $result['id']; ?>" onclick="return confirm('Are you sure you want to delete?');" class="btn btn-danger">ডিলিট করুন</a>
                                    <?php } ?>                              
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>
