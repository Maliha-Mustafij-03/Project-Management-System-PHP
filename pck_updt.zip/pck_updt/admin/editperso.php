<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit;
}

// Fetch data for the specific record
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch parent record
    $sql = "SELECT * FROM smart_nid_print_distribution WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    $parentRecord = $query->fetch(PDO::FETCH_ASSOC);

    // Fetch associated subcategories
    $sqlSubCategory = "SELECT * FROM smart_nid_print_details WHERE parent_id = :parent_id";
    $querySubCategory = $dbh->prepare($sqlSubCategory);
    $querySubCategory->bindParam(':parent_id', $id, PDO::PARAM_INT);
    $querySubCategory->execute();
    $subCategories = $querySubCategory->fetchAll(PDO::FETCH_ASSOC);

    // Fetch associated counts and additional info
    $sqlMoreDetails = "SELECT * FROM smart_nid_print_more_details WHERE parent_id = :parent_id";
    $queryMoreDetails = $dbh->prepare($sqlMoreDetails);
    $queryMoreDetails->bindParam(':parent_id', $id, PDO::PARAM_INT);
    $queryMoreDetails->execute();
    $moreDetails = $queryMoreDetails->fetchAll(PDO::FETCH_ASSOC);
}

// Handle form submission for editing
if (isset($_POST['submit'])) {
    $category = $_POST['category'];

    // Update the parent record
    $sqlUpdateParent = "UPDATE smart_nid_print_distribution SET category = :category WHERE id = :id";
    $queryUpdateParent = $dbh->prepare($sqlUpdateParent);
    $queryUpdateParent->bindParam(':category', $category, PDO::PARAM_STR);
    $queryUpdateParent->bindParam(':id', $id, PDO::PARAM_INT);
    $queryUpdateParent->execute();

    // Update subcategories and related details
    if (isset($_POST['sub_category'])) {
        foreach ($_POST['sub_category'] as $index => $sub_category) {
            $subCategoryId = $_POST['sub_category_id'][$index];
            $sqlUpdateSubCategory = "UPDATE smart_nid_print_details SET sub_category = :sub_category WHERE id = :id";
            $queryUpdateSubCategory = $dbh->prepare($sqlUpdateSubCategory);
            $queryUpdateSubCategory->bindParam(':sub_category', $sub_category, PDO::PARAM_STR);
            $queryUpdateSubCategory->bindParam(':id', $subCategoryId, PDO::PARAM_INT);
            $queryUpdateSubCategory->execute();

            // Update additional info and count
            if (isset($_POST['count_' . $index])) {
                foreach ($_POST['count_' . $index] as $subIndex => $countSub) {
                    $additionalInfoSub = $_POST['additional_info_' . $index][$subIndex];
                    $sqlUpdateMoreDetails = "UPDATE smart_nid_print_more_details 
                                             SET count = :count, additional_info = :additional_info 
                                             WHERE parent_id = :parent_id AND sub_category = :sub_category";
                    $queryUpdateMoreDetails = $dbh->prepare($sqlUpdateMoreDetails);
                    $queryUpdateMoreDetails->bindParam(':count', $countSub, PDO::PARAM_INT);
                    $queryUpdateMoreDetails->bindParam(':additional_info', $additionalInfoSub, PDO::PARAM_STR);
                    $queryUpdateMoreDetails->bindParam(':parent_id', $id, PDO::PARAM_INT);
                    $queryUpdateMoreDetails->bindParam(':sub_category', $sub_category, PDO::PARAM_STR);
                    $queryUpdateMoreDetails->execute();
                }
            }
        }
    }

    $msg = "Data Updated Successfully";
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<title>এডিট - স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</title>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
      <style>
        /* Remove extra space above the breadcrumb */
        body, .page-container {
            margin: 0;
            padding: 0;
        }

        .mother-grid-inner {
            padding-bottom: 100px; /* Allow some space for footer */
        }

        .page-container {
            max-height: 100vh;
            overflow-y: auto;
        }

        .form-control1 {
            font-size: 16px;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .detail-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .detail-row input {
            margin-right: 10px;
        }

        .btn-container {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .btn-container button {
            margin-right: 10px;
        }

        /* Make the body scrollable */
        body {
            overflow-y: auto;
        }

        /* Ensure fixed header does not overlap */
        .header-main.fixed {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
    </style>
</head>
<body>
<div class="page-container">
    <div class="left-content">
        <div class="mother-grid-inner">
            <?php include('includes/header.php'); ?>
            <div class="clearfix"></div>
        </div>
        
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/pck_updt/main">হোম</a><i class="fa fa-angle-right"></i>এডিট স্মার্ট জাতীয় পরিচয়পত্র</li>
        </ol>

        <div class="grid-form">
            <div class="grid-form1">
                <h3>এডিট - স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</h3>
                <?php if ($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?></div>
                <?php } ?>

                <form class="form-horizontal" name="edit_smart_nid_form" method="post" enctype="multipart/form-data">
                    <!-- Category Field -->
                    <div class="form-group">
                        <label for="category" class="col-sm-2 control-label">বিবরণ</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="category" id="category" 
                                value="<?php echo htmlentities($parentRecord['category']); ?>" required>
                        </div>
                    </div>

                    <!-- Subcategory Section -->
                    <?php foreach ($subCategories as $index => $subCategory) { ?>
                        <div class="form-group">
                            <label for="sub_category" class="col-sm-2 control-label">সাব ক্যাটাগরী</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="sub_category[]" 
                                    value="<?php echo htmlentities($subCategory['sub_category']); ?>" required>
                                <input type="hidden" name="sub_category_id[]" value="<?php echo $subCategory['id']; ?>" />
                            </div>
                        </div>

                        <!-- Additional Info and Count -->
                        <?php foreach ($moreDetails as $detail) { 
                            if ($detail['sub_category'] === $subCategory['sub_category']) { ?>
                                <div class="form-group">
                                    <label for="additional_info" class="col-sm-2 control-label">বিস্তারিত তথ্য</label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" name="additional_info_<?php echo $index; ?>[]"><?php echo htmlentities($detail['additional_info']); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="count" class="col-sm-2 control-label">পরিমান</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" name="count_<?php echo $index; ?>[]" 
                                            value="<?php echo htmlentities($detail['count']); ?>" required>
                                    </div>
                                </div>
                            <?php }
                        } ?>
                    <?php } ?>

                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-2">
                            <button type="submit" name="submit" class="btn btn-primary">আপডেট</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
