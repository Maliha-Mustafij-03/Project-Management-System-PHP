<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

// Get the folder list inside 'uploads/'
$folderPath = "uploads/";
$folders = [];
$searchQuery = "";

// Check if there's a search query
if (isset($_GET['search'])) {
    $searchQuery = strtolower(trim($_GET['search']));
}

if (is_dir($folderPath)) {
    // Open the uploads directory
    $dir = opendir($folderPath);

    // Loop through the directory to find all subdirectories (folders)
    while (($folder = readdir($dir)) !== false) {
        if ($folder != '.' && $folder != '..' && is_dir($folderPath . $folder)) {
            // Add folder to the folders array
            $folders[] = $folder;
        }
    }
    closedir($dir);
}

// Filter folders based on search query
if ($searchQuery !== "") {
    $folders = array_filter($folders, function($folder) use ($searchQuery) {
        return strpos(strtolower($folder), $searchQuery) !== false;
    });
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Photo Folders</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-2.1.4.min.js"></script>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        /* Body and general page styles */
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background: linear-gradient(45deg,  #006747,  #006747); /* Gorgeous gradient background */
            color: #006747;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow: hidden; /* Prevent horizontal overflow */
        }

        /* Header Style */
        .header {
            background-color: rgba(0, 0, 0, 0.2); /* Darker header for better contrast */
            color: #fff;
            padding: 40px 20px 20px; /* Added more top padding */
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        /* Back to main page button */
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 12px 25px;
            background-color: #f8b400;
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #f8a800;
        }

       /* Search Bar Styling */
.search-bar {
    position: absolute;
    top: 30px;
    right: 30px;
    padding: 10px;
    font-size: 16px;
    border-radius: 25px;
    border: 1px solid #ddd;
    width: 200px;
    background-color: #fff; /* Keep the background white */
    color: #000; /* Set the text color to black */
}

/* Placeholder Text Styling */
.search-bar::placeholder {
    color: #000; /* Set placeholder text color to black */
}


        /* Folder container and sidebar styles */
        .folder-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            gap: 10px;
            margin-top: 180px; /* Adjusted margin to ensure space for the header */
            padding: 30px;
            overflow-y: auto; /* Enable vertical scrolling */
            flex-grow: 1; /* Make sure the folder list grows to fill available space */
        }

        .folder-item {
            position: relative; /* Needed for the anchor tag */
            width: 150px; /* Slightly larger folder items */
            height: 100px; /* Fixed height for all folder items */
            padding: 15px; /* Padding for inner space */
            box-sizing: border-box; /* Include padding and borders in the width and height */
            border-radius: 8px; /* Optional: rounded corners for style */
            background-color: #fff; /* Folder background */
            transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease; /* Smooth transition */
            cursor: pointer;
        }

        /* Entire .folder-item is now clickable */
        .folder-item a {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: block; /* Make sure the entire area is covered by the link */
            text-decoration: none;
            color: #333;
            font-size: 1em;
            font-weight: 600;
            text-align: left;
            line-height: 1.5;
            overflow: hidden; /* Ensure text or content doesn't overflow */
            text-overflow: ellipsis; /* Optionally add ellipsis for overflowing text */
            text-align: center;
        }

        .folder-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            background-color: #f0f0f0;
        }

        .folder-item i {
            font-size: 20px; /* Increased font size for better visibility */
            color: #4fa3f7;
            margin-bottom: 10px;
            transition: color 0.3s ease;

        }

        .folder-item a:hover {
            color: #ff6f61;
        }

        .folder-item:nth-child(odd) {
            background-color: #ffe085; /* Light yellow for odd items */
        }

        .folder-item:nth-child(even) {
            background-color: #4fa3f7; /* Light blue for even items */
        }

        .folder-item:hover i {
            color: #ff6f61;
        }

        /* Footer Styling */
        .footer {
            text-align: center;
            padding: 30px;
            background-color:  #006747;
            color: #fff;
            position: relative;
            width: 100%;
            bottom: 0;
        }

        /* Responsive Styling */
        @media (max-width: 768px) {
            .folder-item {
                width: 180px;
                padding: 15px;
            }

            .folder-list {
                gap: 15px;
                padding: 20px;
            }

            .header {
                font-size: 18px;
                padding: 15px;
            }

            .back-button {
                font-size: 14px;
                padding: 10px 20px;
            }
        }
    </style>
</head>
<body>

    <!-- Header Section with Back Button -->
    <div class="header">
        <button class="back-button" onclick="window.location.href='/pck_updt/main.php'">Back to Main Page</button>
        <h1>Photo Folders</h1>
        <!-- Search Bar -->
        <form method="get" action="" style="position: absolute; top: 30px; right: 30px;">
            <input type="text" name="search" class="search-bar" placeholder="Search folders" value="<?php echo htmlentities($searchQuery); ?>">
        </form>
    </div>

    <!-- Folder List Section -->
    <div class="content">
        <div class="container">
            <!-- Folder List -->
            <div class="folder-list">
                <?php if (!empty($folders)) {
                    foreach ($folders as $folder) { ?>
                        <div class="folder-item">
                            <!-- Entire folder item is now clickable -->
                            <a href="viewfolder.php?folder=<?php echo urlencode($folder); ?>">
                                <i class="fa fa-folder"></i>
                                <?php echo htmlentities($folder); ?>
                            </a>
                        </div>
                    <?php }
                } else { ?>
                    <p>No folders available.</p>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Footer Section (optional) -->
    <div class="footer">
        <p>&copy; Project Management System 2024. All Rights Reserved. IT Team. IDEA Project (Phase-2)</p>
    </div>

</body>
</html>
