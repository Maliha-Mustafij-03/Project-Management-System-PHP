<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $Source_of_fund = $_POST['Source_of_fund'];
    $Total_Cost = $_POST['Total_Cost'];
    $Cumulative_Cost = $_POST['Cumulative_Cost'];
    $Last_date_of_Cumulative_Cost = $_POST['Last_date_of_Cumulative_Cost'];
    $Cumulative_Cost_percentage = $_POST['Cumulative_Cost_percentage'];
    $Annual_dpp_budget = $_POST['Annual_dpp_budget'];
    $Financial_year = $_POST['Financial_year'];
    $Current_fy_progress = $_POST['Current_fy_progress'];
    $Last_date_of_fy_cost = $_POST['Last_date_of_fy_cost']; // Capture the date field
    $current_fy_progress_per = $_POST['current_fy_progress_per'];
    $Current_FY_Allocation = $_POST['Current_FY_Allocation'];
    $Fund_Release_Installments = $_POST['Fund_Release_Installments'];
    $Funds_Released_So_Far = $_POST['Funds_Released_So_Far'];
    $Comments = $_POST['Comments'];
    $entry_date = date('Y-m-d');
    // SQL query to insert data


    $sql = "INSERT INTO financial_progress (Source_of_fund, Total_Cost, Cumulative_Cost, Last_date_of_Cumulative_Cost, Cumulative_Cost_percentage, Annual_dpp_budget, Financial_year, Current_fy_progress, Last_date_of_fy_cost, current_fy_progress_per, Current_FY_Allocation, Fund_Release_Installments, Funds_Released_So_Far, Comments,entry_date) 
            VALUES (:Source_of_fund, :Total_Cost, :Cumulative_Cost, :Last_date_of_Cumulative_Cost, :Cumulative_Cost_percentage, :Annual_dpp_budget, :Financial_year, :Current_fy_progress, :Last_date_of_fy_cost, :current_fy_progress_per, :Current_FY_Allocation, :Fund_Release_Installments, :Funds_Released_So_Far, :Comments, :entry_date)";

    $stmt = $dbh->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':Source_of_fund', $Source_of_fund);
    $stmt->bindParam(':Total_Cost', $Total_Cost);
    $stmt->bindParam(':Cumulative_Cost', $Cumulative_Cost);
    $stmt->bindParam(':Last_date_of_Cumulative_Cost', $Last_date_of_Cumulative_Cost);
    $stmt->bindParam(':Cumulative_Cost_percentage', $Cumulative_Cost_percentage);
    $stmt->bindParam(':Annual_dpp_budget', $Annual_dpp_budget);
    $stmt->bindParam(':Financial_year', $Financial_year);
    $stmt->bindParam(':Current_fy_progress', $Current_fy_progress);
    $stmt->bindParam(':Last_date_of_fy_cost', $Last_date_of_fy_cost); // Bind the Last Date of FY Cost
    $stmt->bindParam(':current_fy_progress_per', $current_fy_progress_per);
    $stmt->bindParam(':Current_FY_Allocation', $Current_FY_Allocation);
    $stmt->bindParam(':Fund_Release_Installments', $Fund_Release_Installments);
    $stmt->bindParam(':Funds_Released_So_Far', $Funds_Released_So_Far);
    $stmt->bindParam(':Comments', $Comments);
    $stmt->bindParam(':entry_date', $entry_date);
    //echo $stmt->execute();
    // Execute the query
    if ($stmt->execute()) {
        echo "<script>alert('Record created successfully');</script>";
        header('Location:Report.php');
    } else {
        echo "<script>alert('Error in creating record');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Monitoring And Evaluation Creation</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/style.css" rel='stylesheet' type='text/css' />
   
    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        /* Flexbox layout for Sidebar and Main Content */
        .wrapper {
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2d3e50;
            padding: 20px;
            color: white;
            position: fixed;
            height: 100vh;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
            background-color: #f4f7fc;
        }

        .container {
            width: 100%;
            margin: 0 auto;
            padding: 40px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        h3 {
            color: #4CAF50;
            text-align: center;
            margin-bottom: 40px;
            font-size: 32px;
        }

        form {
            display: grid;
            grid-template-columns: 1fr 1fr; /* Two columns */
            gap: 20px;
        }

        label {
            font-weight: bold;
            color: black;
            display: block;
            text-align: left; /* Align labels to the left */
        }

        input[type="text"], input[type="number"], input[type="date"], select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            margin-bottom: 15px;
            text-align: left; /* Align input text to the left */
        }

        input[type="submit"], input[type="reset"], input[type="button"] {
            width: 140px;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #4CAF50;
            color: white;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .wrapper {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                position: relative;
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            form {
                grid-template-columns: 1fr; /* Single column on smaller screens */
            }

            .form-row {
                flex-direction: column;
            }

            .form-row .form-group {
                width: 100%;
            }
        }

        /* New Flexbox Styles for the Form Rows */
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .form-row .form-group {
            flex: 1 1 calc(50% - 10px); /* Each form group takes 50% width minus gap */
            box-sizing: border-box;
        }

        .form-row .form-group input {
            width: 100%;
        }

        .form-row .form-group .error {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }
   
    </style>

</head>

<body>
    <div class="wrapper">
        <?php include('includes/sidebarmenu.php'); ?>

        <div class="main-content">
            <?php include('includes/header.php'); ?>
            <center>
                <h3>Create Financial Progress Record</h3>

                <!-- Create form -->
                <form method="post" action="">
                    <div class="form-row">
                        <div class="form-group">
                           <label for="Source_of_fund">অর্থের উৎস</label>
                           <select name="Source_of_fund" required>
                               <option value="জিওবি">জিওবি</option>
                               <option value="আরপিএ/অন্যান্য">আরপিএ/অন্যান্য</option>
                           </select>
                        </div>
                        <div class="form-group">
                            <label for="Total_Cost">মোট প্রকল্প বরাদ্দ </label>
                            <input type="number" name="Total_Cost" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Cumulative_Cost">ক্রমপুঞ্জিত ব্যয়</label>
                            <input type="number" name="Cumulative_Cost" required>
                        </div>
                        <div class="form-group">
                            <label for="Last_date_of_Cumulative_Cost">ক্রমোপঞ্জিত ব্যয়ের তারিখ </label>
                            <input type="date" name="Last_date_of_Cumulative_Cost" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Cumulative_Cost_percentage">ক্রমঃপুঞ্জিত অগ্রগতির হার</label>
                            <input type="decimal" name="Cumulative_Cost_percentage" required>
                        </div>
                        <div class="form-group">
                            <label for="Annual_dpp_budget">বার্ষিক উন্নয়ন কর্মসূচিতে বরাদ্দ </label>
                            <input type="number" name="Annual_dpp_budget">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Financial_year">চলতি অর্থবছর </label>
                            <input type="text" name="Financial_year" placeholder="2024-2025" >
                        </div>
                        <div class="form-group">
                            <label for="Current_fy_progress">চলতি অর্থ বছরের ব্যায়</label>
                            <input type="number" name="Current_fy_progress" >
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Last_date_of_fy_cost">আরএডিপিতে বরাদ্ধ</label>
                            <input type="number" name="Last_date_of_fy_cost">
                        </div>
                    </div> 

                    <div class="form-row">
                        <div class="form-group">
                            <label for="current_fy_progress_per">চলতি অর্থ বছরের অগ্রগতির হার</label>
                            <input type="text" name="current_fy_progress_per" >
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Current_FY_Allocation">আরডিপিপিপিতে বরাদ্দ</label>
                            <input type="number" name="Current_FY_Allocation" required>
                        </div>
                        <div class="form-group">
                            
                            <label for="Fund_Release_Installments">ছাড়কৃত কিস্তি </label>
                             <select name="Fund_Release_Installments" >
                                <option value="">নির্বাচন করুন</option>
                               <option value="1">1</option>
                               <option value="2">2</option>
                               <option value="3">3</option>
                               <option value="4">4</option>
                           </select>
                            
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Funds_Released_So_Far">চলতি অর্থবছরে অর্থ ছাড়</label>
                            <input type="number" name="Funds_Released_So_Far" required>
                        </div>
                    </div>

                    <!-- <div class="form-row">
                        <div class="form-group">
                            <label for="Comments">মন্তব্য</label>
                            <input type="text" name="Comments" >
                        </div>
                    </div> -->

                    <div class="button-container">
                            <input type="submit" name="create" value="Submit">
                            <input type="reset" name="Reset" value="Reset">
                            <input type="button" value="Report" onclick="window.location.href='Report.php'">
                        </div>
                </form>
            </center>
        </div>
    </div>
</body>
</html>
