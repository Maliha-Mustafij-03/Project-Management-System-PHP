<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Delete functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tblsmartcards WHERE id = :delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    $msg = "Smartcard Deleted Successfully";
}

// Search functionality
$search = "";
if (isset($_POST['search'])) {
    $search = $_POST['search_query'];
    // Modify query to search only in tblsmartcards
    $sql = "SELECT * FROM tblsmartcards 
            WHERE ক্রম_নং LIKE :search_query OR 
                  নাম LIKE :search_query OR 
                  মোট_আবেদন LIKE :search_query OR 
                  মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ LIKE :search_query OR 
                  তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন LIKE :search_query OR 
                  তদন্ত_সম্পন্ন_এপ্রুভ LIKE :search_query OR 
                  বাতিল LIKE :search_query OR 
                  মোট LIKE :search_query OR 
                  উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন LIKE :search_query OR 
                  মিশন_থেকে_আপলোড_অপেক্ষাধীন LIKE :search_query OR 
                  আপলোড LIKE :search_query OR 
                  প্রিন্ট_করার_উপযোগী LIKE :search_query OR 
                  প্রিন্টেড LIKE :search_query OR 
                  তারিখ LIKE :search_query";
    $query = $dbh->prepare($sql);
    $query->bindValue(':search_query', '%' . $search . '%');
    $query->execute();
} else {
    // Fetch all smartcards from tblsmartcards
    $sql = "SELECT * FROM tblsmartcards";
    $query = $dbh->prepare($sql);
    $query->execute();
}

// Fetch results
$smartcards = $query->fetchAll(PDO::FETCH_ASSOC);

// Debugging: Check query result
// echo "<pre>";
// print_r($smartcards);  // Check the result of the query
// echo "</pre>";
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS-GD | Manage Smartcards</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        body {
            font-size: 18px; /* Larger text for better readability */
        }

        .table th, .table td {
            font-size: 16px; /* Ensure data in table is big enough */
        }

        .table th {
            background-color: #f8f9fa;
            text-align: center;
        }

        .table td {
            text-align: center;
        }

        .search-bar {
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
        }

        .alert {
            text-align: center;
            font-size: 18px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
        }

        .grouped-box {
            background-color: #f0f8ff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
        }

        .grouped-box h3 {
            text-align: center;
        }

        .grouped-box .row {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <?php include('includes/sidebarmenu.php'); ?>

    <div class="container">
        <h1>Manage Smartcards</h1>
        
        <!-- Search Form -->
        <div class="search-bar">
            <form method="POST" class="form-inline">
                <input type="text" name="search_query" class="form-control" value="<?php echo htmlentities($search); ?>" placeholder="Search by any data">
                <button type="submit" name="search" class="btn btn-primary ml-2 btn-custom">Search</button>
            </form>
        </div>

        <?php if(isset($msg)) { ?>
            <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
        <?php } ?>
<div class="grouped-box">
    <?php foreach($smartcards as $smartcard) { ?>
        <div class="row">
            <div class="col-md-12">
                <h3>Smartcard Details (ID: <?php echo htmlentities($smartcard['id']); ?>)</h3>
            </div>

            <!-- Left Column -->
            <div class="col-md-6">
                <strong>ক্রম নং: </strong><?php echo htmlentities($smartcard['ক্রম_নং']); ?><br>
                <strong>নাম: </strong><?php echo htmlentities($smartcard['নাম']); ?><br>
                <strong>মোট আবেদন: </strong><?php echo htmlentities($smartcard['মোট_আবেদন']); ?><br>
                <strong>মিশন অফিসে বায়োমেট্রিক গ্রহণ: </strong><?php echo htmlentities($smartcard['মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ']); ?><br>
            </div>

            <!-- Right Column -->
            <div class="col-md-6">
                <strong>তদন্ত সম্পন্ন,এপ্রুভ এর অপেক্ষাধীন: </strong><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন']); ?><br>
                <strong>তদন্ত সম্পন্ন,এপ্রুভ: </strong><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ']); ?><br>
                <strong>বাতিল: </strong><?php echo htmlentities($smartcard['বাতিল']); ?><br>
                <strong>তারিখ: </strong><?php echo htmlentities($smartcard['তারিখ']); ?><br>
            </div>

            <!-- Additional Fields -->
            <div class="col-md-6">
                <strong>মোট: </strong><?php echo htmlentities($smartcard['মোট']); ?><br>
                <strong>উপজেলা থানা নির্বাচন অফিস কর্তৃক তদন্ত প্রক্রিয়াধীন: </strong><?php echo htmlentities($smartcard['উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন']); ?><br>
                <strong>মিশন থেকে আপলোড অপেক্ষাধীন: </strong><?php echo htmlentities($smartcard['মিশন_থেকে_আপলোড_অপেক্ষাধীন']); ?><br>
            </div>

            <div class="col-md-6">
                <strong>আপলোড: </strong><?php echo htmlentities($smartcard['আপলোড']); ?><br>
                <strong>প্রিন্ট করার উপযোগী: </strong><?php echo htmlentities($smartcard['প্রিন্ট_করার_উপযোগী']); ?><br>
                <strong>প্রিন্টেড: </strong><?php echo htmlentities($smartcard['প্রিন্টেড']); ?><br>
            </div>
        </div>
        <hr>
    <?php } ?>
</div>

        

    </div>
</body>
</html>
