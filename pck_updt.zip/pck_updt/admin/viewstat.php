<?php
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';  // Change as needed
$password = '';  // Change as needed

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current record if `id` is set (main category or subcategory)
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch main category data
    $result = $conn->query("SELECT * FROM snid_card_main_data WHERE id = $id");
    if ($result) {
        $data = $result->fetch_assoc();
    } else {
        die("Main category not found.");
    }

    // Fetch subcategories for the given main category
    $subcategories = $conn->query("SELECT * FROM snid_card_subcategory_data WHERE main_category_id = $id");
    if (!$subcategories) {
        die("Subcategories not found.");
    }

    // Fetch item data based on the subcategories
    $items = [];
    while ($subcategory = $subcategories->fetch_assoc()) {
        $subcategory_id = $subcategory['id'];
        $item_result = $conn->query("SELECT * FROM snid_card_item_data WHERE subcategory_id = $subcategory_id");
        while ($item = $item_result->fetch_assoc()) {
            $items[] = [
                'subcategory_name' => $subcategory['subcategory_name'],  // Add subcategory name to group items by subcategory
                'item_name' => $item['item_name'],
                'item_count' => $item['item_count']
            ];
        }
    }

    // Limit to top 10 items based on item count
    usort($items, function($a, $b) {
        return $b['item_count'] - $a['item_count']; // Sort in descending order by item_count
    });
    $top_items = array_slice($items, 0, 10); // Limit to top 10 items
} else {
    die("Invalid request: Missing category ID.");
}
?>

<?php include('includes/header.php'); ?>
<?php include('includes/sidebarmenu.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>স্মার্ট কার্ড তথ্য প্রদর্শন</title>

    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        body, html {
            overflow-x: hidden;
            height: 100%;
            font-family: 'Arial', sans-serif;
        }
        .container {
            padding-top: 60px;
            padding-left: 250px;
        }
        .row {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .left-column, .right-column {
            width: 48%;
        }
        .right-column {
            height: 400px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2>স্মার্ট কার্ড তথ্য প্রদর্শন</h2>

    <div class="row">
        <div class="left-column">
            <h3>মূল ক্যাটাগরি: <?= htmlspecialchars($data['category_name']); ?></h3>
            <p><strong>মোট সংখ্যা:</strong> <?= $data['total_count']; ?></p>
            
            <h4>সাব ক্যাটাগরি:</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>নাম</th>
                        <th>বিবরণ</th>
                        <th>সাব ক্যাটাগরি মোট</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Resetting the subcategories pointer to fetch fresh data
                    $subcategories->data_seek(0);
                    while ($subcategory = $subcategories->fetch_assoc()) :
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($subcategory['subcategory_name']); ?></td>
                            <td><?= htmlspecialchars($subcategory['description']); ?></td>
                            <td><?= $subcategory['subcategory_total']; ?></td>
                        </tr>

                        <!-- Display item data for the current subcategory -->
                        <tr>
                            <td colspan="3">
                                <strong>আইটেমের তালিকা:</strong>
                                <ul>
                                    <?php
                                    // Loop through items related to the current subcategory
                                    foreach ($top_items as $item) :
                                        if ($item['subcategory_name'] == $subcategory['subcategory_name']) :
                                    ?>
                                            <li><?= htmlspecialchars($item['item_name']) . ' - ' . $item['item_count']; ?></li>
                                    <?php
                                        endif;
                                    endforeach;
                                    ?>
                                </ul>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="right-column">
            <canvas id="itemChart" width="400" height="400"></canvas>
            <script>
                var ctx = document.getElementById('itemChart').getContext('2d');
                var itemChart = new Chart(ctx, {
                    type: 'pie',  // Changed to pie chart
                    data: {
                        labels: <?php 
                            // Update labels to show both item name and subcategory name
                            $item_labels = array_map(function($item) { 
                                return $item['item_name'] . " (" . $item['subcategory_name'] . ")";
                            }, $top_items);
                            echo json_encode($item_labels);
                        ?>,
                        datasets: [{
                            label: 'আইটেম সংখ্যা',
                            data: <?php 
                                $item_counts = array_map(function($item) { return $item['item_count']; }, $top_items);
                                echo json_encode($item_counts);
                            ?>,
                            backgroundColor: [
                                'rgba(52, 152, 219, 0.6)',
                                'rgba(231, 76, 60, 0.6)',
                                'rgba(46, 204, 113, 0.6)',
                                'rgba(241, 196, 15, 0.6)',
                                'rgba(155, 89, 182, 0.6)',
                                'rgba(52, 152, 219, 0.6)',
                                'rgba(231, 76, 60, 0.6)',
                                'rgba(46, 204, 113, 0.6)',
                                'rgba(241, 196, 15, 0.6)',
                                'rgba(155, 89, 182, 0.6)'
                            ],  // Different color for each slice
                            borderColor: [
                                'rgba(52, 152, 219, 1)',
                                'rgba(231, 76, 60, 1)',
                                'rgba(46, 204, 113, 1)',
                                'rgba(241, 196, 15, 1)',
                                'rgba(155, 89, 182, 1)',
                                'rgba(52, 152, 219, 1)',
                                'rgba(231, 76, 60, 1)',
                                'rgba(46, 204, 113, 1)',
                                'rgba(241, 196, 15, 1)',
                                'rgba(155, 89, 182, 1)'
                            ],  // Border color for each slice
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',  // Position the legend
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(tooltipItem) {
                                        return tooltipItem.label + ": " + tooltipItem.raw;  // Format tooltip
                                    }
                                }
                            }
                        }
                    }
                });
            </script>
        </div>
    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>
