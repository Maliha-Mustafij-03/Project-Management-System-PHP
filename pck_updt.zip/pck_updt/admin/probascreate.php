<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Handle smartcard creation
if (isset($_POST['submit'])) {
    // Capture form data
    $slno = $_POST['slno'];
    $name = $_POST['name'];

    // Handle the arrays for each dynamic field
    $totalApplications = $_POST['totalApplications'];  // Ensure this matches the name used in the JS
    $biometricsTaken = $_POST['biometricstaken'];
    $investigationPendingApproval = $_POST['investigationpendingapproval'];
    $investigationApproved = $_POST['investigationapproved'];
    $canceled = $_POST['canceled'];
    $investigationInProgress = $_POST['investigationinprogress'];
    $awaitingUpload = $_POST['awaitingupload'];
    $uploaded = $_POST['uploaded'];
    $readyForPrinting = $_POST['readyforprinting'];
    $printed = $_POST['printed'];
    $date = $_POST['date'];

    // Loop through arrays and insert each record
    for ($i = 0; $i < count($biometricsTaken); $i++) {
        // Dynamically calculate the total
        $total = $investigationPendingApproval[$i] + $investigationApproved[$i] + $canceled[$i];

        // Check if the record already exists in the database
        $sql_check = "SELECT COUNT(*) FROM tblsmartcards WHERE 
                      ক্রম_নং = :slno AND 
                      নাম = :name AND 
                      তারিখ = :date";
        $query_check = $dbh->prepare($sql_check);
        $query_check->bindParam(':slno', $slno, PDO::PARAM_STR);
        $query_check->bindParam(':name', $name, PDO::PARAM_STR);
        $query_check->bindParam(':date', $date[$i], PDO::PARAM_STR);
        $query_check->execute();
        
        // If the record already exists, skip insertion
        $existingRecordCount = $query_check->fetchColumn();
        
        if ($existingRecordCount == 0) {
            // Only insert if the record doesn't exist
            $sql = "INSERT INTO tblsmartcards 
                    (ক্রম_নং, নাম, মোট_আবেদন, মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ, 
                     তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন, তদন্ত_সম্পন্ন_এপ্রুভ, বাতিল, মোট, 
                     উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন, 
                     মিশন_থেকে_আপলোড_অপেক্ষাধীন, আপলোড, প্রিন্ট_করার_উপযোগী, 
                     প্রিন্টেড, তারিখ)
                     VALUES 
                    (:slno, :name, :totalApplications, :biometricsTaken, :investigationPendingApproval, 
                     :investigationApproved, :canceled, :total, :investigationInProgress, :awaitingUpload, 
                     :uploaded, :readyForPrinting, :printed, :date)";

            $query = $dbh->prepare($sql);
            // Bind the parameters for each iteration
            $query->bindParam(':slno', $slno, PDO::PARAM_STR);
             $query->bindParam(':date', $date[$i], PDO::PARAM_STR);  // Date is string because it's in YYYY-MM-DD format

            $query->bindParam(':name', $name, PDO::PARAM_STR);
            $query->bindParam(':totalApplications', $totalApplications[$i], PDO::PARAM_INT);
            $query->bindParam(':biometricsTaken', $biometricsTaken[$i], PDO::PARAM_INT);
            $query->bindParam(':investigationPendingApproval', $investigationPendingApproval[$i], PDO::PARAM_INT);
            $query->bindParam(':investigationApproved', $investigationApproved[$i], PDO::PARAM_INT);
            $query->bindParam(':canceled', $canceled[$i], PDO::PARAM_INT);
            $query->bindParam(':total', $total, PDO::PARAM_INT); // Total will be the calculated sum
            $query->bindParam(':investigationInProgress', $investigationInProgress[$i], PDO::PARAM_INT);
            $query->bindParam(':awaitingUpload', $awaitingUpload[$i], PDO::PARAM_INT);
            $query->bindParam(':uploaded', $uploaded[$i], PDO::PARAM_INT);
            $query->bindParam(':readyForPrinting', $readyForPrinting[$i], PDO::PARAM_INT);
            $query->bindParam(':printed', $printed[$i], PDO::PARAM_INT);
           
            $query->execute();
        }
    }

    $msg = "Smartcard Send in Abroad Record Created Successfully";
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Admin Creation</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin-left: 200px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control1 {
            font-size: 13px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            margin-top: 8px;
        }
        .btn-container {
            margin-top: 20px;
            text-align: center;
        }
        .detail-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        .detail-row input {
            flex: 1;
            min-width: 220px;
            padding: 12px;
            font-size: 12px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .btn {
            font-size: 16px;
            padding: 10px 20px;
        }
        .alert {
            color: green;
            font-size: 18px;
            text-align: center;
            margin-top: 20px;
        }
    </style>

    <script>
        function addField() {
            var container = document.getElementById('fieldsContainer');
            var row = document.createElement('div');
            row.className = 'detail-row';

            var fields = [
                {label: 'মোট আবেদন', name: 'totalApplications[]', placeholder: 'Enter Total Applications'},
                {label: 'তারিখ', name: 'date[]', placeholder: 'Enter Date (YYYY-MM-DD)', type: 'date'},
                {label: 'মিশন অফিসে বায়োমেট্রিক গ্রহণ', name: 'biometricstaken[]', placeholder: 'Enter Biometrics Taken'},
                {label: 'তদন্ত সম্পন্ন,এপ্রুভ এর অপেক্ষাধীন', name: 'investigationpendingapproval[]', placeholder: 'Enter Pending Investigations'},
                {label: 'তদন্ত সম্পন্ন,এপ্রুভ', name: 'investigationapproved[]', placeholder: 'Enter Approved Investigations'},
                {label: 'বাতিল', name: 'canceled[]', placeholder: 'Enter Canceled Applications'},
                {label: 'তদন্ত প্রক্রিয়াধীন', name: 'investigationinprogress[]', placeholder: 'Enter In Progress Investigations'},
                {label: 'আপলোড অপেক্ষাধীন', name: 'awaitingupload[]', placeholder: 'Enter Awaiting Upload'},
                {label: 'আপলোড', name: 'uploaded[]', placeholder: 'Enter Uploaded'},
                {label: 'প্রিন্টের জন্য প্রস্তুত', name: 'readyforprinting[]', placeholder: 'Enter Ready for Printing'},
                {label: 'প্রিন্টেড', name: 'printed[]', placeholder: 'Enter Printed'}
                

            ];

            fields.forEach(function(field) {
    var div = document.createElement('div');
    div.className = 'form-group';

    var label = document.createElement('label');
    label.textContent = field.label;

    var input = document.createElement('input');
    input.name = field.name;
    input.placeholder = field.placeholder;
    input.className = 'form-control1';

    // Check if the field is a date type and set it
    if (field.type === 'date') {
        input.type = 'date';  // Use date type for the "Date" field
    } else {
        input.type = 'number';  // Other fields remain number type
    }

    div.appendChild(label);
    div.appendChild(input);
    row.appendChild(div);
});


            container.appendChild(row);
        }

        function removeField() {
            var container = document.getElementById('fieldsContainer');
            if (container.children.length > 0) {
                container.removeChild(container.lastElementChild);
            }
        }
    </script>
</head>

<body>
    <div class="container">
        <h2>প্রবাসে স্মার্ট কার্ড বিতরণ কার্যক্রম</h2>
        <?php if ($msg) { echo "<div class='alert'>$msg</div>"; } ?>

        <form method="post">
            
          <div class="form-group">
    <label for="name">দেশের নাম</label>
    <select id="name" name="name" class="form-control1" required>
        <option value="">Select a Country</option>
        <option value="Saudi Arabia">Saudi Arabia</option>
        <option value="UAE">UAE</option>
        <option value="Kuwait">Kuwait</option>
        <option value="Oman">Oman</option>
        <option value="Qatar">Qatar</option>
        <option value="Bahrain">Bahrain</option>
        <option value="Lebanon">Lebanon</option>
        <option value="Jordan">Jordan</option>
        <option value="Libya">Libya</option>
        <option value="Sudan">Sudan</option>
        <option value="Malaysia">Malaysia</option>
        <option value="Singapore">Singapore</option>
        <option value="South Korea">South Korea</option>
        <option value="United Kingdom">United Kingdom</option>
        <option value="Italy">Italy</option>
        <option value="United States">United States</option>
        <option value="Canada">Canada</option>
        <option value="Japan">Japan</option>
        <option value="Australia">Australia</option>
        <option value="Greece">Greece</option>
        
        <option value="Germany">Germany</option>
        <option value="South Africa">South Africa</option>
        <option value="Egypt">Egypt</option>
        
        <option value="Philippines">Philippines</option>
        <option value="Swithzerland">Swithzerland</option>
        <option value="Brazil">Brazil</option>
        <option value="Russia">Russia</option>
        <option value="Hongkong">Hongkong</option>
        <option value="Spain">Spain</option>
        <option value="France">France</option>
        <option value="Netherland">Netherland</option>
        
        <option value="Maldives">Maldives</option>
        <option value="New-zealand">New-zealand</option>
        
        <option value="Cyprus">Cyprus</option>
        <option value="China">China</option>
        <option value="Indonesia">Indonesia</option>
        <option value="Mauritius">Mauritius</option>
        
        <option value="Turkey">Turkey</option>
        
       
        <option value="Brunei">Brunei</option>
        <option value="Iraq">Iraq</option>
    </select>
</div>



            <div id="fieldsContainer">
                <!-- Dynamic fields will be inserted here -->
            </div>

            <div class="btn-container">
                <button type="button" class="btn btn-primary" onclick="addField()">নতুন যোগ করুন </button>
                <button type="button" class="btn btn-danger" onclick="removeField()">মুছুন</button>
            </div>

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-success">তৈরী</button>
            </div>
        </form>
    </div>
</body>
</html>
