
<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize variables for feedback messages
$successMsg = '';
$errorMsg = '';

// Handle form submission for adding a new photo
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $folderName = $_POST['folder_name']; // Folder name chosen by user

    try {
        // Validate the folder name
        $folderPath = "uploads/" . $folderName;

        // Check if the folder exists
        if (!file_exists($folderPath)) {
            // If the folder doesn't exist, prompt the user to create it
            if (isset($_POST['create_folder']) && $_POST['create_folder'] == 'yes') {
                // Create a new folder
                if (!mkdir($folderPath, 0777, true)) {
                    $errorMsg = "<div class='alert alert-danger'>Error creating folder.</div>";
                }
            } else {
                // If the folder doesn't exist and the user chooses not to create a new one
                $errorMsg = "<div class='alert alert-danger'>Folder does not exist. Please create a new folder.</div>";
            }
        }

        // File upload handling
        $image_url = null;
        if (!empty($_FILES['image_url']['name'])) {
            $targetFile = $folderPath . "/" . basename($_FILES["image_url"]["name"]);
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

            // Check if file is an actual image
            $check = getimagesize($_FILES["image_url"]["tmp_name"]);
            if ($check === false) {
                $errorMsg = "<div class='alert alert-danger'>File is not an image.</div>";
            } elseif (file_exists($targetFile)) {
                $errorMsg = "<div class='alert alert-danger'>File already exists in this folder.</div>";
            } elseif ($_FILES["image_url"]["size"] > 5000000) { // 5MB max size
                $errorMsg = "<div class='alert alert-danger'>File is too large.</div>";
            } elseif (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
                $errorMsg = "<div class='alert alert-danger'>Only JPG, JPEG, PNG & GIF files are allowed.</div>";
            } else {
                // Move uploaded file
                if (move_uploaded_file($_FILES["image_url"]["tmp_name"], $targetFile)) {
                    $image_url = $targetFile;
                } else {
                    $errorMsg = "<div class='alert alert-danger'>Error uploading file.</div>";
                }
            }
        }

        // Insert new photo details into the database if the image is uploaded
        if ($image_url) {
            $sql = "INSERT INTO photos (title, description, image_url, folder) VALUES (:title, :description, :image_url, :folder)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':title', $title);
            $query->bindParam(':description', $description);
            $query->bindParam(':image_url', $image_url);  // Store the file path in the database
            $query->bindParam(':folder', $folderName);

            // Debugging: Check if the SQL query is working
            if ($query->execute()) {
                $successMsg = "<div class='alert alert-success'>Photo added successfully!</div>";
            } else {
                $errorMsg = "<div class='alert alert-danger'>Error executing SQL query.</div>";
            }
        } else {
            $errorMsg = "<div class='alert alert-danger'>Please upload an image.</div>";
        }
    } catch (PDOException $e) {
        $errorMsg = "<div class='alert alert-danger'>Error adding photo: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Photo</title>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>
    <!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->     
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 1000;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .content {
            margin-left: 250px;
            margin-top: 60px;
            padding: 20px;
        }
        h1 {
            margin-top: 50px;
            color: blue;
            font-size: 24px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <?php include('includes/sidebarmenu.php'); ?>
</div>

<!-- Header -->
<div class="header">
    <?php include('includes/header.php'); ?>
</div>

<!-- Content Area -->
<div class="content">
    <div class="container">
        <h1>Add Photo</h1>

        <?php if ($successMsg) echo $successMsg; ?>
        <?php if ($errorMsg) echo $errorMsg; ?>
        <form method="POST" action="add-photo.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="form-group">
                <label for="folder_name">Folder Name:</label>
                <input type="text" class="form-control" id="folder_name" name="folder_name" required>
                <small>Specify the folder where the photo will be stored.</small>
            </div>
            <div class="form-group">
                <label for="create_folder">Create New Folder:</label>
                <input type="checkbox" name="create_folder" value="yes"> Check to create a new folder
            </div>
            <div class="form-group">
                <label for="image_url">Image:</label>
                <input type="file" class="form-control" id="image_url" name="image_url" required>
            </div>
            <button type="submit" name="add" class="btn btn-primary">Add Photo</button>
        </form>
    </div>
</div>

</body>
</html>
