<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}

// Check if form is submitted for creating a new HR report
if (isset($_POST['create'])) {
    $reportDate = $_POST['report_date'];
    $department = $_POST['department'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Handling file uploads (both PDF and DOC)
    $attachments = '';
    if (!empty($_FILES['attachments']['name'][0])) {
        $uploadedFiles = [];
        foreach ($_FILES['attachments']['tmp_name'] as $key => $tmpName) {
            $fileName = $_FILES['attachments']['name'][$key];
            $fileTmpName = $_FILES['attachments']['tmp_name'][$key];
            $filePath = 'uploads/' . basename($fileName);

            // Check if the file is either PDF or DOC
            $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
            if ($fileExt == 'pdf' || $fileExt == 'doc' || $fileExt == 'docx') {
                move_uploaded_file($fileTmpName, $filePath);
                $uploadedFiles[] = $filePath;
            }
        }
        $attachments = implode(',', $uploadedFiles); // Store comma-separated paths
    }

    // Insert new HR report into the database
    $sql = "INSERT INTO hr_reports (report_date, department, title, description, attachments)
            VALUES (:reportDate, :department, :title, :description, :attachments)";
    
    $query = $dbh->prepare($sql);
    $query->bindParam(':reportDate', $reportDate, PDO::PARAM_STR);
    $query->bindParam(':department', $department, PDO::PARAM_STR);
    $query->bindParam(':title', $title, PDO::PARAM_STR);
    $query->bindParam(':description', $description, PDO::PARAM_STR);
    $query->bindParam(':attachments', $attachments, PDO::PARAM_STR);

    if ($query->execute()) {
        // After successful insertion, store the success message in session
        $_SESSION['msg'] = "HR Report Created Successfully";
        header('Location: managehr.php'); // Redirect to manage-hr-reports.php or your desired page
        exit; // Ensure no further code is executed after the redirect
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Create HR Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .errorWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #dd3d36; }
        .succWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #5cb85c; }
        .header-main, .sidebar { z-index: 1000; }
       .page-container {
            padding-top: 20px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */
        }
        .sidebar { position: fixed; top: 0; left: 0; width: 250px; height: 100vh; background: #f8f9fa; }

    </style>
</head>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>    
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="main.php">হোম</a><i class="fa fa-angle-right"></i>এইচআর রিপোর্ট</li>
        </ol>
        <div class="container">
            <h2>এইচআর রিপোর্ট তৈরি করুন</h2>
            <p>Date, Department, Title, Description, and Attachments:</p>
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>রিপোর্টের তারিখ</label>
                    <input type="date" name="report_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>বিভাগ</label>
                    <input type="text" name="department" class="form-control">
                </div>
                <div class="form-group">
                    <label>মীটিং এর শিরোনাম</label>
                    <input type="text" name="title" class="form-control">
                </div>
                <div class="form-group">
                    <label>বর্ণনা</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>সংযুক্তি (PDF, DOC, DOCX)</label>
                    <input type="file" name="attachments[]" class="form-control" accept=".pdf, .doc, .docx" multiple>
                </div>
                <button type="submit" name="create" class="btn btn-primary">রিপোর্ট তৈরী</button>
            </form>
        </div>
        
        <?php include('includes/footer.php'); ?>
    </div>
    <?php include('includes/sidebarmenu.php'); ?>
    <div class="clearfix"></div>     
</div>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
