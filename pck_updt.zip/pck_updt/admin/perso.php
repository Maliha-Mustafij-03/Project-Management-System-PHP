<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Process the main form data
    $category = $_POST['category'];

    // Insert into smart_nid_print_distribution
    $sql = "INSERT INTO smart_nid_print_distribution (category) VALUES (:category)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':category', $category, PDO::PARAM_STR);
    $query->execute();

    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        // Handle subcategory and additional details (dynamic fields)
        if (isset($_POST['sub_category'])) {
            foreach ($_POST['sub_category'] as $index => $sub_category) {
                if (!empty($sub_category)) {
                    $total_subcategory_count = 0; // Initialize total count for the subcategory
                    $sqlDetail = "INSERT INTO smart_nid_print_details (parent_id, sub_category) 
                                  VALUES (:parent_id, :sub_category)";
                    $queryDetail = $dbh->prepare($sqlDetail);
                    $queryDetail->bindParam(':parent_id', $lastInsertId, PDO::PARAM_INT);
                    $queryDetail->bindParam(':sub_category', $sub_category, PDO::PARAM_STR);
                    $queryDetail->execute();

                    // Handle multiple count and additional info under subcategory
                    if (isset($_POST['count_' . $index])) {
                        foreach ($_POST['count_' . $index] as $subIndex => $countSub) {
                            $additionalInfoSub = $_POST['additional_info_' . $index][$subIndex];
                            $total_subcategory_count += $countSub; // Add to the total count
                            
                            $sqlMoreDetail = "INSERT INTO smart_nid_print_more_details (parent_id, sub_category, count, additional_info) 
                                              VALUES (:parent_id, :sub_category, :count, :additional_info)";
                            $queryMoreDetail = $dbh->prepare($sqlMoreDetail);
                            $queryMoreDetail->bindParam(':parent_id', $lastInsertId, PDO::PARAM_INT);
                            $queryMoreDetail->bindParam(':sub_category', $sub_category, PDO::PARAM_STR);
                            $queryMoreDetail->bindParam(':count', $countSub, PDO::PARAM_INT);
                            $queryMoreDetail->bindParam(':additional_info', $additionalInfoSub, PDO::PARAM_STR);
                            $queryMoreDetail->execute();
                        }
                    }

                    // Update total count for the subcategory
                    $sqlUpdate = "UPDATE smart_nid_print_details SET total_count = :total_count WHERE parent_id = :parent_id AND sub_category = :sub_category";
                    $queryUpdate = $dbh->prepare($sqlUpdate);
                    $queryUpdate->bindParam(':total_count', $total_subcategory_count, PDO::PARAM_INT);
                    $queryUpdate->bindParam(':parent_id', $lastInsertId, PDO::PARAM_INT);
                    $queryUpdate->bindParam(':sub_category', $sub_category, PDO::PARAM_STR);
                    $queryUpdate->execute();
                }
            }
        }
        $msg = "Data Saved Successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<title>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ ফর্ম</title>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
  <style>
    
        /* Remove extra space above the breadcrumb */
        body, .page-container {
            margin: 0;
            padding: 0;
        }

        .mother-grid-inner {
            padding-bottom: 100px; /* Allow some space for footer */
        }

        .page-container {
            max-height: 100vh;
            overflow-y: auto;
        }

        .form-control1 {
            font-size: 16px;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .detail-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .detail-row input {
            margin-right: 10px;
        }

        .btn-container {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .btn-container button {
            margin-right: 10px;
        }

        /* Make the body scrollable */
        body {
            overflow-y: auto;
        }

        /* Ensure fixed header does not overlap */
        .header-main.fixed {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
    </style>
<script>
function addSubCategory() {
    var container = document.getElementById('subCategoryContainer');
    var row = document.createElement('div');
    row.className = 'form-group';

    // Subcategory select dropdown with provided subcategory options
    var subCategorySelect = document.createElement('select');
    subCategorySelect.name = 'sub_category[]';
    subCategorySelect.className = 'form-control';
    subCategorySelect.innerHTML = `
        <option value="">সাব ক্যাটাগরী নির্বাচন করুন</option>
        <option value="কার্যক্রম">কার্যক্রম</option>
        <option value="মুদ্রন চলমান এলাকা">মুদ্রন চলমান এলাকা</option>
        <option value="উপজেলা/থানা ভিত্তিক মুদ্রনের তথ্য">উপজেলা/থানা ভিত্তিক মুদ্রনের তথ্য</option>
        <option value="বিতরন এলাকা">বিতরন এলাকা</option>
        <option value="প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরন">প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরন</option>
        <option value="বীর মু্ক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রন ও প্রেরন">বীর মু্ক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রন ও প্রেরন</option>
        <option value="ব্ল্যাংক কার্ডের হিসাব">ব্ল্যাংক কার্ডের হিসাব</option>
    `;
    row.appendChild(subCategorySelect);

    // Wrapper to hold the additional info and count fields in the same line
    var innerRow = document.createElement('div');
    innerRow.className = 'row';

    // Additional Info input field (6 columns wide)
    var additionalInfoInput = document.createElement('textarea');
    additionalInfoInput.name = 'additional_info_' + container.children.length + '[]';
    additionalInfoInput.className = 'form-control col-sm-6'; // 6 columns wide
    additionalInfoInput.placeholder = 'তথ্য';
    innerRow.appendChild(additionalInfoInput);

    // Count input field (6 columns wide)
    var countInput = document.createElement('input');
    countInput.type = 'number';
    countInput.name = 'count_' + container.children.length + '[]';
    countInput.className = 'form-control col-sm-6'; // 6 columns wide
    countInput.placeholder = 'পরিমান(সংখ্যায়)';
    countInput.addEventListener('input', updateTotalCount);
    innerRow.appendChild(countInput);

    row.appendChild(innerRow);

    // Button to add more count and additional info fields under subcategory
    var addMoreButton = document.createElement('button');
    addMoreButton.type = 'button';
    addMoreButton.className = 'btn btn-primary col-sm-3';
    addMoreButton.innerText = 'বিস্তারিত তথ্য যোগ';
    addMoreButton.setAttribute('onclick', 'addMoreInfo(' + container.children.length + ')');
    row.appendChild(addMoreButton);

    // Add the new subcategory row to the container
    container.appendChild(row);

    // Empty field for Total Count (for manual entry later)
    var totalCountContainer = document.createElement('div');
    totalCountContainer.className = 'form-group';
    totalCountContainer.innerHTML = `
        <label class="col-sm-2 control-label">মোট পরিমান(সংখ্যায়)</label>
        <div class="col-sm-8">
            <input type="number" class="form-control" name="total_count_subcategory[]" placeholder="মোট পরিমান(সংখ্যায়)" />
        </div>
    `;
    container.appendChild(totalCountContainer);
}

function addMoreInfo(subcategoryIndex) {
    var container = document.getElementById('subCategoryContainer');
    var row = document.createElement('div');
    row.className = 'row';

    // Additional Info input field for new info (6 columns wide)
    var additionalInfoInput = document.createElement('textarea');
    additionalInfoInput.name = 'additional_info_' + subcategoryIndex + '[]';
    additionalInfoInput.className = 'form-control col-sm-6'; // 6 columns wide
    additionalInfoInput.placeholder = 'তথ্য';
    row.appendChild(additionalInfoInput);

    // Count input field for new info (6 columns wide)
    var countInput = document.createElement('input');
    countInput.type = 'number';
    countInput.name = 'count_' + subcategoryIndex + '[]';
    countInput.className = 'form-control col-sm-6'; // 6 columns wide
    countInput.placeholder = 'পরিমান(সংখ্যায়)';
    countInput.addEventListener('input', updateTotalCount);
    row.appendChild(countInput);

    // Append this new row to the respective subcategory container
    container.children[subcategoryIndex].appendChild(row);
}

// Update the total count for a subcategory
function updateTotalCount() {
    // This function can be used to calculate the total count if needed later
}
</script>
</head>
<body>
   <div class="page-container">
   <div class="left-content">
       <div class="mother-grid-inner">
           <!-- Header Start Here -->
           <?php include('includes/header.php'); ?>
           <div class="clearfix"></div>
       </div>
       <!-- Header End Here -->
       
       <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</li>
       </ol>

       <div class="grid-form">
           <div class="grid-form1">
               <h3>স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ এর তথ্য</h3>
               <?php if ($error) { ?>
                   <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
               <?php } else if ($msg) { ?>
                   <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
               <?php } ?>
               <form class="form-horizontal" name="smart_nid_form" method="post" enctype="multipart/form-data">
                   <!-- Category Field -->
                   <div class="form-group">
                       <label for="category" class="col-sm-2 control-label">বিবরণ</label>
                       <div class="col-sm-8">
                           <input type="text" class="form-control" name="category" id="category" placeholder="বিবরণ" required>
                       </div>
                   </div>

                   <!-- Subcategory Section -->
                   <div class="form-group">
                       <label for="sub_category" class="col-sm-2 control-label">সাব ক্যাটাগরীর বিস্তারিত</label>
                       <div class="col-sm-8">
                           <div id="subCategoryContainer">
                               <!-- Dynamic Subcategories Will Be Added Here -->
                           </div>
                           <button type="button" class="btn btn-primary" onclick="addSubCategory()">নতুন সাব ক্যাটাগরী যোগ</button>
                       </div>
                   </div>

                   <div class="form-group">
                       <div class="col-sm-8 col-sm-offset-2">
                           <button type="submit" name="submit" class="btn btn-primary">সাবমিট</button>
                       </div>
                   </div>
               </form>
           </div>
       </div>
   </div>
</div>
</body>
</html>
