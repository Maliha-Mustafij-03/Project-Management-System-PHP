<?php
session_start();
include('includes/config.php');

// Check if the 'photo' parameter is provided in the URL
if (isset($_GET['photo'])) {
    $photoId = $_GET['photo'];
    
    // Fetch the photo details from the database to get the image path and folder
    $sql = "SELECT * FROM photos WHERE id = :id";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':id', $photoId);
    $stmt->execute();
    $photo = $stmt->fetch();
    
    if ($photo) {
        // Delete the photo file from the filesystem
        if (file_exists($photo['image_url'])) {
            unlink($photo['image_url']);
        }

        // Delete the photo record from the database
        $sql = "DELETE FROM photos WHERE id = :id";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':id', $photoId);
        $stmt->execute();
        
        // Success message
        $successMsg = "Photo deleted successfully!";
    } else {
        // If the photo is not found
        $errorMsg = "Photo not found.";
    }
} else {
    // No photo specified in the URL
    $errorMsg = "No photo specified.";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Delete Photo</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 1000;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .content {
            margin-left: 250px;
            margin-top: 60px;
            padding: 20px;
        }
        h1 {
            margin-top: 50px;
            color: blue;
            font-size: 24px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <?php include('includes/sidebarmenu.php'); ?>
</div>

<!-- Header -->
<div class="header">
    <?php include('includes/header.php'); ?>
</div>

<!-- Content Area -->
<div class="content">
    <div class="container">
        <h1>Delete Photo</h1>

        <!-- Display Success or Error Message -->
        <?php if (isset($successMsg)): ?>
            <div class="alert alert-success">
                <?php echo $successMsg; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($errorMsg)): ?>
            <div class="alert alert-danger">
                <?php echo $errorMsg; ?>
            </div>
        <?php endif; ?>

        <!-- Button to Go Back to Photo Gallery -->
        <a href="photo-gallery.php" class="btn btn-primary">Back to Photo Gallery</a>
    </div>
</div>

</body>
</html>
