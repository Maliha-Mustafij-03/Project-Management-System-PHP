<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}

// Code for deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM tbltenderpackages WHERE PackageId = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    echo "<script>alert('Package deleted.');</script>";
    echo "<script>window.location.href='manage-packages.php'</script>";
}

// Search query handling
$searchTerm = isset($_POST['search']) ? $_POST['search'] : '';
$sql = "SELECT * FROM tbltenderpackages WHERE PackageNo LIKE :search OR Details LIKE :search OR ResponsiblePerson LIKE :search";
$query = $dbh->prepare($sql);
$query->bindValue(':search', '%' . $searchTerm . '%', PDO::PARAM_STR);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>NCS | Admin Manage Packages</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> 
    addEventListener("load", function() { 
        setTimeout(hideURLbar, 0); 
    }, false); 
    function hideURLbar(){ 
        window.scrollTo(0,1); 
    } 
</script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery-2.1.4.min.js"></script>
<!-- //jQuery -->
<!-- tables -->
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<link rel="stylesheet" type="text/css" href="css/basictable.css" />
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#table').basictable();
        $('#table-breakpoint').basictable({ breakpoint: 768 });
        $('#table-swap-axis').basictable({ swapAxis: true });
        $('#table-force-off').basictable({ forceResponsive: false });
        $('#table-no-resize').basictable({ noResize: true });
        $('#table-two-axis').basictable();
        $('#table-max-height').basictable({ tableWrapper: true });
    });
</script>
<!-- //tables -->

<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->

<!-- Custom Search Box CSS -->
<style>
    /* Ensure the search container takes the full width */
    .search-bar-container {
        width: 100%;
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }
    
    /* The search input should take up the entire available width */
    .search-bar {
        flex-grow: 1; /* This allows the search bar to expand to fill available space */
        padding: 10px;
        font-size: 16px;
        width: 100%;  /* Ensure the input itself also spans the full width */
        box-sizing: border-box; /* Make sure padding is included in the element's width */
    }

    /* The button should be a fixed width, with margin for spacing */
    .search-btn {
        width: 100px;
        padding: 10px;
        font-size: 16px;
        margin-left: 10px; /* Add space between search input and button */
    }
</style>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
   <div class="left-content">
       <div class="mother-grid-inner">
           <!--header start here-->
           <?php include('includes/header.php');?>
           <div class="clearfix"> </div>    
       </div>
       <!--header end here-->
       <ol class="breadcrumb">
                               <li><a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true">
                                        </i>  <span>Back to Home Page</span><div class="clearfix"></div></a></li>
       </ol>
       <div class="agile-grids">    
           <!-- Search Form -->
           <form method="post" action="manage-packages.php" class="form-inline mb-3">
               <div class="form-group search-bar-container">
                   <label for="search" class="sr-only">Search</label>
                   <input type="text" class="form-control search-bar" id="search" name="search" placeholder="Search" value="<?php echo htmlentities($searchTerm); ?>">
                   <button type="submit" class="btn btn-primary search-btn">অনুসন্ধান</button>
               </div>
           </form>

           <!-- tables -->
           <div class="agile-tables">
               <div class="w3l-table-info">
                   <h2>বর্তমান অর্থবছর ২০২৩-২০২৪-এর জন্য অনুমোদিত নিম্নলিখিত প্যাকেজগুলির দ্রুত কেনাকাটা প্রক্রিয়া সম্পন্ন করার জন্য টেন্ডার আহ্বানের জন্য প্রয়োজনীয় টেকনিক্যাল স্পেসিফিকেশন এডিট করুন</h2>
                   <table id="table">
                       <thead>
                           <tr>
                               <th>#</th>
                               <th>প্যাকেজ নম্বর</th>
                               <th>বিস্তারিত</th>
                               <th>দরপত্র আহবান এর তারিখ</th>
                               
                               <th>ক্রয় পদ্ধতি ও ধরণ</th>
                               <th>প্রাক্কলিত ব্যয় (লক্ষ টাকা)</th>
                               <th>ক্রয় অনুমোদনকারী কর্তৃপক্ষ</th>
                               <th>চুক্তির অগ্রগতির তারিখ</th>
                               <th>চলমান/সম্পন্ন</th>
                               <th>তৈরীর তারিখ</th>
                               <th>অ্যাকশন</th>
                           </tr>
                       </thead>
                       <tbody>
                           <?php
                           $cnt = 1;
                           if($query->rowCount() > 0) {
                               foreach($results as $result) {
                           ?>
                           <tr>
                               <td><?php echo htmlentities($cnt);?></td>
                               <td><?php echo htmlentities($result->PackageNo);?></td>
                               <td><?php echo htmlentities($result->Details);?></td>
                                <td><?php echo htmlentities($result->Consultant);?></td>
                              
                               <td><?php echo htmlentities($result->PurchaseMethodType);?></td>
                               <td><?php echo htmlentities($result->EstimatedExpenditure);?></td>
                               <td><?php echo htmlentities($result->ResponsiblePerson);?></td>
                               <td><?php echo htmlentities($result->SpecificationForwardingDate);?></td>
                               <td><?php echo htmlentities($result->liveorclose);?></td>
                               <td><?php echo htmlentities($result->Creationdate);?></td>
                               <td>
                                   <a href="update-package.php?pid=<?php echo htmlentities($result->PackageId);?>">
                                       <button type="button" class="btn btn-primary btn-block">বিস্তারিত দেখুন</button>
                                   </a><br />
                                   <?php
                                   if (isset($_SESSION['alogin'])) {
                                       echo '<a href="manage-packages.php?action=delete&id=' . htmlentities($result->PackageId) . '" 
                                           onclick="return confirm(\'Do you really want to delete?\');" 
                                           class="btn btn-danger btn-block">মুছুন</a>';
                                   }
                                   ?>
                               </td>
                           </tr>
                           <?php $cnt++; } } ?>
                       </tbody>
                   </table>
               </div>
           </div>
           <!-- script-for sticky-nav -->
           <script>
           $(document).ready(function() {
               var navoffeset = $(".header-main").offset().top;
               $(window).scroll(function(){
                   var scrollpos = $(window).scrollTop(); 
                   if(scrollpos >= navoffeset) {
                       $(".header-main").addClass("fixed");
                   } else {
                       $(".header-main").removeClass("fixed");
                   }
               });
           });
           </script>
           <!-- /script-for sticky-nav -->
           <!--inner block start here-->
           <div class="inner-block"></div>
           <!--inner block end here-->
           <!--copy rights start here-->
           <?php include('includes/footer.php');?>
           <!--COPY rights end here-->
       </div>
   </div>
   <!--/content-inner-->
   <!--/sidebar-menu-->
   <?php include('includes/sidebarmenu.php');?>
   <div class="clearfix"></div>     
</div>
<script>
var toggle = true;

$(".sidebar-icon").click(function() {                
  if (toggle) {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  } else {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
  toggle = !toggle;
});
</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->    
</body>
</html>
