<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Handle package creation or update for both admin and user
if (isset($_POST['submit'])) {
    $pno = $_POST['packageno'];
    $pdetails = $_POST['packagedetails'];
    $sfd = $_POST['specificationforwardingdate'];
    $pmt = $_POST['purchasemethodtype'];
    $ee = $_POST['estimatedexpenditure'];
    $rp = $_POST['responsibleperson'];
    $consultant = $_POST['consultant'];
    $lc = $_POST['lc'];
    $pimage = $_FILES["packageimage"]["name"];
    
    // If there is an image uploaded, move it to the folder
    if ($pimage) {
        move_uploaded_file($_FILES["packageimage"]["tmp_name"], "packageimages/" . $pimage);
    }

    // Check if the package already exists in tbltenderpackages, and if so, update it
    $sql = "SELECT PackageId FROM tbltenderpackages WHERE PackageNo=:pno";
    $query = $dbh->prepare($sql);
    $query->bindParam(':pno', $pno, PDO::PARAM_STR);
    $query->execute();
    $existingPackage = $query->fetch(PDO::FETCH_OBJ);

    if ($existingPackage) {
        // If the package exists, update it
        $sqlUpdate = "UPDATE tbltenderpackages SET 
                        Details = :pdetails,
                        SpecificationForwardingDate = :sfd,
                        PurchaseMethodType = :pmt,
                        EstimatedExpenditure = :ee,
                        ResponsiblePerson = :rp,
                        Consultant = :consultant,
                        liveorclose = :lc
                      WHERE PackageNo = :pno";
        $queryUpdate = $dbh->prepare($sqlUpdate);
        $queryUpdate->bindParam(':pdetails', $pdetails, PDO::PARAM_STR);
        $queryUpdate->bindParam(':sfd', $sfd, PDO::PARAM_STR);
        $queryUpdate->bindParam(':pmt', $pmt, PDO::PARAM_STR);
        $queryUpdate->bindParam(':ee', $ee, PDO::PARAM_STR);
        $queryUpdate->bindParam(':rp', $rp, PDO::PARAM_STR);
        $queryUpdate->bindParam(':consultant', $consultant, PDO::PARAM_STR);
        $queryUpdate->bindParam(':lc', $lc, PDO::PARAM_STR);
        $queryUpdate->bindParam(':pno', $pno, PDO::PARAM_STR);
        $queryUpdate->execute();

        // Now update the package details
        foreach ($_POST['package_details'] as $index => $detail) {
            if (!empty($detail)) {
                $detailPart2 = $_POST['detail_part2'][$index];
                $status = $_POST['status'][$index];
                $completionDate = $_POST['completion_date'][$index];

                // Check if this detail already exists
                $sqlDetailUpdate = "SELECT DetailId FROM tblpackagedetails WHERE PackageId = :packageId AND Detail = :detail";
                $queryDetailCheck = $dbh->prepare($sqlDetailUpdate);
                $queryDetailCheck->bindParam(':packageId', $existingPackage->PackageId, PDO::PARAM_INT);
                $queryDetailCheck->bindParam(':detail', $detail, PDO::PARAM_STR);
                $queryDetailCheck->execute();
                $existingDetail = $queryDetailCheck->fetch(PDO::FETCH_OBJ);

                if ($existingDetail) {
                    // If the detail exists, update it
                    $sqlUpdateDetail = "UPDATE tblpackagedetails SET 
                                            DetailPart2 = :detailPart2,
                                            Status = :status,
                                            ActualCompletedDate = :completionDate
                                          WHERE DetailId = :detailId";
                    $queryUpdateDetail = $dbh->prepare($sqlUpdateDetail);
                    $queryUpdateDetail->bindParam(':detailPart2', $detailPart2, PDO::PARAM_STR);
                    $queryUpdateDetail->bindParam(':status', $status, PDO::PARAM_STR);
                    $queryUpdateDetail->bindParam(':completionDate', $completionDate, PDO::PARAM_STR);
                    $queryUpdateDetail->bindParam(':detailId', $existingDetail->DetailId, PDO::PARAM_INT);
                    $queryUpdateDetail->execute();
                } else {
                    // If the detail doesn't exist, insert it
                    $sqlInsertDetail = "INSERT INTO tblpackagedetails (PackageId, Detail, DetailPart2, Status, ActualCompletedDate) 
                                        VALUES (:packageId, :detail, :detailPart2, :status, :completionDate)";
                    $queryInsertDetail = $dbh->prepare($sqlInsertDetail);
                    $queryInsertDetail->bindParam(':packageId', $existingPackage->PackageId, PDO::PARAM_INT);
                    $queryInsertDetail->bindParam(':detail', $detail, PDO::PARAM_STR);
                    $queryInsertDetail->bindParam(':detailPart2', $detailPart2, PDO::PARAM_STR);
                    $queryInsertDetail->bindParam(':status', $status, PDO::PARAM_STR);
                    $queryInsertDetail->bindParam(':completionDate', $completionDate, PDO::PARAM_STR);
                    $queryInsertDetail->execute();
                }
            }
        }

        $msg = "Package Updated Successfully";
    } else {
        $error = "Package Not Found.";
    }
}

// Fetch package details for the form
$pid = intval($_GET['pid']); // Get the Package ID from the URL
$sql = "SELECT * FROM tbltenderpackages WHERE PackageId=:pid";
$query = $dbh->prepare($sql);
$query->bindParam(':pid', $pid, PDO::PARAM_INT);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);

// Fetch package details for this specific package
$sqlDetails = "SELECT * FROM tblpackagedetails WHERE PackageId=:pid";
$queryDetails = $dbh->prepare($sqlDetails);
$queryDetails->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryDetails->execute();
$detailsResults = $queryDetails->fetchAll(PDO::FETCH_OBJ);

?>

<!DOCTYPE HTML>
<html>
<head>
    <title>NCSMS | Admin Package Update</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Responsive web template, Bootstrap Web Templates, Flat Web Templates" />
    <script type="application/x-javascript">
        addEventListener("load", function() { 
            setTimeout(hideURLbar, 0); 
        }, false); 

        function hideURLbar() { 
            window.scrollTo(0,1); 
        } 
    </script>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .form-control1 {
            font-size: 16px; /* Increase font size */
            font-weight: bold; /* Make text bold */
        }
        .form-group label {
            font-weight: bold; /* Make label text bold */
        }
        .btn-container {
            margin-top: 15px;
        }
        .btn-container .btn {
            margin-right: 10px;
        }
        .detail-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .detail-row input {
            margin-right: 10px;
        }
    </style>
    <script>
    function addDetail() {
    var container = document.getElementById('detailsContainer');
    var row = document.createElement('div');
    row.className = 'detail-row';

    // Add description for Tender Details
    var tenderLabel = document.createElement('label');
    tenderLabel.innerHTML = 'কর্মের অগ্রগতি:';
    row.appendChild(tenderLabel);

    // Detail dropdown for "কার্যক্রম সমূহ"
    var detailInput = document.createElement('select');
    detailInput.name = 'package_details[]';
    detailInput.className = 'form-control1';

    // Add the options for "কার্যক্রম সমূহ"
    var options = [
    'নির্বাচন করুন',
        'স্পেসিফিকেশন প্রণয়ন', 
        'দাপ্তরিক প্রাক্কলন প্রণয়ন', 
        'দরপত্র দলিল প্রস্তুত', 
        'দরপত্র দলিল অনুমোদন সচিব(HoPE)', 
        'দরপত্র দলিল অনুমোদন প্রকল্প পরিচালক(PE)', 
        'দরপত্র আহবান/বিজ্ঞাপন প্রকাশ', 
        'প্রি-বিড সভা', 
        'দরপত্র উন্মুক্তকরণ', 
        'দরপত্র মূল্যায়ন', 
        'মূল্যায়ন প্রতিবেদন সুপারিশ অনুমোদন', 
        'NoA/LoA (কার্যাদেশ) প্রদান', 
        'NoA/LoA গ্রহণ', 
        'চুক্তি স্বাক্ষর', 
        'চুক্তি বাস্তবায়ন/প্রণয়ন', 
        'অন্যান্য'
    ];

    options.forEach(function(optionText) {
        var option = document.createElement('option');
        option.value = optionText;
        option.innerHTML = optionText;
        detailInput.appendChild(option);
    });

    row.appendChild(detailInput);

    // Tentative Date input
    var dateLabel = document.createElement('label');
    dateLabel.innerHTML = 'নির্ধারিত তারিখ:';
    row.appendChild(dateLabel);

    var dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.name = 'detail_part2[]';
    dateInput.className = 'form-control1';
    row.appendChild(dateInput);

    // Responsibility Officer/Employee (Text Input)
    var statusLabel = document.createElement('label');
    statusLabel.innerHTML = 'দ্বায়িত্বপ্রাপ্ত কর্মকর্তা/কর্মচারী:';
    row.appendChild(statusLabel);

    var statusInput = document.createElement('input');
    statusInput.type = 'text';
    statusInput.name = 'status[]';
    statusInput.className = 'form-control1';
    statusInput.placeholder = 'কর্মকর্তা/কর্মচারীর নাম';
    row.appendChild(statusInput);

    // Actual Completion Date input
    var completionDateLabel = document.createElement('label');
    completionDateLabel.innerHTML = 'বাস্তবায়নের তারিখ:';
    row.appendChild(completionDateLabel);

    var completionDateInput = document.createElement('input');
    completionDateInput.type = 'date';
    completionDateInput.name = 'completion_date[]';
    completionDateInput.className = 'form-control1';
    row.appendChild(completionDateInput);

    container.appendChild(row);
}


function removeDetail() {
    var container = document.getElementById('detailsContainer');
    if (container.children.length > 1) { // Keep at least one field
        container.removeChild(container.lastChild);
    }
}
    </script>
</head>
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <div class="clearfix"> </div>    
            </div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">হোম</a><i class="fa fa-angle-right"></i>আপডেট প্যাকেজ</li>
            </ol>
            <div class="grid-form">
                <div class="grid-form1">
                    <h3>আপডেট প্যাকেজ</h3>
                    <?php if(isset($error)) { ?>
                        <div class="errorWrap"><?php echo htmlentities($error); ?></div>
                    <?php } else if(isset($msg)) { ?>
                        <div class="succWrap"><?php echo htmlentities($msg); ?></div>
                    <?php } ?>
                    <?php if ($results) { foreach ($results as $result) { ?>
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="packageno">প্যাকেজ নাম্বার</label>
                                <input type="text" class="form-control1" id="packageno" name="packageno" value="<?php echo htmlentities($result->PackageNo); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="packagedetails">প্যাকেজ বিস্তারিত</label>
                                <textarea class="form-control1" id="packagedetails" name="packagedetails" rows="3" required><?php echo htmlentities($result->Details); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="specificationforwardingdate">চুক্তির অগ্রগতির তারিখ</label>
                                <input type="date" class="form-control1" id="specificationforwardingdate" name="specificationforwardingdate" value="<?php echo htmlentities($result->SpecificationForwardingDate); ?>" >
                            </div>
                            <div class="form-group">
                                <label for="purchasemethodtype">ক্রয় পদ্ধতি ও ধরণ</label>
                                <input type="text" class="form-control1" id="purchasemethodtype" name="purchasemethodtype" value="<?php echo htmlentities($result->PurchaseMethodType); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="estimatedexpenditure">প্রাক্কলিত ব্যয় (লক্ষ টাকা)</label>
                                <input type="text" class="form-control1" id="estimatedexpenditure" name="estimatedexpenditure" value="<?php echo htmlentities($result->EstimatedExpenditure); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="responsibleperson">ক্রয় অনুমোদনকারী কর্তৃপক্ষ</label>
                                <input type="text" class="form-control1" id="responsibleperson" name="responsibleperson" value="<?php echo htmlentities($result->ResponsiblePerson); ?>">
                            </div>
                            <div class="form-group">
                                <label for="consultant">দরপত্র আহবান এর তারিখ</label>
                                <input type="date" class="form-control1" id="consultant" name="consultant" value="<?php echo htmlentities($result->Consultant); ?>">
                            </div>
                            
                            <div class="form-group">
    <label for="lc">বর্তমান পর্যায়</label>
    <div>
        <label>
            <input type="radio" name="lc" value="সম্পন্ন" <?php echo ($result->liveorclose == 'সম্পন্ন') ? 'checked' : ''; ?>>
            সম্পন্ন
        </label>
        <label>
            <input type="radio" name="lc" value="আসন্ন" <?php echo ($result->liveorclose == 'আসন্ন') ? 'checked' : ''; ?>>
            আসন্ন
        </label>
        <label>
            <input type="radio" name="lc" value="চলমান" <?php echo ($result->liveorclose == 'চলমান') ? 'checked' : ''; ?>>
            চলমান
        </label>
    </div>
</div>

                            
                            <!-- <div class="form-group">
                                <label for="packageimage">প্যাকেজ ইমেজ</label>
                                <input type="file" class="form-control1" id="packageimage" name="packageimage">
                            </div> -->

                            <div id="detailsContainer">
                                <?php if ($detailsResults) { foreach ($detailsResults as $detail) { ?>
                                    <div class="detail-row">
                                        <input type="text" name="package_details[]" class="form-control1" value="<?php echo htmlentities($detail->Detail); ?>" placeholder="কার্যক্রম সমূহ">
                                        <input type="date" name="detail_part2[]" class="form-control1" value="<?php echo htmlentities($detail->DetailPart2); ?>">
                                        <input type="text" name="status[]" class="form-control1" value="<?php echo htmlentities($detail->Status); ?>" placeholder="কর্মকর্তা/কর্মচারীর নাম">
                                        <input type="date" name="completion_date[]" class="form-control1" value="<?php echo htmlentities($detail->ActualCompletedDate); ?>">
                                    </div>
                                <?php } } ?>
                            </div>
                            <div class="btn-container">
    <button type="button" class="btn btn-primary" onclick="addDetail()">নতুন যোগ করুন</button>
        <button type="button" class="btn btn-danger" onclick="removeDetail()">রিসেট</button>
    <button type="submit" name="submit" class="btn btn-primary" style="margin-top: 0px;">আপডেট প্যাকেজ</button>
</div>

<!-- Added margin-top to the update button -->
<div class="form-group">
    <div class="col-sm-8 col-sm-offset-2">
       
    </div>
                        </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
