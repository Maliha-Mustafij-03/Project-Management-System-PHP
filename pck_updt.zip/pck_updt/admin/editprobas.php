<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

$msg = "";

// Check if AssetID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the existing smartcard data to prefill the form
    $sql = "SELECT * FROM tblsmartcards WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Assign the existing data to variables for pre-population
        $slno = $result['ক্রম_নং'];
        $name = $result['নাম'];
        $totalApplications = $result['মোট_আবেদন'];
        $biometricsTaken = $result['মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ'];
        $investigationPendingApproval = $result['তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন'];
        $investigationApproved = $result['তদন্ত_সম্পন্ন_এপ্রুভ'];
        $canceled = $result['বাতিল'];
        $total = $result['মোট'];
        $investigationInProgress = $result['উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন'];
        $awaitingUpload = $result['মিশন_থেকে_আপলোড_অপেক্ষাধীন'];
        $uploaded = $result['আপলোড'];
        $readyForPrinting = $result['প্রিন্ট_করার_উপযোগী'];
        $printed = $result['প্রিন্টেড'];
        $date = $result['তারিখ'];
    }

    // Handle the form submission for both Create and Edit
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Capture form data
        $slno = $_POST['slno'];
        $name = $_POST['name'];
        $totalApplications = $_POST['totalapplication'];
        $biometricsTaken = $_POST['biometricstaken'];
        $investigationPendingApproval = $_POST['investigationpendingapproval'];
        $investigationApproved = $_POST['investigationapproved'];
        $canceled = $_POST['canceled'];
        $total = $_POST['total'];
        $investigationInProgress = $_POST['investigationinprogress'];
        $awaitingUpload = $_POST['awaitingupload'];
        $uploaded = $_POST['uploaded'];
        $readyForPrinting = $_POST['readyforprinting'];
        $printed = $_POST['printed'];
        $date = $_POST['date'];

        // Check if a record with the same name and date already exists
        $checkSql = "SELECT id FROM tblsmartcards WHERE নাম = :name AND তারিখ = :date";
        $checkQuery = $dbh->prepare($checkSql);
        $checkQuery->bindParam(':name', $name, PDO::PARAM_STR);
        $checkQuery->bindParam(':date', $date, PDO::PARAM_STR);
        $checkQuery->execute();
        $existingRecord = $checkQuery->fetch(PDO::FETCH_ASSOC);

        // If a record exists with the same name and date
        if ($existingRecord) {
            // If we are editing, update the record
            if (isset($id) && $id != '') {
                // Update existing record logic
                $sql = "UPDATE tblsmartcards SET 
                        ক্রম_নং = :slno, 
                        নাম = :name, 
                        মোট_আবেদন = :totalApplications, 
                        মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ = :biometricsTaken, 
                        তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন = :investigationPendingApproval,
                        তদন্ত_সম্পন্ন_এপ্রুভ = :investigationApproved, 
                        বাতিল = :canceled, 
                        মোট = :total, 
                        উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন = :investigationInProgress, 
                        মিশন_থেকে_আপলোড_অপেক্ষাধীন = :awaitingUpload, 
                        আপলোড = :uploaded, 
                        প্রিন্ট_করার_উপযোগী = :readyForPrinting, 
                        প্রিন্টেড = :printed, 
                        তারিখ = :date
                        WHERE id = :id";
                $query = $dbh->prepare($sql);
                $query->bindParam(':id', $id, PDO::PARAM_INT);
            } else {
                // Insert new record logic
                $sql = "INSERT INTO tblsmartcards 
                        (ক্রম_নং, নাম, মোট_আবেদন, মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ, তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন, 
                         তদন্ত_সম্পন্ন_এপ্রুভ, বাতিল, মোট, উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন, 
                         মিশন_থেকে_আপলোড_অপেক্ষাধীন, আপলোড, প্রিন্ট_করার_উপযোগী, প্রিন্টেড, তারিখ)
                         VALUES 
                        (:slno, :name, :totalApplications, :biometricsTaken, :investigationPendingApproval, :investigationApproved, 
                         :canceled, :total, :investigationInProgress, :awaitingUpload, :uploaded, :readyForPrinting, :printed, :date)";
                $query = $dbh->prepare($sql);
            }
        } else {
            // If no record exists with the same name and date, insert a new record
            $sql = "INSERT INTO tblsmartcards 
                    (ক্রম_নং, নাম, মোট_আবেদন, মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ, তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন, 
                     তদন্ত_সম্পন্ন_এপ্রুভ, বাতিল, মোট, উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন, 
                     মিশন_থেকে_আপলোড_অপেক্ষাধীন, আপলোড, প্রিন্ট_করার_উপযোগী, প্রিন্টেড, তারিখ)
                     VALUES 
                    (:slno, :name, :totalApplications, :biometricsTaken, :investigationPendingApproval, :investigationApproved, 
                     :canceled, :total, :investigationInProgress, :awaitingUpload, :uploaded, :readyForPrinting, :printed, :date)";
            $query = $dbh->prepare($sql);
        }

        // Bind the parameters for both Create and Update
        $query->bindParam(':slno', $slno, PDO::PARAM_STR);
        $query->bindParam(':name', $name, PDO::PARAM_STR);
        $query->bindParam(':totalApplications', $totalApplications, PDO::PARAM_INT);
        $query->bindParam(':biometricsTaken', $biometricsTaken, PDO::PARAM_INT);
        $query->bindParam(':investigationPendingApproval', $investigationPendingApproval, PDO::PARAM_INT);
        $query->bindParam(':investigationApproved', $investigationApproved, PDO::PARAM_INT);
        $query->bindParam(':canceled', $canceled, PDO::PARAM_INT);
        $query->bindParam(':total', $total, PDO::PARAM_INT);
        $query->bindParam(':investigationInProgress', $investigationInProgress, PDO::PARAM_INT);
        $query->bindParam(':awaitingUpload', $awaitingUpload, PDO::PARAM_INT);
        $query->bindParam(':uploaded', $uploaded, PDO::PARAM_INT);
        $query->bindParam(':readyForPrinting', $readyForPrinting, PDO::PARAM_INT);
        $query->bindParam(':printed', $printed, PDO::PARAM_INT);
        $query->bindParam(':date', $date, PDO::PARAM_STR);  // Date is string because it's in YYYY-MM-DD format

        $query->execute();

        $msg = "Smartcard Created/Updated Successfully";
    }
} else {
    echo "ID not found.";
    exit;
}
?>

<!-- Your HTML Form here for displaying and submitting data -->

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS/GD | Admin Smartcard Creation/Edit</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
        }

        header {
            background-color: #34495e;
            padding: 10px 0;
            color: #fff;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 28px;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #2c3e50;
            color: #fff;
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h2 {
            text-align: center;
            font-size: 22px;
            margin-bottom: 30px;
            color: #fff;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
        }

        .sidebar ul li:hover {
            background-color: #34495e;
        }

        .container {
            margin-left: 250px;
            padding: 30px;
            width: calc(100% - 250px);
        }

        .form-group {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .form-group .half {
            grid-column: span 2;
        }

        .btn-primary {
            background-color: #3498db;
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #2980b9;
        }

        footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background-color: #34495e;
            color: #fff;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>

<body>
    <header>
        <h1>প্রবাসে স্মার্ট কার্ড বিতরণের বিস্তারিত</h1>
    </header>

    

    <div class="container">
        <h2>বিস্তারিত</h2>

        <form method="post">
            <?php if ($msg) { echo "<div class='alert alert-success'>$msg</div>"; } ?>

            <div class="form-group">
               
                <div>
                    <label for="name">দেশের নাম</label>
                    <input type="text" name="name" id="name" value="<?php echo htmlentities($name); ?>" required>
                </div>
                <div>
                    <label for="totalapplication">মোট আবেদন</label>
                    <input type="number" name="totalapplication" id="totalapplication" value="<?php echo htmlentities($totalApplications); ?>" required>
                </div>

                <div>
                    <label for="biometricstaken">মিশন অফিসে বায়োমেট্রিক গ্রহণ,তদন্ত সম্পন্ন এপ্রুভ এর অপেক্ষাধীন</label>
                    <input type="number" name="biometricstaken" id="biometricstaken" value="<?php echo htmlentities($biometricsTaken); ?>" required>
                </div>
                <div>
                    <label for="investigationpendingapproval">Investigation Pending Approval</label>
                    <input type="number" name="investigationpendingapproval" id="investigationpendingapproval" value="<?php echo htmlentities($investigationPendingApproval); ?>" required>
                </div>
                <div>
                    <label for="investigationapproved">তদন্ত সম্পন্ন এপ্রুভ</label>
                    <input type="number" name="investigationapproved" id="investigationapproved" value="<?php echo htmlentities($investigationApproved); ?>" required>
                </div>

                <div>
                    <label for="canceled">বাতিল</label>
                    <input type="number" name="canceled" id="canceled" value="<?php echo htmlentities($canceled); ?>" required>
                </div>
                <div>
                    <label for="total">Total</label>
                    <input type="number" name="total" id="total" value="<?php echo htmlentities($total); ?>" required>
                </div>
                <div>
                    <label for="investigationinprogress">মোট,উপজেলা থানা নির্বাচন অফিস কর্তৃক তদন্ত প্রক্রিয়াধীন</label>
                    <input type="number" name="investigationinprogress" id="investigationinprogress" value="<?php echo htmlentities($investigationInProgress); ?>" required>
                </div>
                <div>
                    <label for="awaitingupload">মিশন থেকে আপলোড অপেক্ষাধীন</label>
                    <input type="number" name="awaitingupload" id="awaitingupload" value="<?php echo htmlentities($awaitingUpload); ?>" required>
                </div>
                <div>
                    <label for="uploaded">আপলোড</label>
                    <input type="number" name="uploaded" id="uploaded" value="<?php echo htmlentities($uploaded); ?>" required>
                </div>
                <div>
                    <label for="readyforprinting">প্রিন্ট করার উপযোগী</label>
                    <input type="number" name="readyforprinting" id="readyforprinting" value="<?php echo htmlentities($readyForPrinting); ?>" required>
                </div>
                <div>
                    <label for="printed">প্রিন্টেড</label>
                    <input type="number" name="printed" id="printed" value="<?php echo htmlentities($printed); ?>" required>
                </div>
                <div class="half">
                    <label for="date">তারিখ</label>
                    <input type="date" name="date" id="date" value="<?php echo htmlentities($date); ?>" required>
                </div>
            </div>

            <button type="submit" name="submit" class="btn btn-primary">সংরক্ষন</button>
        </form>
    </div>

    <footer>
        <p>&copy; Project Management System 2024. All Rights Reserved.
            IT Team. IDEA Project (Phase-2)</p>
    </footer>
</body>
</html>
