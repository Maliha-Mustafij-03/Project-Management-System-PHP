<?php
// Start the session at the top of the page
session_start();

// Destroy session variables
session_unset();

// Destroy the session
session_destroy();

// Redirect to the correct index page (pck_updt/index.php)
header('Location: /pck_updt/index.php');  // Absolute path from the root
exit();
?>
