<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

// Check if the user is logged in, if not redirect to the login page
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit; // Stop further execution of the script if not logged in
}

// Check if the user is an admin (ensure user_type is set in the session)
$isAdmin = isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin'; // Admin check

// Get the folder parameter from the URL
if (isset($_GET['folder'])) {
    $folder = urldecode($_GET['folder']);
    
    // Fetch photos from the database for the specified folder
    $photos = [];

    // Prepare SQL query to fetch photos by folder
    $sql = "SELECT * FROM photos WHERE image_url LIKE :folderPath";
    $stmt = $dbh->prepare($sql);
    $folderPath = "uploads/$folder/%";  // Use a pattern to match folder-based photos
    $stmt->bindParam(':folderPath', $folderPath);
    $stmt->execute();
    
    // Fetch all matching photos
    $photos = $stmt->fetchAll();

    // Check if photos are found
    if (empty($photos)) {
        $message = "No photos found in this folder.";
    }
} else {
    $message = "No folder specified.";
    exit;
}

// Function to delete all files and subdirectories inside a folder
function deleteFolderContents($folderPath) {
    // Open the folder
    $files = array_diff(scandir($folderPath), array('.', '..')); // Exclude '.' and '..'
    
    foreach ($files as $file) {
        $filePath = $folderPath . DIRECTORY_SEPARATOR . $file;
        
        // If it's a directory, recursively delete its contents
        if (is_dir($filePath)) {
            deleteFolderContents($filePath); // Recursively delete subdirectories
            rmdir($filePath); // Remove the directory after it's empty
        } else {
            unlink($filePath); // Remove the file
        }
    }
}

// Function to delete the folder
function deleteFolder($folderPath) {
    if (is_dir($folderPath)) {
        // First, delete all contents of the folder
        deleteFolderContents($folderPath);
        
        // Now delete the folder itself
        rmdir($folderPath);
    }
}

// Handle folder deletion if no photos found
if (empty($photos) && isset($_SESSION['alogin']) && isset($_GET['delete_folder']) && $_GET['delete_folder'] == 'true') {
    // Delete folder (make sure the folder is empty)
    $folderPathToDelete = "uploads/" . $folder;

    // Check if folder exists before attempting to delete
    if (is_dir($folderPathToDelete)) {
        // Delete the folder and its contents
        deleteFolder($folderPathToDelete);
        $message = "Folder deleted successfully.";
    } else {
        $message = "Folder does not exist.";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photos in Folder: <?php echo htmlentities($folder); ?></title>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 30px;
            padding-left: 15px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin: 10px 0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .photo-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }

        .photo-item {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }

        .photo-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 2px solid #ddd;
        }

        .photo-item:hover {
            transform: translateY(-5px);
        }

        .photo-item p {
            padding: 10px;
            font-size: 16px;
        }

        .btn {
            margin-top: 10px;
        }

        .btn-primary, .btn-danger {
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            text-align: center;
            display: inline-block;
        }

        .btn-primary {
            background-color: #007bff;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .modal-body img {
            width: 100%;
            max-height: 500px;
            object-fit: contain;
        }

        @media (max-width: 768px) {
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <?php include('includes/sidebarmenu.php'); ?>
    </div>

    <!-- Header -->
    <div class="header">
        <?php include('includes/header.php'); ?>
    </div>

    <!-- Content Area -->
    <div class="content">
        <div class="container">
            <h1>Photos in Folder: <?php echo htmlentities($folder); ?></h1>
            <a href="photo-gallery.php" class="btn btn-primary">Back to Folders</a>

            <?php
            // Display success or error message if present
            if (isset($_GET['message'])) {
                echo "<div class='alert alert-info'>" . htmlentities($_GET['message']) . "</div>";
            }

            if (isset($message)) {
                echo "<p>$message</p>";
            } else {
                ?>
                <div class="photo-gallery">
                    <?php
                    foreach ($photos as $photo) {
                        $photoUrl = $photo['image_url'];  // Get the full URL from the database
                        ?>
                        <div class="photo-item">
                            <img src="<?php echo htmlentities($photoUrl); ?>" alt="<?php echo htmlentities($photo['title']); ?>" data-toggle="modal" data-target="#photoModal" data-img="<?php echo htmlentities($photoUrl); ?>" data-photo-name="<?php echo htmlentities($photo['title']); ?>">
                            <p><?php echo htmlentities($photo['title']); ?></p>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }

            // If no photos are found and the user is an admin, provide the option to delete the folder
            if (empty($photos) && isset($_SESSION['alogin'])) {
                echo '<a href="?folder=' . urlencode($folder) . '&delete_folder=true" class="btn btn-danger" onclick="return confirm(\'Are you sure you want to delete this empty folder?\')">Delete Empty Folder</a>';
            }
            ?>
        </div>
    </div>

    <!-- Modal for Zooming Image -->
    <div class="modal fade" id="photoModal" tabindex="-1" role="dialog" aria-labelledby="photoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="photoModalLabel">View Photo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="" id="modalImage" alt="Photo">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Set the image source in the modal
        $('#photoModal').on('show.bs.modal', function (e) {
            var imageUrl = $(e.relatedTarget).data('img');
            var photoName = $(e.relatedTarget).data('photo-name');
            $('#modalImage').attr('src', imageUrl);
            $('#photoModalLabel').text('Viewing: ' + photoName);
        });
    </script>
</body>
</html>
