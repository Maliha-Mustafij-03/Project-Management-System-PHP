<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Delete functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tblassets WHERE id = :delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    $msg = "Asset Deleted Successfully";
}

// Search functionality
$search = "";
if (isset($_POST['search'])) {
    $search = $_POST['search_query'];
    // Search query across all columns
    $sql = "SELECT * FROM tblassets WHERE 
                SLNumber LIKE :search_query OR 
                OfficeName LIKE :search_query OR 
                OfficeDivision LIKE :search_query OR 
                OfficeZilla LIKE :search_query OR 
                ItemName LIKE :search_query OR 
                VendorName LIKE :search_query OR 
                BrandName LIKE :search_query OR 
                DeliveredQuantity LIKE :search_query OR 
                CurrentQuantity LIKE :search_query OR 
                Condition1 LIKE :search_query OR 
                Condition2 LIKE :search_query OR 
                ReceivedBy LIKE :search_query OR 
                Position LIKE :search_query OR 
                ConditionDate LIKE :search_query";
    $query = $dbh->prepare($sql);
    $query->bindValue(':search_query', '%' . $search . '%');
    $query->execute();
} else {
    // Fetch all assets from the database if no search is done
    $sql = "SELECT * FROM tblassets";
    $query = $dbh->prepare($sql);
    $query->execute();
}

$assets = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        body {
            font-size: 18px; /* Larger text for better readability */
        }

        .table th, .table td {
            font-size: 16px; /* Ensure data in table is big enough */
        }

        .table th {
            background-color: #f8f9fa;
            text-align: center;
        }

        .table td {
            text-align: center;
        }

        .search-bar {
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
        }

        .alert {
            text-align: center;
            font-size: 18px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <?php include('includes/sidebarmenu.php'); ?>

    <div class="container">
        <h1>এ্যাসেট ম্যানেজমেন্ট</h1>
        
        <!-- Search Form -->
        <div class="search-bar">
            <form method="POST" class="form-inline">
                <input type="text" name="search_query" class="form-control" value="<?php echo htmlentities($search); ?>" placeholder="Search by any data">
                <button type="submit" name="search" class="btn btn-primary ml-2 btn-custom">Search</button>
            </form>
        </div>

        <?php if(isset($msg)) { ?>
            <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
        <?php } ?>

        <!-- Assets Table -->
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ক্রম নং</th>
                    <th>অফিসের নাম</th>
                    <th>অফিসের বিভাগের নাম</th>
                    <th>অফিসের জেলা</th>
                    <th>আইটেমের নাম</th>
                    <th>ভেন্ডরের নাম</th>
                    <th>ব্র্যান্ডের নাম</th>
                    <th>ডেলিভারী পরিমাণ</th>
                    <th>বর্তমান পরিমাণ</th>
                    <th>অবস্থা (ভালো)</th>
                    <th>অবস্থা(নষ্ট)</th>
                    <th>গ্রহণকারী</th>
                    <th>পদবী</th>
                    <th>তারিখ</th>
                    <th>অপশন</th>
                    
                </tr>
                
            </thead>
            <tbody>
                <?php foreach($assets as $asset) { ?>
                    <tr>
                        <td><?php echo htmlentities($asset['SLNumber']); ?></td>
                        <td><?php echo htmlentities($asset['OfficeName']); ?></td>
                        <td><?php echo htmlentities($asset['OfficeDivision']); ?></td>
                        <td><?php echo htmlentities($asset['OfficeZilla']); ?></td>
                        <td><?php echo htmlentities($asset['ItemName']); ?></td>
                        <td><?php echo htmlentities($asset['VendorName']); ?></td>
                        <td><?php echo htmlentities($asset['BrandName']); ?></td>
                        <td><?php echo htmlentities($asset['DeliveredQuantity']); ?></td>
                        <td><?php echo htmlentities($asset['CurrentQuantity']); ?></td>
                        <td><?php echo htmlentities($asset['Condition1']); ?></td>
                        <td><?php echo htmlentities($asset['Condition2']); ?></td>
                        <td><?php echo htmlentities($asset['ReceivedBy']); ?></td>
                        <td><?php echo htmlentities($asset['Position']); ?></td>
                        <td><?php echo htmlentities($asset['ConditionDate']); ?></td>

                        <td class="action-buttons">
                            <a href="editasset.php?AssetID=<?php echo $asset['AssetID']; ?>" class="btn btn-warning btn-sm btn-custom">এডিট</a>
                            <?php if(strlen($_SESSION['alogin']) != 0) { ?>
                                <a href="?delete_id=<?php echo $asset['id']; ?>" class="btn btn-danger btn-sm btn-custom" onclick="return confirm('Are you sure you want to delete this asset?')">মুছুন</a>
                            </td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
