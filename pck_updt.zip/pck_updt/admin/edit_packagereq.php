<?php
session_start();
include('includes/config.php');
include('includes/sidebarmenu.php');
// Initialize error and msg variables
$error = $msg = '';

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch package details
    $sqlPackage = "SELECT * FROM tblpackages WHERE PackageId = :id";
    $queryPackage = $dbh->prepare($sqlPackage);
    $queryPackage->bindParam(':id', $id, PDO::PARAM_INT);
    $queryPackage->execute();
    $package = $queryPackage->fetch(PDO::FETCH_OBJ);

    // Check if the package exists
    if (!$package) {
        $error = "Package not found.";
    } else {
        // Fetch conditions for the package
        $sqlConditions = "SELECT * FROM tblconditions WHERE PackageNo = :id";
        $queryConditions = $dbh->prepare($sqlConditions);
        $queryConditions->bindParam(':id', $id, PDO::PARAM_INT);
        $queryConditions->execute();
        $conditions = $queryConditions->fetchAll(PDO::FETCH_OBJ);
    }
}

if (isset($_POST['submit'])) {
    $pno = $_POST['packageno'];
    $description = $_POST['description'];
    $conditions = $_POST['condition'];  // Array of conditions
    $datesofcondition = $_POST['dateofcondition']; // Array of condition dates

    // Update package details
    $sqlUpdatePackage = "UPDATE tblpackages SET PackageNo = :pno, Description = :description WHERE PackageId = :id";
    $queryUpdatePackage = $dbh->prepare($sqlUpdatePackage);
    $queryUpdatePackage->bindParam(':pno', $pno, PDO::PARAM_STR);
    $queryUpdatePackage->bindParam(':description', $description, PDO::PARAM_STR);
    $queryUpdatePackage->bindParam(':id', $id, PDO::PARAM_INT);
    $queryUpdatePackage->execute();

    // Update conditions
    // First, delete existing conditions for the package
    $sqlDeleteConditions = "DELETE FROM tblconditions WHERE PackageNo = :id";
    $queryDeleteConditions = $dbh->prepare($sqlDeleteConditions);
    $queryDeleteConditions->bindParam(':id', $id, PDO::PARAM_INT);
    $queryDeleteConditions->execute();

    // Insert new conditions
    foreach ($conditions as $index => $condition) {
        if (!empty($condition) && !empty($datesofcondition[$index])) {
            $sqlCondition = "INSERT INTO tblconditions (PackageNo, `Condition`, DateOfCondition) 
                             VALUES (:pno, :condition, :dateOfCondition)";
            $queryCondition = $dbh->prepare($sqlCondition);
            $queryCondition->bindParam(':pno', $id, PDO::PARAM_INT);
            $queryCondition->bindParam(':condition', $condition, PDO::PARAM_STR);
            $queryCondition->bindParam(':dateOfCondition', $datesofcondition[$index], PDO::PARAM_STR);
            $queryCondition->execute();
        }
    }

    // Set success message in session
    $_SESSION['msg'] = "Conditions updated successfully";

    // Redirect to the previous page
    header('Location: ' . $_SERVER['HTTP_REFERER']); // Redirects to the referring page
    exit();
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>NCS-GD | Edit Package</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <script>
        // Function to add a new condition and date input row
        function addCondition() {
            var container = document.getElementById('conditionsContainer');
            var row = document.createElement('div');
            row.className = 'detail-row';

            // Create new text input for condition
            var conditionInput = document.createElement('input');
            conditionInput.type = 'text';
            conditionInput.name = 'condition[]';
            conditionInput.className = 'form-control1';
            conditionInput.placeholder = 'Condition Description';
            row.appendChild(conditionInput);

            // Create new date input for the condition date
            var dateInput = document.createElement('input');
            dateInput.type = 'date';
            dateInput.name = 'dateofcondition[]';
            dateInput.className = 'form-control1';
            row.appendChild(dateInput);

            // Append the new row to the container
            container.appendChild(row);
        }

        // Function to remove the last added condition and date input row
        function removeCondition() {
            var container = document.getElementById('conditionsContainer');
            
            // Ensure at least one condition row remains
            if (container.children.length > 1) {
                container.removeChild(container.lastChild);
            }
        }
    </script>
</head>
<body>
    <div class="page-container">
        <!-- Sidebar and header -->
        <?php include('includes/header.php'); ?>
        <div class="left-content">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">Home</a><i class="fa fa-angle-right"></i>Edit Description</li>
            </ol>
            <h3>Edit Description</h3>

            <?php
            // Display success message from session (if available)
            if (isset($_SESSION['msg'])) {
                echo '<div class="succWrap"><strong>SUCCESS</strong>: ' . htmlentities($_SESSION['msg']) . '</div>';
                unset($_SESSION['msg']);  // Clear the message after it is displayed
            }
            // Display error message if available
            if($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php }
            ?>

            <form class="form-horizontal" name="package" method="post">
                <div class="form-group">
                    <label for="slno" class="col-sm-2 control-label">SL নম্বর</label>
                    <div class="col-sm-8">
                        <!-- Check if SLNo exists in the package -->
                        <?php if (isset($package->SLNo)) { ?>
                            <input type="text" class="form-control1" name="slno" value="<?php echo htmlentities($package->SLNo); ?>" readonly>
                        <?php } else { ?>
                            <input type="text" class="form-control1" name="slno" value="Not Available" readonly>
                        <?php } ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="packageno" class="col-sm-2 control-label">বক্স নাম্বার</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control1" name="packageno" value="<?php echo htmlentities($package->PackageNo); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="description" class="col-sm-2 control-label">বিবরণ</label>
                    <div class="col-sm-8">
                        <textarea class="form-control1" name="description" required><?php echo htmlentities($package->Description); ?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label for="conditions" class="col-sm-2 control-label">শর্তের তারিখ</label>
                    <div class="col-sm-8">
                        <div id="conditionsContainer">
                            <?php 
                            // Ensure that $conditions is an array and contains data before trying to loop over it
                            if (isset($conditions) && count($conditions) > 0) {
                                foreach ($conditions as $condition) {
                                    // Check if both properties exist for each condition
                                    if (isset($condition->Condition) && isset($condition->DateOfCondition)) { ?>
                                        <div class="detail-row">
                                            <!-- Remove 'required' if you want to allow empty values when conditions are not preloaded -->
                                            <input type="text" class="form-control1" name="condition[]" value="<?php echo htmlentities($condition->Condition); ?>" >
                                            <input type="date" class="form-control1" name="dateofcondition[]" value="<?php echo htmlentities($condition->DateOfCondition); ?>">
                                        </div>
                                    <?php } 
                                }
                            } ?>
                        </div>
                        <div class="btn-container">
                            <button type="button" class="btn btn-primary" onclick="addCondition()">নতুন শর্তের তারিখ যোগ করুন</button>
                            <button type="button" class="btn btn-danger" onclick="removeCondition()">পূর্বের শর্তের তারিখ মুছুন</button>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <button type="submit" name="submit" class="btn-primary btn">তৈরী</button>
                        <button type="reset" class="btn-inverse btn">রিসেট</button>
                    </div>
                </div>
            </form>

        </div>
    </div>
</body>
</html>
