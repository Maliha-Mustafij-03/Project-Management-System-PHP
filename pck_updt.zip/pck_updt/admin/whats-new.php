<?php 
session_start();
error_reporting(0);
include('includes/config.php');

// Initialize search query
$searchQuery = '';

// Handle form submission for editing news
if (isset($_POST['submit'])) {
    $newsId = $_POST['news_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $created_at = $_POST['created_at'];  // Added created_at field
    
    $sql = "UPDATE urgent_news SET title=:title, description=:description, created_at=:created_at WHERE id=:newsId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':title', $title, PDO::PARAM_STR);
    $query->bindParam(':description', $description, PDO::PARAM_STR);
    $query->bindParam(':created_at', $created_at, PDO::PARAM_STR);  // Binding created_at
    $query->bindParam(':newsId', $newsId, PDO::PARAM_INT);
    $query->execute();

    echo "<script>alert('PD Sir\'s Commitment updated successfully'); window.location.href='whats-new.php';</script>";
}

// Handle deletion of news
if (isset($_POST['delete'])) {
    $newsId = $_POST['news_id'];
    
    $sql = "DELETE FROM urgent_news WHERE id=:newsId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':newsId', $newsId, PDO::PARAM_INT);
    $query->execute();

    echo "<script>alert('PD Sir\'s Commitment deleted successfully'); window.location.href='whats-new.php';</script>";
}

// Handle search functionality
if (isset($_POST['search'])) {
    $searchQuery = $_POST['search_query'];
}

// Modify SQL query based on search
$sql = "SELECT id, title, description, created_at FROM urgent_news WHERE title LIKE :searchQuery OR description LIKE :searchQuery ORDER BY created_at DESC";
$query = $dbh->prepare($sql);
$query->bindValue(':searchQuery', '%' . $searchQuery . '%', PDO::PARAM_STR);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);

?>
<!DOCTYPE HTML>
<html>
<head>
    <title>What's New - PD Sir's Commitment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .page-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar-menu {
            background: #003366;
            color: #fff;
            padding: 10px;
            width: 250px;
            height: 100vh;
            position: fixed;
        }
        .page-content {
            margin-left: 250px; /* Adjust for sidebar width */
            padding: 20px;
            flex: 1;
        }
        .header-main {
            background-color: #003366;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .breadcrumb {
            background-color: #f5f5f5;
            padding: 10px 15px;
            margin-bottom: 20px;
        }
        .breadcrumb-item a {
            color: #003366;
        }
        .urgent-news {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 20px;
            border-left: 5px solid #003366;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .urgent-news input {
            padding: 5px 10px;
            font-size: 14px;
            border: 1px solid #003366;
            border-radius: 5px;
            width: 200px;
        }
        .news-item {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            border-radius: 5px;
        }
        .news-content h5 {
            font-size: 18px;
            font-weight: bold;
        }
        .news-content p {
            font-size: 14px;
        }
        .edit-form input, .edit-form textarea {
            width: 100%;
            margin-bottom: 10px;
            padding: 10px;
            font-size: 14px;
        }
        .edit-form button {
            background-color: #003366;
            color: #fff;
            padding: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 3px;
        }
        .edit-form button:hover {
            background-color: #002244;
        }
        .delete-btn, .btn-primary, .cancel-btn {
            padding: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 3px;
        }
        .delete-btn {
            background-color: #cc0000;
            color: #fff;
            margin-left: 10px;
        }
        .delete-btn:hover {
            background-color: #990000;
        }
        .btn-primary {
            background-color: #003366;
            color: #fff;
        }
        .btn-primary:hover {
            background-color: #002244;
        }
        .cancel-btn {
            background-color: #cccccc;
            color: #333;
            margin-left: 10px;
        }
        .cancel-btn:hover {
            background-color: #999999;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Sidebar -->
        <?php include('includes/sidebarmenu.php'); ?>

        <!-- Page Content -->
        <div class="page-content">
            <!-- Header -->
            <?php include('includes/header.php'); ?>

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">Home</a><i class="fa fa-angle-right"></i>PD Sir's Commitment</li>
            </ol>

            <!-- Urgent News Section -->
            <div class="urgent-news">
                <span>PD Sir's Commitment</span>
                <!-- Search Form -->
                <form method="POST" style="display: flex; align-items: center;">
                    <input type="text" name="search_query" placeholder="Search by Title or Description" value="<?php echo htmlentities($searchQuery); ?>">
                    <button type="submit" name="search" class="btn btn-primary" style="margin-left: 10px;">Search</button>
                </form>
            </div>

            <!-- News Items -->
            <?php 
            if ($query->rowCount() > 0) {
                foreach ($results as $result) {
                    ?>
                    <div class="news-item">
                        <div class="news-content">
                            <h5><?php echo htmlentities($result->title); ?></h5>
                            <p><?php echo htmlentities($result->description); ?></p>

                            <button class="btn btn-primary" data-toggle="collapse" data-target="#editForm<?php echo $result->id; ?>">Edit</button>

                            <?php if (isset($_SESSION['alogin'])) { // Check if user is admin ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="news_id" value="<?php echo $result->id; ?>">
                                    <button type="submit" name="delete" class="delete-btn">Delete</button>
                                </form>
                            <?php } ?>

                            <div id="editForm<?php echo $result->id; ?>" class="collapse edit-form">
                                <form method="POST">
                                    <input type="hidden" name="news_id" value="<?php echo $result->id; ?>">

                                    <!-- Add created_at field before title -->
                                    <label for="created_at">Date</label>
                                    <input type="date" name="created_at" value="<?php echo date('Y-m-d', strtotime($result->created_at)); ?>" required>

                                    <input type="text" name="title" value="<?php echo htmlentities($result->title); ?>" required>

                                    <textarea name="description" required><?php echo htmlentities($result->description); ?></textarea>

                                    <button type="submit" name="submit">Update</button>
                                    <button type="button" class="cancel-btn" onclick="window.location.href='whats-new.php';">Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php 
                }
            } else {
                echo "<p>No PD Sir's Commitment found for your search.</p>";
            }
            ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>

    <!-- JavaScript -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.btn-primary').click(function(){
                var target = $(this).data('target');
                $('.collapse').not(target).collapse('hide');
                $(target).collapse('show');
            });
        });
    </script>
</body>
</html>
