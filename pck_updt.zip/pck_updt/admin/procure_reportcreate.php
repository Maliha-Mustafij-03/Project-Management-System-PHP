<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Initialize variables for messages
$error = "";
$msg = "";

// Handle form submission only when the submit button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $total_packages = $_POST['total_packages'];
    $previous_contracts = $_POST['previous_contracts'];
    $signed_contracts = $_POST['signed_contracts'];
    $implementation_progress_rate = $_POST['implementation_progress_rate'];
    $packages_under_evaluation = $_POST['packages_under_evaluation'];
    $remaining_packages = $_POST['remaining_packages'];

    // Check if all fields are filled
    if (empty($total_packages) || empty($previous_contracts) || empty($signed_contracts) || empty($implementation_progress_rate) || empty($packages_under_evaluation) || empty($remaining_packages)) {
        $error = "All fields are required!";
    } else {
        // Prepare SQL query to insert data into the table
        $sql = "INSERT INTO procurement_plan (total_packages, previous_contracts, signed_contracts, implementation_progress_rate, packages_under_evaluation, remaining_packages)
                VALUES (:total_packages, :previous_contracts, :signed_contracts, :implementation_progress_rate, :packages_under_evaluation, :remaining_packages)";
        
        // Prepare and bind parameters
        $query = $dbh->prepare($sql);
        $query->bindParam(':total_packages', $total_packages);
        $query->bindParam(':previous_contracts', $previous_contracts);
        $query->bindParam(':signed_contracts', $signed_contracts);
        $query->bindParam(':implementation_progress_rate', $implementation_progress_rate);
        $query->bindParam(':packages_under_evaluation', $packages_under_evaluation);
        $query->bindParam(':remaining_packages', $remaining_packages);
        
        try {
            // Execute the query
            $query->execute();
            $msg = "Procurement progress data successfully inserted.";

            // Redirect to procure_reportmanage page after successful insertion
            header("Location: procure_reportmanage.php");
            exit; // Make sure to exit after redirecting
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Fetch all records to display
$sql = "SELECT * FROM procurement_plan";
$query = $dbh->prepare($sql);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);
?>
 <?php include('includes/sidebarmenu.php'); ?>
  <?php include('includes/header.php'); ?>
  
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procurement Progress Report</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        /* Allow the textarea to be resized both horizontally and vertically */
        textarea {
            resize: both; /* This allows resizing */
            width: 100%;   /* Full width */
            min-height: 100px;  /* Minimum height */
        }
        .container {
            margin-top: 40px;
            padding-left: 200px; /* Adjust based on sidebar width */sssss
        }
    </style>
</head>
<body>
    <div class="container">
        <h3 class="mt-5">Procurement Progress Report</h3>

        <!-- Display error or success message -->
        <?php if($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php elseif($msg): ?>
            <div class="alert alert-success"><?php echo $msg; ?></div>
        <?php endif; ?>

        <!-- Form to insert data -->
        <form method="POST" class="form-horizontal mt-4">
            <div class="form-group">
                <label for="total_packages" class="control-label col-sm-2">২০২৪-২৫  ক্রয় পরিকল্পনায় অন্তর্ভুক্ত মোট প্যাকেজ সংখ্যা</label>
                <div class="col-sm-8">
                    <textarea name="total_packages" class="form-control" id="total_packages"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="previous_contracts" class="control-label col-sm-2">পূর্বে চুক্তি সম্পন্ন প্যাকেজ</label>
                <div class="col-sm-8">
                    <textarea name="previous_contracts" class="form-control" id="previous_contracts"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="signed_contracts" class="control-label col-sm-2">২০২৪-২৫ চুক্তি সম্পাদিত প্যাকেজ সংখ্যা</label>
                <div class="col-sm-8">
                    <textarea name="signed_contracts" class="form-control" id="signed_contracts"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="implementation_progress_rate" class="control-label col-sm-2">বাস্তবায়ন অগ্রগতির হার (%)</label>
                <div class="col-sm-8">
                    <textarea name="implementation_progress_rate" class="form-control" id="implementation_progress_rate"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="packages_under_evaluation" class="control-label col-sm-2">দরপত্র প্রক্রিয়াধীন প্যাকেজ সংখ্যা (মূল্যায়ন চলমান, NOA, ইত্যাদি)*</label>
                <div class="col-sm-8">
                    <textarea name="packages_under_evaluation" class="form-control" id="packages_under_evaluation"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="remaining_packages" class="control-label col-sm-2">অবশিষ্ট প্যাকেজসমূহ</label>
                <div class="col-sm-8">
                    <textarea name="remaining_packages" class="form-control" id="remaining_packages"></textarea>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-8 col-sm-offset-2">
                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>

    </div>
</body>
</html> 
