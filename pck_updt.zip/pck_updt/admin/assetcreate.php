<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Handle asset creation
if (isset($_POST['submit'])) {
    $slno = $_POST['slno'];
    $officeName = $_POST['officeName'];
    $officeDivision = $_POST['officeDivision'];
    $officeZilla = $_POST['officeZilla'];

    $items = $_POST['itemname']; // Array of item names
    $vendors = $_POST['vendorname']; // Array of vendor names
    $brands = $_POST['brandname']; // Array of brand names
    $deliveredQuantities = $_POST['deliveredquantity']; // Array of delivered quantities
    $currentQuantities = $_POST['currentquantity']; // Array of current quantities
    $condition1s = $_POST['condition1']; // Array of condition 1
    $quantities1 = $_POST['quantity1']; // Array of quantities 1
    $condition2s = $_POST['condition2']; // Array of condition 2
    $quantities2 = $_POST['quantity2']; // Array of quantities 2
    $receivedBy = $_POST['receivedBy']; // Array of received by
    $positions = $_POST['position']; // Array of positions
    $conditionDates = $_POST['dateofcondition']; // Array of condition dates

    // Insert each asset (item + condition + quantities + received by) into tblassets
    foreach ($items as $index => $itemName) {
        // Insert the asset with nullable fields
        $sql = "INSERT INTO tblassets 
                        (SLNumber, OfficeName, OfficeDivision, OfficeZilla, ItemName, VendorName, BrandName, DeliveredQuantity, CurrentQuantity, Condition1, Quantity1, Condition2, Quantity2, ReceivedBy, Position, ConditionDate) 
                    VALUES 
                        (:slno, :officeName, :officeDivision, :officeZilla, :itemName, :vendorName, :brandName, :deliveredQuantity, :currentQuantity, :condition1, :quantity1, :condition2, :quantity2, :receivedBy, :position, :conditionDate)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':slno', $slno, PDO::PARAM_STR);
        $query->bindParam(':officeName', $officeName, PDO::PARAM_STR);
        $query->bindParam(':officeDivision', $officeDivision, PDO::PARAM_STR);
        $query->bindParam(':officeZilla', $officeZilla, PDO::PARAM_STR);
        $query->bindParam(':itemName', $itemName, PDO::PARAM_STR);
        $query->bindParam(':vendorName', $vendors[$index], PDO::PARAM_STR);
        $query->bindParam(':brandName', $brands[$index], PDO::PARAM_STR);
        $query->bindParam(':deliveredQuantity', $deliveredQuantities[$index], PDO::PARAM_INT);
        $query->bindParam(':currentQuantity', $currentQuantities[$index], PDO::PARAM_INT);
        $query->bindParam(':condition1', $condition1s[$index], PDO::PARAM_STR);
        $query->bindParam(':quantity1', $quantities1[$index], PDO::PARAM_INT);
        $query->bindParam(':condition2', $condition2s[$index], PDO::PARAM_STR);
        $query->bindParam(':quantity2', $quantities2[$index], PDO::PARAM_INT);
        $query->bindParam(':receivedBy', $receivedBy[$index], PDO::PARAM_STR);
        $query->bindParam(':position', $positions[$index], PDO::PARAM_STR);
        $query->bindParam(':conditionDate', $conditionDates[$index], PDO::PARAM_STR);
        $query->execute();
    }

    $msg = "Asset(s) Created Successfully";
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Admin Asset Creation</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
<style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
}

.container {
    margin-left: 250px; /* Adjust this value based on the sidebar width */
    padding: 20px;
    width: calc(100% - 250px); /* Take full width minus sidebar */
    box-sizing: border-box;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px; /* Sidebar width */
    height: 100vh; /* Full height */
    background-color: #f8f9fa;
    padding: 20px;
    box-sizing: border-box;
}

.main-content {
    margin-left: 250px; /* Ensure content does not overlap the sidebar */
    padding: 20px;
    width: calc(100% - 250px); /* Full width minus sidebar */
    box-sizing: border-box;
}

.detail-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.detail-row input {
    margin-right: 10px;
    margin-bottom: 10px;
    padding: 12px;
    font-size: 16px;
    width: 220px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.detail-row input[type="date"] {
    width: 250px;
}

.form-control1 {
    font-size: 16px;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
}

.form-control1:focus {
    outline: none;
    border-color: #007bff;
}

.btn-container {
    margin-top: 20px;
    margin-bottom: 20px;
    text-align: center;
}

</style>
    <script>
        function addCondition() {
            var container = document.getElementById('conditionsContainer');
            var row = document.createElement('div');
            row.className = 'detail-row';

            var itemInput = document.createElement('input');
            itemInput.type = 'text';
            itemInput.name = 'itemname[]';
            itemInput.className = 'form-control1';
            itemInput.placeholder = 'আইটেম এর নাম';
            row.appendChild(itemInput);

            var vendorInput = document.createElement('input');
            vendorInput.type = 'text';
            vendorInput.name = 'vendorname[]';
            vendorInput.className = 'form-control1';
            vendorInput.placeholder = 'ভেন্ডরের নাম';
            row.appendChild(vendorInput);

            var brandInput = document.createElement('input');
            brandInput.type = 'text';
            brandInput.name = 'brandname[]';
            brandInput.className = 'form-control1';
            brandInput.placeholder = 'ব্র্যান্ডের নাম';
            row.appendChild(brandInput);

            var deliveredQtyInput = document.createElement('input');
            deliveredQtyInput.type = 'number';
            deliveredQtyInput.name = 'deliveredquantity[]';
            deliveredQtyInput.className = 'form-control1';
            deliveredQtyInput.placeholder = 'ডেলিভারীর পরিমাণ';
            row.appendChild(deliveredQtyInput);

            var currentQtyInput = document.createElement('input');
            currentQtyInput.type = 'number';
            currentQtyInput.name = 'currentquantity[]';
            currentQtyInput.className = 'form-control1';
            currentQtyInput.placeholder = 'বর্তমান পরিমাণ';
            row.appendChild(currentQtyInput);

            var condition1Input = document.createElement('input');
            condition1Input.type = 'text';
            condition1Input.name = 'condition1[]';
            condition1Input.className = 'form-control1';
            condition1Input.placeholder = 'বর্তমান অবস্থা (ভালো)';
            row.appendChild(condition1Input);

            var quantity1Input = document.createElement('input');
            quantity1Input.type = 'number';
            quantity1Input.name = 'quantity1[]';
            quantity1Input.className = 'form-control1';
            quantity1Input.placeholder = 'পরিমান(ভালো)';
            row.appendChild(quantity1Input);

            var condition2Input = document.createElement('input');
            condition2Input.type = 'text';
            condition2Input.name = 'condition2[]';
            condition2Input.className = 'form-control1';
            condition2Input.placeholder = 'বর্তমান অবস্থা (নষ্ট)';
            row.appendChild(condition2Input);

            var quantity2Input = document.createElement('input');
            quantity2Input.type = 'number';
            quantity2Input.name = 'quantity2[]';
            quantity2Input.className = 'form-control1';
            quantity2Input.placeholder = 'পরিমান(নষ্ট)';
            row.appendChild(quantity2Input);

            var receivedByInput = document.createElement('input');
            receivedByInput.type = 'text';
            receivedByInput.name = 'receivedBy[]';
            receivedByInput.className = 'form-control1';
            receivedByInput.placeholder = 'গ্রহনকারী';
            row.appendChild(receivedByInput);

            var positionInput = document.createElement('input');
            positionInput.type = 'text';
            positionInput.name = 'position[]';
            positionInput.className = 'form-control1';
            positionInput.placeholder = 'পদবী';
            row.appendChild(positionInput);

            var conditionDateInput = document.createElement('input');
            conditionDateInput.type = 'date';
            conditionDateInput.name = 'dateofcondition[]';
            conditionDateInput.className = 'form-control1';
            row.appendChild(conditionDateInput);

            container.appendChild(row);
        }

        function removeCondition() {
            var container = document.getElementById('conditionsContainer');
            if (container.children.length > 1) {
                container.removeChild(container.lastChild);
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>এ্যাসেট তৈরি করুন</h1>
        <form method="POST">
            <div class="form-group">
                 <?php include('includes/header.php'); ?>
                <label for="slno">ক্রম নং</label>
                <input type="text" class="form-control1" name="slno" id="slno" required>
            </div>
            <div class="form-group">
                <label for="officeName">অফিসের নাম</label>
                <input type="text" class="form-control1" name="officeName" id="officeName" required>
            </div>
            <div class="form-group">
                <label for="officeDivision">অফিসের বিভাগের নাম</label>
                <input type="text" class="form-control1" name="officeDivision" id="officeDivision" required>
            </div>
            <div class="form-group">
                <label for="officeZilla">অফিসের জেলা</label>
                <input type="text" class="form-control1" name="officeZilla" id="officeZilla" required>
            </div>

            <div id="conditionsContainer">
                <!-- Dynamic condition rows will be added here -->
            </div>

            <div class="btn-container">
                <button type="button" class="btn btn-info" onclick="addCondition()">বিস্তারিত তথ্য যোগ</button>
                <br> <br>
                <button type="submit" name="submit" class="btn btn-success">সাবমিট</button>
            </div>
        </form>
    </div>
</body>
</html>

    </div>
    <?php include('includes/sidebarmenu.php'); ?>
    <div class="clearfix"></div>     
</div>

</body>
</html>
