<?php
session_start();

// Include configuration
include('includes/config.php');

// Initialize error and success messages
$error = "";
$msg = "";

// Check if user is logged in as admin or user
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) { 
    // If neither is set, redirect to login page (index.php)
    header('location:index.php');
    exit;
}


// Get the distribution ID from the URL
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];

    // Fetch the distribution and conditions for this ID
    $sql = "SELECT s.id, s.serial_no, s.country_name, c.card_number, c.remaining, c.condition_date 
            FROM smart_card_distribution s
            LEFT JOIN smart_card_conditions c ON s.id = c.distribution_id
            WHERE s.id = :edit_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':edit_id', $edit_id, PDO::PARAM_INT);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_ASSOC);

    // If no record is found, show an error
    if (!$results) {
        $error = "এই স্মার্ট কার্ড বিতরণ রেকর্ড পাওয়া যায়নি!";
    }
}

// Handle the form submission to update the record
if (isset($_POST['submit'])) {
    // Get form data
    $serialNo = $_POST['serialno'];  // Serial number (ক্রম নং)
    $countryName = $_POST['countryname']; // Country name (দেশের নাম)
    $cardNumbers = $_POST['cardnumber'];  // Array of printed card numbers
    $remaining = $_POST['remaining'];  // Array of remaining number for printing
    $datesOfCondition = $_POST['dateofcondition']; // Array of condition dates

    // Update smart card distribution information
    $sql = "UPDATE smart_card_distribution SET serial_no = :serialNo, country_name = :countryName 
            WHERE id = :edit_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':serialNo', $serialNo, PDO::PARAM_STR);
    $query->bindParam(':countryName', $countryName, PDO::PARAM_STR);
    $query->bindParam(':edit_id', $edit_id, PDO::PARAM_INT);

    if ($query->execute()) {
        // Delete existing conditions for this distribution ID before inserting new ones
        $sqlDelete = "DELETE FROM smart_card_conditions WHERE distribution_id = :distributionId";
        $queryDelete = $dbh->prepare($sqlDelete);
        $queryDelete->bindParam(':distributionId', $edit_id, PDO::PARAM_INT);
        $queryDelete->execute();

        // Insert new or updated conditions
        foreach ($cardNumbers as $index => $cardNumber) {
            if (!empty($cardNumber) && !empty($datesOfCondition[$index]) && !empty($remaining[$index])) {
                $sqlInsert = "INSERT INTO smart_card_conditions (distribution_id, card_number, remaining, condition_date) 
                              VALUES (:distributionId, :cardNumber, :remaining, :conditionDate)";
                $queryInsert = $dbh->prepare($sqlInsert);
                $queryInsert->bindParam(':distributionId', $edit_id, PDO::PARAM_INT);
                $queryInsert->bindParam(':cardNumber', $cardNumber, PDO::PARAM_INT);
                $queryInsert->bindParam(':remaining', $remaining[$index], PDO::PARAM_INT);
                $queryInsert->bindParam(':conditionDate', $datesOfCondition[$index], PDO::PARAM_STR);
                $queryInsert->execute();
            }
        }

        $msg = "ডেটা সফলভাবে আপডেট হয়েছে!";
    } else {
        $error = "ডেটা আপডেট করতে সমস্যা হয়েছে, আবার চেষ্টা করুন।";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Edit Smart Card Distribution</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .form-group .control-label {
            font-weight: bold;
        }
        .form-control1 {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
        }
        .btn-container {
            margin-top: 10px;
        }
        .detail-row {
            display: flex;
            margin-bottom: 10px;
        }
        .detail-row input {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <div class="clearfix"> </div>    
            </div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>স্মার্ট কার্ড বিতরণ এডিট করুন </li>
            </ol>
            <div class="grid-form">
                <div class="grid-form1">
                    <h3>স্মার্ট কার্ড বিতরণ তথ্য এবং শর্ত সংশোধন করুন</h3>
                    <?php if ($error) { ?>
                        <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
                    <?php } else if ($msg) { ?>
                        <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
                    <?php } ?>
                    <div class="tab-content">
                        <div class="tab-pane active" id="horizontal-form">
                            <form class="form-horizontal" name="smartcard" method="post">
                                <div class="form-group">
                                    <label for="serialno" class="col-sm-2 control-label">ক্রম নং</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control1" name="serialno" id="serialno" value="<?php echo htmlentities($results[0]['serial_no']); ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="countryname" class="col-sm-2 control-label">দেশের নাম</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control1" name="countryname" id="countryname" value="<?php echo htmlentities($results[0]['country_name']); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="condition" class="col-sm-2 control-label">বিস্তারিত</label>
                                    <div class="col-sm-8">
                                        <div id="conditionsContainer">
                                            <?php foreach ($results as $row) { ?>
                                                <div class="detail-row">
                                                    <input type="number" class="form-control1" name="cardnumber[]" value="<?php echo htmlentities($row['card_number']); ?>" placeholder="কার্ডের সংখ্যা(পাঠানো হয়ে গেছে)" required>
                                                    <input type="number" class="form-control1" name="remaining[]" value="<?php echo htmlentities($row['remaining']); ?>" placeholder="মুদ্রন বাকি কার্ডের সংখ্যা" required>
                                                    <input type="date" class="form-control1" name="dateofcondition[]" value="<?php echo htmlentities($row['condition_date']); ?>" required>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="btn-container">
                                            <button type="button" class="btn btn-primary" onclick="addCondition()">নতুন যোগ করুন</button>
                                            <button type="button" class="btn btn-danger" onclick="removeCondition()">মুছুন</button>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button type="submit" name="submit" class="btn-primary btn">আপডেট করুন</button>
                                        <button type="reset" class="btn-inverse btn">রিসেট</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('includes/footer.php'); ?>
        </div>
        <?php include('includes/sidebarmenu.php'); ?>
    </div>

    <script>
        function addCondition() {
            var container = document.getElementById('conditionsContainer');
            var row = document.createElement('div');
            row.className = 'detail-row';
            
            var cardNumberInput = document.createElement('input');
            cardNumberInput.type = 'number';
            cardNumberInput.name = 'cardnumber[]';
            cardNumberInput.className = 'form-control1';
            cardNumberInput.placeholder = 'কার্ডের সংখ্যা(পাঠানো হয়ে গেছে)';
            row.appendChild(cardNumberInput);

            var remainingInput = document.createElement('input');
            remainingInput.type = 'number';
            remainingInput.name = 'remaining[]';
            remainingInput.className = 'form-control1';
            remainingInput.placeholder = 'মুদ্রন বাকি কার্ডের সংখ্যা';
            row.appendChild(remainingInput);

            var dateOfConditionInput = document.createElement('input');
            dateOfConditionInput.type = 'date';
            dateOfConditionInput.name = 'dateofcondition[]';
            dateOfConditionInput.className = 'form-control1';
            row.appendChild(dateOfConditionInput);

            container.appendChild(row);
        }

        function removeCondition() {
            var container = document.getElementById('conditionsContainer');
            if (container.children.length > 1) {
                container.removeChild(container.lastChild);
            }
        }
    </script>
</body>
</html>
