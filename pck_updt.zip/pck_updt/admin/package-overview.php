<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}

// Code for deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    $packageId = intval($_GET['id']);
    $sql = "DELETE FROM package_overview WHERE id=:id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $packageId, PDO::PARAM_INT);
    
    if ($query->execute()) {
        $msg = "Package Deleted Successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Search functionality
$searchQuery = '';
if (isset($_POST['search'])) {
    $searchQuery = $_POST['search'];
}

$sql = "SELECT * FROM package_overview WHERE package_no LIKE :searchQuery 
        OR details LIKE :searchQuery 
        OR current_condition LIKE :searchQuery 
        OR specification_date_transmission_verification LIKE :searchQuery 
        OR specification_target LIKE :searchQuery 
        OR specification_date_dispatch_procurement LIKE :searchQuery";
$query = $dbh->prepare($sql);
$query->bindValue(':searchQuery', '%'.$searchQuery.'%', PDO::PARAM_STR);
$query->execute();
$packages = $query->fetchAll(PDO::FETCH_OBJ);

?>

<!DOCTYPE HTML>
<html>
<head>
    <title>NCS-GD | Manage Packages</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 16px;
        }

        .errorWrap {
            padding: 15px;
            margin: 10px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            color: #dd3d36;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
        }

        .succWrap {
            padding: 15px;
            margin: 10px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            color: #5cb85c;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
        }

        table.table-bordered {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table.table-bordered th,
        table.table-bordered td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
            color: #000; /* Deep black text color */
            font-weight: bold; /* Make all table data bold */
            font-size: 16px; /* Increased font size */
        }

        table.table-bordered thead th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            border-bottom: 2px solid #0056b3;
        }

        table.table-bordered tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table.table-bordered tbody tr:hover {
            background-color: #e0e0e0;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin: 5px 0;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .header-main.fixed {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        /* Aligning search form and button */
        .search-container {
            margin-bottom: 20px;
            margin-top: 20px;
        }

        .search-container input {
            width: 60%;
            display: inline-block;
            padding: 10px;
            font-size: 16px;
        }

        .search-container button {
            padding: 10px 20px;
            font-size: 16px;
            display: inline-block;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }

        /* Footer Styling */
        footer {
            background-color: #f1f1f1;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
            width: 100%;
        }

    </style>

</head> 
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <div class="clearfix"> </div>  
            </div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>ম্যানেজ প্যাকেজ</li>
            </ol>
            <div class="container">
                <h2>"স্পেসিফিকেশন কমিটি দ্বারা স্পেসিফিকেশন, যাচাই কমিটিতে প্রেরণের তারিখ এবং ক্রয় (ম্যানেজ ওভারভিউ)"</h2>

                <!-- Search Form -->
                <div class="search-container">
                    <form method="POST" action="">
                        <input type="text" name="search" class="form-control" placeholder="Search by Package No, Details, Current Condition, specification_target,Specification Dates" value="<?php echo htmlentities($searchQuery); ?>">
                        <button type="submit">অনুসন্ধান</button>
                    </form>
                </div>

                <?php if($error) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
                <?php } else if($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
                <?php } ?>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>প্যাকেজ নং</th>
                            <th>বিস্তারিত</th>
                            <th>ক্রয়পদ্ধতি</th>
                            <th>স্পেসিফিকেশনের লক্ষ্যমাত্রা</th>
                            <th>স্পেসিফিকেশন চূড়ান্তকরণ প্রাপ্তির তারিখ</th>
                            <th>ক্রয়ের জন্য স্পেসিফিকেশন প্রেরণের  তারিখ</th>
                            <th>অ্যাকশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $cnt = 1;
                        foreach($packages as $result) {
                        ?>
                        <tr>
                            <td><?php echo htmlentities($cnt); ?></td>
                            <td><?php echo htmlentities($result->package_no); ?></td>
                            <td><?php echo htmlentities($result->details); ?></td>
                            <td><?php echo htmlentities($result->current_condition); ?></td>
                             <td><?php echo htmlentities($result->specification_target); ?></td>

                            <td><?php echo htmlentities($result->specification_date_transmission_verification); ?></td>
                            <td><?php echo htmlentities($result->specification_date_dispatch_procurement); ?></td>
                            <td>
                                <a href="update-package1.php?id=<?php echo htmlentities($result->id); ?>" class="btn btn-primary btn-block">এডিট</a><br />
                                <?php
                                if (isset($_SESSION['alogin'])) {
                                    echo '<a href="package-overview.php?action=delete&id=' . htmlentities($result->id) . '" 
                                        onclick="return confirm(\'Do you really want to delete?\');" 
                                        class="btn btn-danger btn-block">মুছুন</a>';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php $cnt++; } ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <?php include('includes/sidebarmenu.php'); ?>
        <div class="clearfix"></div>     
    </div>

    <!-- Footer -->
    <footer>
         <p class="wow zoomIn animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
            NCS/GD-Tender Package Management System 2024. All Rights Reserved.<br>
            Database Administration Team. IDEA Project (Phase-2)
        </p>
    </footer>
    
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
