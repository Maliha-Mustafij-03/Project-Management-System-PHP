<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if neither admin nor user is logged in
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
} else { 
    // Fetch user details if 'uid' is provided
    $uid = isset($_GET['uid']) ? $_GET['uid'] : '';
    if ($uid == '') {
        header('location:manage-users.php');
        exit;
    }
    
    // Fetch user data for editing
    $sql = "SELECT * FROM tblusers WHERE EmailId = :uid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':uid', $uid, PDO::PARAM_STR);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_OBJ);

    if (!$result) {
        header('location:manage-users.php');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Update user information
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];

        // Update the user details
        $sql = "UPDATE tblusers SET FullName = :name, MobileNumber = :mobile, EmailId = :email WHERE EmailId = :currentEmail";
        $query = $dbh->prepare($sql);
        $query->bindParam(':name', $name, PDO::PARAM_STR);
        $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':currentEmail', $uid, PDO::PARAM_STR);
        $query->execute();

        $msg = "User details updated successfully";
    }

    // Optionally, you can display the success message
    if (isset($msg)) {
        echo "<div class='alert alert-success'>{$msg}</div>";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>NCS | Edit User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-2.1.4.min.js"></script>

<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

</head> 
<body>
    <div class="page-container">
        <!--/content-inner-->
        <div class="left-content">
            <div class="mother-grid-inner">
                <!--header start here-->
                <?php include('includes/header.php');?>
                <div class="clearfix"> </div>    
            </div>
            <!--header end here-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Edit User</li>
            </ol>
            <div class="agile-grids">    
                <div class="agile-tables">
                    <div class="w3l-table-info">
                        <h2>Edit User</h2>
                        <?php if (isset($msg)) { ?><div class="alert alert-success" role="alert"><?php echo htmlentities($msg); ?></div><?php } ?>
                        <form method="post">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlentities($result->FullName); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="mobile">Mobile No.</label>
                                <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo htmlentities($result->MobileNumber); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Id</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlentities($result->EmailId); ?>" required readonly>
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
                <!-- script-for sticky-nav -->
                <script>
                $(document).ready(function() {
                     var navoffeset=$(".header-main").offset().top;
                     $(window).scroll(function(){
                        var scrollpos=$(window).scrollTop(); 
                        if(scrollpos >=navoffeset){
                            $(".header-main").addClass("fixed");
                        }else{
                            $(".header-main").removeClass("fixed");
                        }
                     });
                });
                </script>
                <!-- /script-for sticky-nav -->
                <!--inner block start here-->
                <div class="inner-block">
                </div>
                <!--inner block end here-->
                <!--copy rights start here-->
                <?php include('includes/footer.php');?>
                <!--COPY rights end here-->
            </div>
        </div>
        <!--/sidebar-menu-->
        <?php include('includes/sidebarmenu.php');?>
        <div class="clearfix"></div>        
    </div>
    <!--js -->
    <!-- Bootstrap and jQuery -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
   
</body>
</html>
<?php  ?>
