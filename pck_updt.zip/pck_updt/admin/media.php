<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}

// Check if form is submitted for creating a new media report
if (isset($_POST['create'])) {
    $reportDate = $_POST['report_date'];
    $division = $_POST['division'];
    $media = $_POST['media'];
    $topic = $_POST['topic'];

    // Handling PDF file upload
    $attachments = '';
    if (!empty($_FILES['attachments']['name'][0])) {
        $uploadedFiles = [];
        foreach ($_FILES['attachments']['tmp_name'] as $key => $tmpName) {
            $fileName = $_FILES['attachments']['name'][$key];
            $fileTmpName = $_FILES['attachments']['tmp_name'][$key];
            $filePath = 'uploads/' . basename($fileName);

            // Check if file is a PDF
            if (pathinfo($fileName, PATHINFO_EXTENSION) == 'pdf') {
                move_uploaded_file($fileTmpName, $filePath);
                $uploadedFiles[] = $filePath;
            }
        }
        $attachments = implode(',', $uploadedFiles); // Store comma-separated paths
    }

    // Insert new media report into the database
    $sql = "INSERT INTO media_reports (report_date, division, media, topic, attachments)
            VALUES (:reportDate, :division, :media, :topic, :attachments)";
    
    $query = $dbh->prepare($sql);
    $query->bindParam(':reportDate', $reportDate, PDO::PARAM_STR);
    $query->bindParam(':division', $division, PDO::PARAM_STR);
    $query->bindParam(':media', $media, PDO::PARAM_STR);
    $query->bindParam(':topic', $topic, PDO::PARAM_STR);
    $query->bindParam(':attachments', $attachments, PDO::PARAM_STR);
if ($query->execute()) {
    // After successful insertion, store the success message in session
    $_SESSION['msg'] = "Media Report Created Successfully";
    header('Location: manage-media.php'); // Redirect to media.php or your desired page
    exit; // Ensure no further code is executed after the redirect
} else {
    $error = "Something went wrong. Please try again";
}

   
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Create Media Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .errorWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #dd3d36; }
        .succWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #5cb85c; }
        .header-main, .sidebar { z-index: 1000; }
       .page-container {
            padding-top: 20px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */
        }
        .sidebar { position: fixed; top: 0; left: 0; width: 250px; height: 100vh; background: #f8f9fa; }

    </style>
</head>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>    
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="main.php">হোম</a><i class="fa fa-angle-right"></i>কমিশন, সচিবালয়, নির্বাচন,এনআইডি,স্মার্টকার্ড ও ইভিএম</li>
        </ol>
        <div class="container">
            <h2>গণমাধ্যমে প্রকাশিত ও সম্প্রচারিত সংবাদ এবং বিশ্লেষণ</h2>
            <p>Date, Division, Media, Topic, and Attachments:</p>
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>রিপোর্টের তারিখ</label>
                    <input type="date" name="report_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>বিভাগ</label>
                    <input type="text" name="division" class="form-control">
                </div>
                <div class="form-group">
                    <label>গণমাধ্যম</label>
                    <input type="text" name="media" class="form-control">
                </div>
                <div class="form-group">
                    <label>বিষয়</label>
                    <input type="text" name="topic" class="form-control">
                </div>
                <div class="form-group">
                    <label>সংযুক্তি(পিডিএফ)</label>
                    <input type="file" name="attachments[]" class="form-control" accept="application/pdf" multiple>
                </div>
                <button type="submit" name="create" class="btn btn-primary">রিপোর্ট তৈরী</button>
            </form>
        </div>
        
        <?php include('includes/footer.php'); ?>
    </div>
    <?php include('includes/sidebarmenu.php'); ?>
    <div class="clearfix"></div>     
</div>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
