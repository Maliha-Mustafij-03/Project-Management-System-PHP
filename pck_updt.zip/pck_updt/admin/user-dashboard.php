<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit; // Make sure to exit after redirecting
} else {
    $username = $_SESSION['userlogin']; // Get the username for display or other purposes
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>TMS | User Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <script src="js/jquery-2.1.4.min.js"></script>
</head> 
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <?php include('includes/sidebarmenu.php'); ?>

                <!-- Breadcrumb -->
                <ol class="breadcrumb">
                                        <li><a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true">
                                        </i>  <span>Back to Home Page</span><div class="clearfix"></div></a></li>
                </ol>

                <!-- Dashboard Content -->
                <div class="container">
                    <h2>Welcome, <?php echo htmlentities($username); ?></h2>
                    <div class="row">
                        <!-- Add your user-specific dashboard widgets here -->
                        <div class="col-md-12">
                            <h4>Your Dashboard</h4>
                            <p>This is the user dashboard where you can manage and show data.</p>
                        </div>
                    </div>
                </div>

                <?php include('includes/footer.php'); ?>
            </div>
        </div>

        <div class="clearfix"></div>
    </div>
<!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <!-- jQuery -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <!-- //jQuery -->
    
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <!-- //lined-icons -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
