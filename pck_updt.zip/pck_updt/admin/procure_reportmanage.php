<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Initialize variables for error and success messages
$error = "";
$msg = "";

// Handle delete operation
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    
    // Prepare SQL query to delete the record
    $sql = "DELETE FROM procurement_plan WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id);
    
    try {
        $query->execute();
        $msg = "Record deleted successfully!";
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Search functionality
$searchQuery = "";
if (isset($_POST['search'])) {
    $searchQuery = $_POST['search_term'];  // Get search term

    // Prepare SQL query with a WHERE clause based on the search term
    $sql = "SELECT * FROM procurement_plan WHERE total_packages LIKE :search OR previous_contracts LIKE :search OR signed_contracts LIKE :search OR implementation_progress_rate LIKE :search OR packages_under_evaluation LIKE :search OR remaining_packages LIKE :search";
    $query = $dbh->prepare($sql);
    $query->bindValue(':search', '%' . $searchQuery . '%');
    $query->execute();
} else {
    // If no search, fetch all records
    $sql = "SELECT * FROM procurement_plan";
    $query = $dbh->prepare($sql);
    $query->execute();
}

$results = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include('includes/sidebarmenu.php'); ?>
  <?php include('includes/header.php'); ?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Procurement Progress</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        .container {
            margin-top: 40px;
            padding-left: 200px; /* Adjust based on sidebar width */sssss
        }
        /* Custom styles for the buttons */
        .btn-sm {
            margin-right: 10px;
        }

        .btn-edit {
            background-color: #f0ad4e;
            color: white;
        }

        .btn-delete {
            background-color: #d9534f;
            color: white;
        }

        .search-bar {
            margin: 20px 0;
        }

        .table thead th {
            background-color: #4e73df;
            color: white;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3 class="mt-5">Manage Procurement Progress Report</h3>

        <!-- Display error or success message -->
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php elseif ($msg): ?>
            <div class="alert alert-success"><?php echo $msg; ?></div>
        <?php endif; ?>

        <!-- Search Bar Form -->
        <form method="POST" class="search-bar">
            <div class="form-group row">
                <div class="col-md-8">
                    <input type="text" name="search_term" class="form-control" placeholder="Search Procurement Data" value="<?php echo htmlspecialchars($searchQuery); ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" name="search" class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>

        <!-- Add New Record Button -->
        <a href="procure_reportcreate.php" class="btn btn-success mb-3">Add New Record</a>

        <!-- Table to display data -->
        <h3 class="mt-5">Existing Procurement Progress</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>২০২৪-২৫  ক্রয় পরিকল্পনায় অন্তর্ভুক্ত মোট প্যাকেজ সংখ্যা</th>
                    <th>পূর্বে চুক্তি সম্পন্ন প্যাকেজ</th>
                    <th>২০২৪-২৫ চুক্তি সম্পাদিত প্যাকেজ সংখ্যা</th>
                    <th>বাস্তবায়ন অগ্রগতির হার (%)</th>
                    <th>দরপত্র প্রক্রিয়াধীন প্যাকেজ সংখ্যা (মূল্যায়ন চলমান, NOA, ইত্যাদি)*</th>
                    <th>অবশিষ্ট প্যাকেজসমূহ</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['total_packages']); ?></td>
                        <td><?php echo htmlspecialchars($row['previous_contracts']); ?></td>
                        <td><?php echo htmlspecialchars($row['signed_contracts']); ?></td>
                        <td><?php echo htmlspecialchars($row['implementation_progress_rate']); ?></td>
                        <td><?php echo htmlspecialchars($row['packages_under_evaluation']); ?></td>
                        <td><?php echo htmlspecialchars($row['remaining_packages']); ?></td>
                        <td>
                            <a href="procure_reportedit.php?id=<?php echo $row['id']; ?>" class="btn btn-edit btn-sm">Edit</a>

                            <?php if (isset($_SESSION['alogin'])): ?>
    <a href="procure_reportmanage.php?delete_id=<?php echo $row['id']; ?>" class="btn btn-delete btn-sm" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
<?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
