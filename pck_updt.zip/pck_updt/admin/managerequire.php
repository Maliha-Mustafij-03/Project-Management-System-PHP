<?php
session_start();

// Include configuration
include('includes/config.php');

// Initialize error and success messages
$error = "";
$msg = "";

// Check if user is logged in as admin or user
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) { 
    // If neither is set, redirect to login page (index.php)
    header('location:index.php');
    exit;
}

// Initialize search query
$searchQuery = "";
$searchTerm = "";

// Check if search form is submitted
if (isset($_POST['search'])) {
    $searchTerm = $_POST['searchTerm'];
    if (!empty($searchTerm)) {
        // Remove % from the input before using it in the query
        $searchTermDisplay = $searchTerm; // This is for display, will not have % in it
        $searchTerm = "%" . $searchTerm . "%"; // Add wildcards for LIKE search
        $searchQuery = "WHERE s.serial_no LIKE :searchTerm 
                         OR s.country_name LIKE :searchTerm 
                         OR c.card_number LIKE :searchTerm 
                         OR c.remaining LIKE :searchTerm 
                         OR c.condition_date LIKE :searchTerm";
    }
} else {
    $searchTermDisplay = ""; // If no search, display an empty string
}

// Fetch all smart card distributions along with conditions (one-to-many)
$sql = "SELECT s.id, s.serial_no, s.country_name, c.card_number, c.remaining, c.condition_date 
        FROM smart_card_distribution s
        LEFT JOIN smart_card_conditions c ON s.id = c.distribution_id
        $searchQuery";
$query = $dbh->prepare($sql);

// Bind the search term if it's provided
if (!empty($searchTerm)) {
    $query->bindParam(':searchTerm', $searchTerm, PDO::PARAM_STR);
}

$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS-GD | Manage Smart Card Distribution</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        .table-container {
            margin-top: 20px;
        }
        .btn-container {
            margin-top: 8px;
        }
        .table th, .table td {
            text-align: center;
        }
        .search-form {
            margin-bottom: 20px;
            display: flex;
            justify-content: right;
            align-items: right;
        }
        .search-form input {
            margin-right: 10px;
            padding: 10px;
            width: 250px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .search-form button {
            padding: 10px 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .search-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <div class="clearfix"> </div>    
            </div>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>স্মার্ট কার্ড বিতরণ পরিচালনা</li>
            </ol>

            <div class="grid-form">
                <div class="grid-form1">
                    <h3>স্মার্ট কার্ড বিতরণ ব্যবস্থাপনা</h3>

                    <!-- Search Form with input and button on the same line -->
                    <div class="search-form">
                        <form method="post" action="">
                            <input type="text" name="searchTerm" class="form-control" placeholder="অনুসন্ধান" value="<?php echo htmlentities($searchTermDisplay); ?>" />
                            <button type="submit" name="search" class="btn btn-primary">অনুসন্ধান</button>
                        </form>
                    </div>

                    <?php if ($error) { ?>
                        <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
                    <?php } else if ($msg) { ?>
                        <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
                    <?php } ?>

                    <div class="table-container">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ক্রম নং</th>
                                    <th>দেশের নাম</th>
                                    <th>কার্ডের সংখ্যা(পাঠানো হয়ে গেছে)</th>
                                    <th>মুদ্রন বাকি কার্ডের সংখ্যা</th>
                                    <th>তারিখ</th>
                                    <th>অ্যাকশন</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Display all records and associated conditions
                                $currentDistributionId = null;
                                foreach ($results as $row) {
                                    // Check if this is the first row for a new distribution
                                    if ($currentDistributionId != $row['id']) {
                                        // This is a new distribution row, so print the distribution info
                                        $currentDistributionId = $row['id'];
                                        echo "<tr>
                                                <td>" . htmlentities($row['serial_no']) . "</td>
                                                <td>" . htmlentities($row['country_name']) . "</td>
                                                <td>" . htmlentities($row['card_number']) . "</td>
                                                <td>" . htmlentities($row['remaining']) . "</td>
                                                <td>" . htmlentities($row['condition_date']) . "</td>
                                                <td><a href='edit_require.php?edit_id=" . htmlentities($row['id']) . "' class='btn btn-primary'>এডিট</a>";
                                                
                                                // Display delete button only if the user is logged in
                                                if (isset($_SESSION['alogin'])) {
                                                    echo "<a href='delete_smart_card_distribution.php?delete_id=" . htmlentities($row['id']) . "' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete?\");'>মুছুন</a>";
                                                }
                                                
                                        echo "</td></tr>";
                                    } else {
                                        // This is a continuation of the same distribution, so just repeat the conditions
                                        echo "<tr>
                                                <td></td>
                                                <td></td>
                                                <td>" . htmlentities($row['card_number']) . "</td>
                                                <td>" . htmlentities($row['remaining']) . "</td>
                                                <td>" . htmlentities($row['condition_date']) . "</td>
                                                <td></td>
                                              </tr>";
                                    }
                                }
                                if (!$results) {
                                    echo "<tr><td colspan='6'>কোনো তথ্য নেই</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php include('includes/footer.php'); ?>
        </div>
        <?php include('includes/sidebarmenu.php'); ?>
    </div>
</body>
</html>
