<?php
// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';  // Change as needed
$password = '';  // Change as needed
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch current category data
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch main category data
    $result = $conn->query("SELECT * FROM snid_card_main_data WHERE id = $id");
    if ($result) {
        $data = $result->fetch_assoc();
    } else {
        die("Main category not found.");
    }

    // Fetch subcategories for the main category
    $subcategories = $conn->query("SELECT * FROM snid_card_subcategory_data WHERE main_category_id = $id");
    if (!$subcategories) {
        die("Subcategories not found.");
    }
} else {
    die("Invalid request: Missing category ID.");
}

// Handle form submission (edit form)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update main category
    $category_name = $_POST['category_name'];
    $total_count = $_POST['total_count'];  // This is updated by calculating the total subcategory count.

    // Update main category
    $conn->query("UPDATE snid_card_main_data SET category_name = '$category_name', total_count = '$total_count' WHERE id = $id");

    // Update subcategories
    foreach ($_POST['subcategories'] as $subcategory_id => $subcategory) {
        $subcategory_name = $subcategory['subcategory_name'];
        $description = $subcategory['description'];
        $subcategory_total = $subcategory['subcategory_total'];

        // Check if it's a new subcategory
        if (strpos($subcategory_id, 'new') !== false) {
            // Insert new subcategory into the database
            $conn->query("INSERT INTO snid_card_subcategory_data (main_category_id, subcategory_name, description, subcategory_total) 
                VALUES ('$id', '$subcategory_name', '$description', '$subcategory_total')");
            $subcategory_id = $conn->insert_id; // Get the ID of the newly inserted subcategory
        } else {
            // Update existing subcategory
            $conn->query("UPDATE snid_card_subcategory_data SET subcategory_name = '$subcategory_name', description = '$description', subcategory_total = '$subcategory_total' WHERE id = $subcategory_id");
        }

        // Handle items for the subcategory
        foreach ($subcategory['items'] as $item_id => $item) {
            if (isset($item['delete']) && $item['delete'] == 'true') {
                // Delete the item from the database
                $conn->query("DELETE FROM snid_card_item_data WHERE id = $item_id");
            } else {
                $item_name = $item['name'];
                $item_count = $item['count'];

                // Check if it's a new item
                if (strpos($item_id, 'new') !== false) {
                    // Insert new item into the database
                    $conn->query("INSERT INTO snid_card_item_data (subcategory_id, item_name, item_count) 
                        VALUES ('$subcategory_id', '$item_name', '$item_count')");
                } else {
                    // Update existing item
                    $conn->query("UPDATE snid_card_item_data SET item_name = '$item_name', item_count = '$item_count' WHERE id = $item_id");
                }
            }
        }
    }

    // Redirect back to the manage page
    header("Location: managestat.php");
    exit();
}
?>

<?php include('includes/header.php'); ?>
<?php include('includes/sidebarmenu.php'); ?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>এডিট স্মার্ট কার্ড তথ্য</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        body, html {
            overflow-x: hidden;
            height: 100%;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 40px;
            padding-left: 200px; /* Adjust based on sidebar width */
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2>স্মার্ট কার্ড তথ্য সম্পাদনা</h2>
    <form action="" method="post">
        <!-- Main category -->
        <div class="form-group">
            <label for="category_name">নাম:</label>
            <input type="text" class="form-control" id="category_name" name="category_name" value="<?= isset($data['category_name']) ? htmlspecialchars($data['category_name']) : ''; ?>" >
        </div>
        <div class="form-group">
            <label for="total_count">মোট সংখ্যা:</label>
            <input type="number" class="form-control" id="total_count" name="total_count" value="<?= isset($data['total_count']) ? htmlspecialchars($data['total_count']) : ''; ?>" readonly>
        </div>

        <h3>সাব ক্যাটাগরি</h3>
        <div id="subcategories-container">
            <?php if ($subcategories->num_rows > 0): ?>
                <?php while ($subcategory = $subcategories->fetch_assoc()) : ?>
                    <!-- Subcategory Form -->
                    <div class="subcategory" id="subcategory-<?= $subcategory['id']; ?>">
                        <div class="form-group">
                            <label for="subcategory_name[<?= $subcategory['id']; ?>]">সাব ক্যাটাগরি নাম:</label>
                            <input type="text" class="form-control" name="subcategories[<?= $subcategory['id']; ?>][subcategory_name]" value="<?= htmlspecialchars($subcategory['subcategory_name']); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="description[<?= $subcategory['id']; ?>]">বিশদ বিবরনী:</label>
                            <textarea class="form-control" name="subcategories[<?= $subcategory['id']; ?>][description]"><?= htmlspecialchars($subcategory['description']); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="subcategory_total[<?= $subcategory['id']; ?>]">সাব ক্যাটাগরি মোট:</label>
                            <input type="number" class="form-control subcategory_total" name="subcategories[<?= $subcategory['id']; ?>][subcategory_total]" value="<?= htmlspecialchars($subcategory['subcategory_total']); ?>" readonly>
                        </div>

                        <!-- Items for this subcategory -->
                        <h4>আইটেম</h4>
                        <div class="items-list" id="items-list-<?= $subcategory['id']; ?>">
                            <?php
                            $items = $conn->query("SELECT * FROM snid_card_item_data WHERE subcategory_id = " . $subcategory['id']);
                            if ($items->num_rows > 0):
                                while ($item = $items->fetch_assoc()):
                            ?>
                                <div class="form-group" id="item-<?= $item['id']; ?>">
                                    <label for="item_name[<?= $item['id']; ?>]">আইটেমের নাম:</label>
                                    <input type="text" class="form-control" name="subcategories[<?= $subcategory['id']; ?>][items][<?= $item['id']; ?>][name]" value="<?= htmlspecialchars($item['item_name']); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="item_count[<?= $item['id']; ?>]">আইটেমের পরিমাণ:</label>
                                    <input type="number" class="form-control" name="subcategories[<?= $subcategory['id']; ?>][items][<?= $item['id']; ?>][count]" value="<?= htmlspecialchars($item['item_count']); ?>" oninput="updateSubcategoryTotal(<?= $subcategory['id']; ?>)">
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="subcategories[<?= $subcategory['id']; ?>][items][<?= $item['id']; ?>][delete]" value="true"> মুছুন
                                </div>
                            <?php endwhile; ?>
                            <?php else: ?>
                                <p>কোন আইটেম পাওয়া যায়নি।</p>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="addItem(<?= $subcategory['id']; ?>)">আইটেম যোগ করুন</button>
                        <button type="button" class="btn btn-danger" onclick="removeLastItem(<?= $subcategory['id']; ?>)">শেষ আইটেম রিসেট</button>
                        <button type="button" class="btn btn-danger" onclick="removeSubcategory(<?= $subcategory['id']; ?>)">সাব ক্যাটাগরি মুছুন</button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>কোন সাব ক্যাটাগরি পাওয়া যায়নি।</p>
            <?php endif; ?>
        </div>
        <button type="button" class="btn btn-primary" onclick="addSubcategory()">নতুন সাব ক্যাটাগরি যোগ করুন</button>
        <button type="submit" class="btn btn-success">পরিবর্তন সংরক্ষণ করুন</button>
    </form>
</div>

<script>
// Add Item
function addItem(subcategoryId) {
    var itemsList = document.getElementById('items-list-' + subcategoryId);
    var newItemIndex = itemsList.childElementCount;

    var newItemHTML = `
    <div class="form-group" id="item-new-${subcategoryId}-${newItemIndex}">
        <label for="item_name[new-${subcategoryId}-${newItemIndex}]">আইটেমের নাম:</label>
        <input type="text" class="form-control" name="subcategories[${subcategoryId}][items][new-${newItemIndex}][name]" >
    </div>
    <div class="form-group">
        <label for="item_count[new-${subcategoryId}-${newItemIndex}]">আইটেমের পরিমাণ:</label>
        <input type="number" class="form-control" name="subcategories[${subcategoryId}][items][new-${newItemIndex}][count]" required oninput="updateSubcategoryTotal(${subcategoryId})">
    </div>`;
    itemsList.innerHTML += newItemHTML;
    updateSubcategoryTotal(subcategoryId);  // Update subcategory total after adding item
}

// Remove Last Item from Subcategory
function removeLastItem(subcategoryId) {
    var itemsList = document.getElementById('items-list-' + subcategoryId);
    if (itemsList.children.length > 0) {
        var lastItem = itemsList.lastElementChild;  // Get the last item in the list
        lastItem.remove();  // Remove the last item from the list
        updateSubcategoryTotal(subcategoryId);  // Update the subcategory total after removing the item
    }
}

// Update Subcategory Total
function updateSubcategoryTotal(subcategoryId) {
    var subcategoryTotal = 0;
    var itemCounts = document.querySelectorAll(`[name^="subcategories[${subcategoryId}][items]"][name$="[count]"]`);
    itemCounts.forEach(function(input) {
        subcategoryTotal += parseInt(input.value) || 0;
    });

    // Update the subcategory total input
    var subcategoryTotalInput = document.querySelector(`[name="subcategories[${subcategoryId}][subcategory_total]"]`);
    if (subcategoryTotalInput) {
        subcategoryTotalInput.value = subcategoryTotal;
    }

    // Update the main category total count
    updateMainCategoryTotal();
}

// Update Main Category Total
function updateMainCategoryTotal() {
    var totalCount = 0;
    var subcategoryTotals = document.querySelectorAll('[name$="[subcategory_total]"]');
    subcategoryTotals.forEach(function(input) {
        totalCount += parseInt(input.value) || 0;
    });
    document.getElementById('total_count').value = totalCount;
}

// Add Subcategory
function addSubcategory() {
    var subcategoriesContainer = document.getElementById('subcategories-container');
    var newSubcategoryIndex = subcategoriesContainer.childElementCount;

    var newSubcategoryHTML = `
    <div class="subcategory" id="subcategory-new-${newSubcategoryIndex}">
        <div class="form-group">
            <label for="subcategory_name[new-${newSubcategoryIndex}]">সাব ক্যাটাগরি নাম:</label>
            <input type="text" class="form-control" name="subcategories[new-${newSubcategoryIndex}][subcategory_name]" >
        </div>
        <div class="form-group">
            <label for="description[new-${newSubcategoryIndex}]">বিশদ বিবরনী:</label>
            <textarea class="form-control" name="subcategories[new-${newSubcategoryIndex}][description]" ></textarea>
        </div>
        <div class="form-group">
            <label for="subcategory_total[new-${newSubcategoryIndex}]">সাব ক্যাটাগরি মোট:</label>
            <input type="number" class="form-control subcategory_total" name="subcategories[new-${newSubcategoryIndex}][subcategory_total]" readonly>
        </div>
        <h4>আইটেম</h4>
        <div class="items-list" id="items-list-new-${newSubcategoryIndex}"></div>
        <button type="button" class="btn btn-primary" onclick="addItem('new-${newSubcategoryIndex}')">আইটেম যোগ করুন</button>
        <button type="button" class="btn btn-danger" onclick="removeLastItem('new-${newSubcategoryIndex}')">শেষ আইটেম মুছুন</button>
        <button type="button" class="btn btn-danger" onclick="removeSubcategory('new-${newSubcategoryIndex}')">সাব ক্যাটাগরি মুছুন</button>
    </div>`;
    subcategoriesContainer.innerHTML += newSubcategoryHTML;
}

function removeSubcategory(subcategoryId) {
    // First, try to get the element by a static subcategory ID (for existing ones)
    var subcategory = document.getElementById('subcategory-' + subcategoryId);

    // If not found, try to get it by a dynamic subcategory ID (for newly added ones)
    if (!subcategory) {
        subcategory = document.getElementById('subcategory-new-' + subcategoryId);
    }

    // If we find the subcategory, remove it
    if (subcategory) {
        subcategory.remove();  // Remove the subcategory element from the DOM
    }

    // After removal, update the main category total
    updateMainCategoryTotal();  // This ensures the total count is recalculated
}

</script>

</body>
</html>
