<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Check if AssetID is provided in the URL
if (isset($_GET['AssetID'])) {
    $AssetID = $_GET['AssetID'];

    // Fetch the existing asset data to prefill the form
    $sql = "SELECT * FROM tblassets WHERE AssetID = :AssetID";
    $query = $dbh->prepare($sql);
    $query->bindParam(':AssetID', $AssetID, PDO::PARAM_INT);
    $query->execute();
    $asset = $query->fetch(PDO::FETCH_ASSOC);
    $msg = "";
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Collect the updated data
        $slno = $_POST['slno'];
        $officeName = $_POST['officeName'];
        $officeDivision = $_POST['officeDivision'];
        $officeZilla = $_POST['officeZilla'];

        $items = $_POST['itemname']; // Array of item names
        $vendors = $_POST['vendorname']; // Array of vendor names
        $brands = $_POST['brandname']; // Array of brand names
        $deliveredQuantities = $_POST['deliveredquantity']; // Array of delivered quantities
        $currentQuantities = $_POST['currentquantity']; // Array of current quantities
        $condition1s = $_POST['condition1']; // Array of condition 1
        $quantities1 = $_POST['quantity1']; // Array of quantities 1
        $condition2s = $_POST['condition2']; // Array of condition 2
        $quantities2 = $_POST['quantity2']; // Array of quantities 2
        $receivedBy = $_POST['receivedBy']; // Array of received by
        $positions = $_POST['position']; // Array of positions
        $conditionDates = $_POST['dateofcondition']; // Array of condition dates

        // Update the asset details (excluding dynamic conditions)
        $sql = "UPDATE tblassets SET SLNumber = :slno, OfficeName = :officeName, OfficeDivision = :officeDivision, OfficeZilla = :officeZilla WHERE AssetID = :AssetID";
        $query = $dbh->prepare($sql);
        $query->bindParam(':slno', $slno, PDO::PARAM_STR);
        $query->bindParam(':officeName', $officeName, PDO::PARAM_STR);
        $query->bindParam(':officeDivision', $officeDivision, PDO::PARAM_STR);
        $query->bindParam(':officeZilla', $officeZilla, PDO::PARAM_STR);
        $query->bindParam(':AssetID', $AssetID, PDO::PARAM_INT);
        $query->execute();

        // Update each asset condition (existing conditions)
        foreach ($items as $index => $itemName) {
            $sql = "UPDATE tblassets 
                    SET ItemName = :itemName, VendorName = :vendorName, BrandName = :brandName, DeliveredQuantity = :deliveredQuantity, 
                        CurrentQuantity = :currentQuantity, Condition1 = :condition1, Quantity1 = :quantity1, Condition2 = :condition2, 
                        Quantity2 = :quantity2, ReceivedBy = :receivedBy, Position = :position, ConditionDate = :conditionDate 
                    WHERE AssetID = :AssetID AND ItemName = :oldItemName";
            $query = $dbh->prepare($sql);
            $query->bindParam(':itemName', $itemName, PDO::PARAM_STR);
            $query->bindParam(':vendorName', $vendors[$index], PDO::PARAM_STR);
            $query->bindParam(':brandName', $brands[$index], PDO::PARAM_STR);
            $query->bindParam(':deliveredQuantity', $deliveredQuantities[$index], PDO::PARAM_INT);
            $query->bindParam(':currentQuantity', $currentQuantities[$index], PDO::PARAM_INT);
            $query->bindParam(':condition1', $condition1s[$index], PDO::PARAM_STR);
            $query->bindParam(':quantity1', $quantities1[$index], PDO::PARAM_INT);
            $query->bindParam(':condition2', $condition2s[$index], PDO::PARAM_STR);
            $query->bindParam(':quantity2', $quantities2[$index], PDO::PARAM_INT);
            $query->bindParam(':receivedBy', $receivedBy[$index], PDO::PARAM_STR);
            $query->bindParam(':position', $positions[$index], PDO::PARAM_STR);
            $query->bindParam(':conditionDate', $conditionDates[$index], PDO::PARAM_STR);
            $query->bindParam(':AssetID', $AssetID, PDO::PARAM_INT);
            $query->bindParam(':oldItemName', $asset['ItemName'], PDO::PARAM_STR); // To prevent overriding wrong record
            $query->execute();
        }

        $msg = "Asset Updated Successfully";
    }
} else {
    echo "Asset ID not found.";
    exit;
}

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Asset</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
    .form-control1 {
        font-size: 16px;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
    }

    /* New grid layout */
    .form-group {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 16px;
    }

    .form-group input {
        width: 100%;
    }

    #conditionsContainer {
        display: grid;
        grid-template-columns: repeat(2, 1fr); /* Change this number to control how many columns you want */
        gap: 16px;
    }

    .detail-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr); /* You can adjust the number of columns */
        gap: 16px;
    }

    .btn-container {
        margin-top: 20px;
    }

    /* For responsive design */
    @media screen and (max-width: 768px) {
        .form-group {
            grid-template-columns: 1fr; /* Stack fields vertically on small screens */
        }

        #conditionsContainer {
            grid-template-columns: 1fr; /* Stack condition fields on small screens */
        }
    }
</style>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>আপডেট এসেট</title>
     <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>
    <!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->     
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        .form-control1 {
            font-size: 16px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }

        /* New grid layout */
        .form-group {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 16px;
        }

        .form-group input {
            width: 100%;
        }

        #conditionsContainer {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* Change this number to control how many columns you want */
            gap: 16px;
        }

        .detail-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* You can adjust the number of columns */
            gap: 16px;
        }

        .btn-container {
            margin-top: 20px;
        }

        /* For responsive design */
        @media screen and (max-width: 768px) {
            .form-group {
                grid-template-columns: 1fr; /* Stack fields vertically on small screens */
            }

            #conditionsContainer {
                grid-template-columns: 1fr; /* Stack condition fields on small screens */
            }
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <?php include('includes/sidebarmenu.php'); ?>
    <div class="container">
        <h1>আপডেট এসেট</h1>
        <form method="POST">
            <div class="form-group">
                <label for="slno">ক্রমিক নং</label>
                <input type="text" class="form-control1" name="slno" value="<?php echo htmlentities($asset['SLNumber']); ?>" required>
            </div>
            <div class="form-group">
                <label for="officeName">অফিসের নাম</label>
                <input type="text" class="form-control1" name="officeName" value="<?php echo htmlentities($asset['OfficeName']); ?>" required>
            </div>
            <div class="form-group">
                <label for="officeDivision">অফিসের বিভাগ</label>
                <input type="text" class="form-control1" name="officeDivision" value="<?php echo htmlentities($asset['OfficeDivision']); ?>" required>
            </div>
            <div class="form-group">
                <label for="officeZilla">অফিসের জেলা</label>
                <input type="text" class="form-control1" name="officeZilla" value="<?php echo htmlentities($asset['OfficeZilla']); ?>" required>
            </div>

            <div id="conditionsContainer">
                <?php
                    // Fetch conditions from database for the current asset
                    $sqlConditions = "SELECT * FROM tblassets WHERE AssetID = :AssetID";
                    $queryConditions = $dbh->prepare($sqlConditions);
                    $queryConditions->bindParam(':AssetID', $AssetID, PDO::PARAM_INT);
                    $queryConditions->execute();
                    $conditions = $queryConditions->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($conditions as $condition) {
                ?>
                    <div class="detail-row">
                        <input type="text" name="itemname[]" class="form-control1" value="<?php echo htmlentities($condition['ItemName']); ?>" placeholder="আইটেমের নাম">
                        <input type="text" name="vendorname[]" class="form-control1" value="<?php echo htmlentities($condition['VendorName']); ?>" placeholder="ভেন্ডরের নাম">
                        <input type="text" name="brandname[]" class="form-control1" value="<?php echo htmlentities($condition['BrandName']); ?>" placeholder="ব্রান্ডের নাম">
                        <input type="number" name="deliveredquantity[]" class="form-control1" value="<?php echo htmlentities($condition['DeliveredQuantity']); ?>" placeholder="ডেলিভারীর পরিমাণ">
                        <input type="number" name="currentquantity[]" class="form-control1" value="<?php echo htmlentities($condition['CurrentQuantity']); ?>" placeholder="বর্তমান পরিমাণ">
                        <input type="text" name="condition1[]" class="form-control1" value="<?php echo htmlentities($condition['Condition1']); ?>" placeholder="অবস্থা(ভালো)">
                        <input type="number" name="quantity1[]" class="form-control1" value="<?php echo htmlentities($condition['Quantity1']); ?>" placeholder="পরিমাণ(ভালো)">
                        <input type="text" name="condition2[]" class="form-control1" value="<?php echo htmlentities($condition['Condition2']); ?>" placeholder="অবস্থা(নষ্ট)">
                        <input type="number" name="quantity2[]" class="form-control1" value="<?php echo htmlentities($condition['Quantity2']); ?>" placeholder="পরিমান(নষ্ট)">
                        <input type="text" name="receivedBy[]" class="form-control1" value="<?php echo htmlentities($condition['ReceivedBy']); ?>" placeholder="গ্রহণকারীর নাম">
                        <input type="text" name="position[]" class="form-control1" value="<?php echo htmlentities($condition['Position']); ?>" placeholder="পদবী">
                        <input type="date" name="dateofcondition[]" class="form-control1" value="<?php echo htmlentities($condition['ConditionDate']); ?>">
                    </div>
                <?php
                    }
                ?>
            </div>

            <div class="btn-container">
                <button type="button" class="btn btn-info" onclick="addCondition()">নতুন যোগ</button>
                <br><br>
                <button type="submit" class="btn btn-success">সাবমিট</button>
            </div>
        </form>
    </div>
</body>
</html>

<script>
    function addCondition() {
        var container = document.getElementById('conditionsContainer');
        var row = document.createElement('div');
        row.className = 'detail-row';

        row.innerHTML = `
            <input type="text" name="itemname[]" class="form-control1" placeholder="আইটেমের নাম">
            <input type="text" name="vendorname[]" class="form-control1" placeholder="ভেন্ডরের নাম">
            <input type="text" name="brandname[]" class="form-control1" placeholder="ব্রান্ডের নাম">
            <input type="number" name="deliveredquantity[]" class="form-control1" placeholder="ডেলিভারীর পরিমাণ">
            <input type="number" name="currentquantity[]" class="form-control1" placeholder="বর্তমান পরিমাণ">
            <input type="text" name="condition1[]" class="form-control1" placeholder="অবস্থা(ভালো)">
            <input type="number" name="quantity1[]" class="form-control1" placeholder="পরিমাণ(ভালো)">
            <input type="text" name="condition2[]" class="form-control1" placeholder="অবস্থা(নষ্ট)">
            <input type="number" name="quantity2[]" class="form-control1" placeholder="পরিমান(নষ্ট)">
            <input type="text" name="receivedBy[]" class="form-control1" placeholder="গ্রহণকারীর নাম">
            <input type="text" name="position[]" class="form-control1" placeholder="পদবী">
            <input type="date" name="dateofcondition[]" class="form-control1">
        `;
        container.appendChild(row);
    }
</script>
