<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit; // Ensure no further code runs after redirecting
}

// Check if form is submitted for updating package
if (isset($_POST['update'])) {
    $packageId = $_POST['package_id'];
    $packageNo = $_POST['package_no'];
    $details = $_POST['details'];
    $current_condition = $_POST['current_condition'];
    $specificationTarget = $_POST['specification_target']; // Capture the new field value
    $specificationDateTransmissionVerification = $_POST['specification_date_transmission_verification'];
    $specificationDateDispatchProcurement = $_POST['specification_date_dispatch_procurement'];

    // Update package information in the database
    $sql = "UPDATE package_overview 
            SET package_no = :packageNo, details = :details, current_condition = :current_condition,
                specification_target = :specificationTarget,
                specification_date_transmission_verification = :specificationDateTransmissionVerification, 
                specification_date_dispatch_procurement = :specificationDateDispatchProcurement
            WHERE id = :packageId";

    $query = $dbh->prepare($sql);
    $query->bindParam(':packageNo', $packageNo, PDO::PARAM_STR);
    $query->bindParam(':details', $details, PDO::PARAM_STR);
    $query->bindParam(':current_condition', $current_condition, PDO::PARAM_STR);
    $query->bindParam(':specificationTarget', $specificationTarget, PDO::PARAM_STR); // Bind the new field
    $query->bindParam(':specificationDateTransmissionVerification', $specificationDateTransmissionVerification, PDO::PARAM_STR);
    $query->bindParam(':specificationDateDispatchProcurement', $specificationDateDispatchProcurement, PDO::PARAM_STR);
    $query->bindParam(':packageId', $packageId, PDO::PARAM_INT);

    if ($query->execute()) {
        $msg = "Package Updated Successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Fetch package details for editing
$packageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT * FROM package_overview WHERE id = :packageId";
$query = $dbh->prepare($sql);
$query->bindParam(':packageId', $packageId, PDO::PARAM_INT);
$query->execute();
$package = $query->fetch(PDO::FETCH_OBJ);

if (!$package) {
    $error = "No package found.";
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Update Package</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .border-red {
            border: 2px solid black;
        }
        .header-main, .sidebar {
            z-index: 1000; /* Ensure the header and sidebar are on top */
        }
        .page-container {
            padding-top: 60px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */
        }
        .left-content {
            margin-left: 0; /* Reset margin */
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            overflow: auto;
            background: #f8f9fa; /* Light background for sidebar */
            border-right: 2px solid red; /* Red border for sidebar */
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!--header start here-->
        <?php include('includes/header.php');?>
        <div class="clearfix"> </div>    
        <!--header end here-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">হোম</a><i class="fa fa-angle-right"></i>আপডেট প্যাকেজ</li>
        </ol>
        <div class="container">
            <h2>স্পেসিফিকেশন কমিটি-II দ্বারা তৈরীকৃত স্পেসিফিকেশন, যাচাই কমিটিতে প্রেরণের তারিখ এবং ক্রয় (আপডেট ওভারভিউ) :</h2>
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>
            <form method="post">
                <input type="hidden" name="package_id" value="<?php echo htmlspecialchars($package->id ?? ''); ?>">
                <div class="form-group">
                    <label>প্যাকেজ নং</label>
                    <input type="text" name="package_no" value="<?php echo htmlspecialchars($package->package_no ?? ''); ?>" class="form-control border-red" required>
                </div>
                <div class="form-group">
                    <label>বিস্তারিত</label>
                    <textarea name="details" class="form-control border-red" required><?php echo htmlspecialchars($package->details ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>ক্রয়পদ্ধতি</label>
                    <textarea name="current_condition" class="form-control border-red" required><?php echo htmlspecialchars($package->current_condition ?? ''); ?></textarea>
                </div>
                <!-- New Text Field for Specification Target -->
                <div class="form-group">
                    <label>স্পেসিফিকেশনের লক্ষ্যমাত্রা</label>
                    <textarea name="specification_target" class="form-control border-red"><?php echo htmlspecialchars($package->specification_target ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>স্পেসিফিকেশন চূড়ান্তকরণ প্রাপ্তির তারিখ  </label>
                    <input type="date" name="specification_date_transmission_verification" value="<?php echo htmlspecialchars($package->specification_date_transmission_verification ?? ''); ?>" class="form-control border-red">
                </div>
                <div class="form-group">
                    <label>স্পেসিফিকেশন প্রকিউরমেন্টে পাঠানো এর তারিখ</label>
                    <input type="date" name="specification_date_dispatch_procurement" value="<?php echo htmlspecialchars($package->specification_date_dispatch_procurement ?? ''); ?>" class="form-control border-red">
                </div>
                <button type="submit" name="update" class="btn btn-primary">আপডেট প্যাকেজ</button>
            </form>
        </div>
        <!-- script-for sticky-nav -->
        <script>
        $(document).ready(function() {
            var navoffeset = $(".header-main").offset().top;
            $(window).scroll(function() {
                var scrollpos = $(window).scrollTop(); 
                if (scrollpos >= navoffeset) {
                    $(".header-main").addClass("fixed");
                } else {
                    $(".header-main").removeClass("fixed");
                }
            });
        });
        </script>
        <!--inner block start here-->
        <div class="inner-block"></div>
        <!--inner block end here-->
        <!--copy rights start here-->
        <?php include('includes/footer.php');?>
        <!--COPY rights end here-->
    </div>
    <!--/content-inner-->
    <!--/sidebar-menu-->
    <?php include('includes/sidebarmenu.php');?>
    <div class="clearfix"></div>     
</div>
<script>
var toggle = true;

$(".sidebar-icon").click(function() {                
  if (toggle) {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  } else {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
  toggle = !toggle;
});
</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->      
</body>
</html>
<?php  ?>
