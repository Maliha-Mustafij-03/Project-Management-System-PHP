<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

// Check if the user is logged in, if not redirect to the login page
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit; // Stop further execution of the script if not logged in
}

// // Check if the user is an admin (assuming you have a session variable like 'user_type')
// $_SESSION['alogin'] = ($_SESSION['user_type'] == 'admin'); // Set to true if admin, false otherwise

// Get the folder parameter from the URL
if (isset($_GET['folder'])) {
    $folder = urldecode($_GET['folder']);
    
    // Fetch photos from the database for the specified folder
    $photos = [];

    // Prepare SQL query to fetch photos by folder
    $sql = "SELECT * FROM photos WHERE image_url LIKE :folderPath";
    $stmt = $dbh->prepare($sql);
    $folderPath = "uploads/$folder/%";  // Use a pattern to match folder-based photos
    $stmt->bindParam(':folderPath', $folderPath);
    $stmt->execute();
    
    // Fetch all matching photos
    $photos = $stmt->fetchAll();

    // Check if photos are found
    if (empty($photos)) {
        $message = "No photos found in this folder.";
    }
} else {
    $message = "No folder specified.";
    exit;
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Photos in Folder: <?php echo htmlentities($folder); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-2.1.4.min.js"></script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->     

<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet">SS
   
   


    <style>
         html, body {
    height: 100%; /* Ensure full height */
    margin: 0;    /* Remove margin to avoid unwanted scrollbars */
    overflow: auto; /* Allow scrolling when necessary */
}
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            overflow: auto; /* Allow scrolling when necessary */
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 1000;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .content {
            margin-left: 250px;
            margin-top: 120px; /* Increased margin-top to prevent content overlap with the fixed header */
            padding: 20px;
        }
        .photo-gallery {
            display: flex;
            flex-wrap: wrap;
        }
        .photo-item {
            width: 200px;
            margin: 10px;
            text-align: center;
        }
        .photo-item img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn-back {
            margin-bottom: 20px;
        }
        .modal-body img {
            width: 100%;
            max-height: 500px;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <?php include('includes/sidebarmenu.php'); ?>
    </div>

    <!-- Header -->
    <div class="header">
        <?php include('includes/header.php'); ?>
    </div>

    <!-- Content Area -->
    <div class="content">
        <div class="container">
            <h1>Photos in Folder: <?php echo htmlentities($folder); ?></h1>
            <a href="photo-gallery.php" class="btn btn-primary btn-back">Back to Folders</a>

            <?php
            // Display success or error message if present
            if (isset($_GET['message'])) {
                echo "<div class='alert alert-info'>" . htmlentities($_GET['message']) . "</div>";
            }

            if (isset($message)) {
                echo "<p>$message</p>";
            } else {
                ?>
                <div class="photo-gallery">
                    <?php
                    foreach ($photos as $photo) {
                        $photoUrl = $photo['image_url'];  // Get the full URL from the database
                        ?>
                        <div class="photo-item">
                            <img src="<?php echo htmlentities($photoUrl); ?>" alt="<?php echo htmlentities($photo['title']); ?>" data-toggle="modal" data-target="#photoModal" data-img="<?php echo htmlentities($photoUrl); ?>" data-photo-name="<?php echo htmlentities($photo['title']); ?>">
                            <p><?php echo htmlentities($photo['title']); ?></p>

                            <!-- Show Edit button to all users -->
                            <a href="edit-photo.php?photo=<?php echo urlencode($photo['id']); ?>&folder=<?php echo urlencode($folder); ?>" class="btn btn-warning btn-sm">Edit</a>

                            <!-- Show Delete button only for admin -->
                            <?php if (isset($_SESSION['alogin'])) { ?>
                                <a href="delete-photo.php?photo=<?php echo urlencode($photo['id']); ?>&folder=<?php echo urlencode($folder); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this photo?')">Delete</a>
                            <?php } ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            ?>
        </div>
    </div>

    <!-- Modal for Zooming Image -->
    <div class="modal fade" id="photoModal" tabindex="-1" role="dialog" aria-labelledby="photoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="photoModalLabel">View Photo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="" id="modalImage" alt="Photo">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Set the image source in the modal
        $('#photoModal').on('show.bs.modal', function (e) {
            var imageUrl = $(e.relatedTarget).data('img');
            var photoName = $(e.relatedTarget).data('photo-name');
            $('#modalImage').attr('src', imageUrl);
            $('#photoModalLabel').text('Viewing: ' + photoName);
        });
    </script>
</body>
</html>
