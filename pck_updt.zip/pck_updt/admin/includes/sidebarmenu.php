<?php
// Start the session at the top of the page
session_start();

// Ensure the necessary session variables are set before using them
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('Location: admin/logout.php'); // Redirect if no login found
    exit();
}
?>

<div class="sidebar-menu">
    <header class="logo1">
        <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
    </header>
    <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
    <div class="menu">
        <ul id="menu">
            <?php if (isset($_SESSION['alogin'])): ?>
                <!-- Admin menu: Display all menu items -->
                <li>
                    <a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a>
                </li>

                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> NCS Packages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="create-package.php">Create</a></li>
                        <li><a href="manage-packages.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Overview</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="create.php">Create</a></li>
                        <li><a href="package-overview.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Summary</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="procure_reportcreate.php">Create</a></li>
                        <li><a href="procure_reportmanage.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Financial Progress</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="MonitoringAndEvaluation.php">Create</a></li>
                        <li><a href="ManageFinanceReport.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Smart Card Expatriate</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="probascreate.php">Create</a></li>
                        <li><a href="manageprobas.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Smart Card Statistics</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="createstat.php">Create</a></li>
                        <li><a href="managestat.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>HR Meeting</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="hrcreate.php">Create</a></li>
                        <li><a href="managehr.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Media News</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="media.php">Create</a></li>
                        <li><a href="manage-media.php">Manage</a></li>
                    </ul>
                </li>
                <li>

                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>PD Sir's Commitment</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="news.php">Create</a></li>
                        <li><a href="whats-new.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="photo-gallery.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Photo Gallery Section</span><div class="clearfix"></div></a>
                </li>
                <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                
                    <li>
    <a href="/pck_updt/login.php"><i class="fa fa-users" aria-hidden="true"></i><span>Create User</span></a>
</li>
<li>
    <a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span><div class="clearfix"></div></a>
</li>

                
            <?php elseif (isset($_SESSION['userlogin'])): ?>
                <!-- User menu: Display menu items based on user type -->
                 <?php if (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'HR'): ?>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>HR Meeting</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="hrcreate.php">Create</a></li>
                        <li><a href="managehr.php">Manage</a></li>
                    </ul>
                </li>
                 <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Smartcard Expatriate'): ?>
                    <li>
                        <a href="user-dashboard.php"><i class="fa fa-tachometer"></i> <span>User Dashboard</span><div class="clearfix"></div></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Smart Card Expatriate</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="probascreate.php">Create</a></li>
                            <li><a href="manageprobas.php">Manage</a></li>
                        </ul>
                    </li>
                     <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Communication'): ?>
                    <li>
                        <a href="user-dashboard.php"><i class="fa fa-tachometer"></i> <span>User Dashboard</span><div class="clearfix"></div></a>
                    </li>
                    <li>
                        <a href="photo-gallery.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Photo Gallery Section</span><div class="clearfix"></div></a>
                    </li>
                    <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Media News</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="media.php">Create</a></li>
                        <li><a href="manage-media.php">Manage</a></li>
                    </ul>
                </li>
                 <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Procurement'): ?>
                    <li>
                        <a href="user-dashboard.php"><i class="fa fa-tachometer"></i> <span>User Dashboard</span><div class="clearfix"></div></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> NCS Packages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="create-package.php">Create</a></li>
                            <li><a href="manage-packages.php">Manage</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Summary</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="procure_reportcreate.php">Create</a></li>
                            <li><a href="procure_reportmanage.php">Manage</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Overview</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="create.php">Create</a></li>
                            <li><a href="package-overview.php">Manage</a></li>
                        </ul>
                    </li>
                     <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                      <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Finance'): ?>
                    <li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Financial Progress</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                                           <ul id="menu-academico-sub" >
                                           <li id="menu-academico-avaliacoes" ><a href="MonitoringAndEvaluation.php">Create</a></li>
                                            <li id="menu-academico-avaliacoes" ><a href="ManageFinanceReport.php">Manage</a></li>
                                          </ul>
                                        </li>
                                         <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Smartcard Statistics'): ?>
                    <li>
                        <a href="user-dashboard.php"><i class="fa fa-tachometer"></i> <span>User Dashboard</span><div class="clearfix"></div></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Smart Card Statistics</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="createstat.php">Create</a></li>
                            <li><a href="managestat.php">Manage</a></li>
                        </ul>
                    </li>
                     <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
            <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'Others'): ?>
                    
                     <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'PD Dept'): ?>
                    <li>
                        <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>PD Sir's Commitment</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                        <ul id="menu-academico-sub">
                            <li><a href="news.php">Create</a></li>
                            <li><a href="whats-new.php">Manage</a></li>
                        </ul>
                    </li>
               
 <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>

 <?php elseif (isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'View'): ?>


                <li>
                    <a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a>
                </li>

                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> NCS Packages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="create-package.php">Create</a></li>
                        <li><a href="manage-packages.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Overview</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="create.php">Create</a></li>
                        <li><a href="package-overview.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Procurement Summary</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="procure_reportcreate.php">Create</a></li>
                        <li><a href="procure_reportmanage.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Financial Progress</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="MonitoringAndEvaluation.php">Create</a></li>
                        <li><a href="ManageFinanceReport.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>HR Meeting</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="hrcreate.php">Create</a></li>
                        <li><a href="managehr.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Smart Card Expatriate</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="probascreate.php">Create</a></li>
                        <li><a href="manageprobas.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Smart Card Statistics</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="createstat.php">Create</a></li>
                        <li><a href="managestat.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Media News</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="media.php">Create</a></li>
                        <li><a href="manage-media.php">Manage</a></li>
                    </ul>
                </li>
                <li>

                    <a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>PD Sir's Commitment</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul id="menu-academico-sub">
                        <li><a href="news.php">Create</a></li>
                        <li><a href="whats-new.php">Manage</a></li>
                    </ul>
                </li>
                <li>
                    <a href="photo-gallery.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Photo Gallery Section</span><div class="clearfix"></div></a>
                </li>
                <li>
                    <a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true"></i>  <span>Back to Main Page</span><div class="clearfix"></div></a>
                </li>
                
                    <li>
    <a href="/pck_updt/login.php"><i class="fa fa-users" aria-hidden="true"></i><span>Create User</span></a>
</li>
<li>
    <a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span><div class="clearfix"></div></a>
</li>
            <?php endif; ?>
             <?php endif; ?>
        </ul>
    </div>
</div>
