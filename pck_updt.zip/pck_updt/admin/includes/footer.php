<!-- Footer Section -->
<div class="copy-right">
    <div class="container">
        <p class="wow zoomIn animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
            Project Management System 2024. All Rights Reserved.<br>
            IT Team. IDEA Project (Phase-2)
        </p>
    </div>
</div>

<!-- Footer Styles -->
<style>
    /* Footer Styles */
    .copy-right {
        background-color: #004d26;  /* Dark background color for the footer */
        color: #fff;             /* White text color */
        text-align: center;      /* Center-align the text */
        padding: 20px 0;         /* Add padding to top and bottom */
        font-family: Arial, sans-serif; /* Font family */
        position: relative;      /* Ensures no overlapping elements */
        border-top: 1px solid #444;  /* Optional: adds a subtle border to separate footer */
    }

    .copy-right .container {
        width: 100%;  /* Ensures the container takes full width */
        max-width: 1200px; /* Optional: max-width for the content */
        margin: 0 auto;  /* Centers the container */
        padding: 0 15px;  /* Optional: add padding to left and right */
    }

    .copy-right p {
        margin: 0;        /* Removes default margin from paragraph */
        padding: 0;       /* Removes default padding from paragraph */
        font-size: 14px;  /* Sets the font size */
        line-height: 1.5; /* Adjusts line height for readability */
    }

    .wow.zoomIn.animated {
        visibility: visible;
        animation-name: zoomIn;
        animation-duration: 1s;
        animation-timing-function: ease-out;
        animation-delay: 0.5s;
    }

    @keyframes zoomIn {
        0% {
            opacity: 0;
            transform: scale(0.3);
        }
        100% {
            opacity: 1;
            transform: scale(1);
        }
    }
</style>
