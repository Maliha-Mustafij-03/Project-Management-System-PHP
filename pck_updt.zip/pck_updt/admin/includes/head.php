<?php


// Check if user is logged in (either as admin or regular user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');  // Redirect to the login page if neither is logged in
    exit;  // Ensure script stops after redirect
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        /* Define the slow color change effect from Red to Yellow */
        @keyframes colorChange {
            0% { 
                color: red; 
                text-shadow: 0 0 5px red, 0 0 10px red; /* Red shadow effect */
            }
            50% { 
                color: yellow; 
                text-shadow: 0 0 5px yellow, 0 0 10px yellow; /* Yellow shadow effect */
            }
            100% { 
                color: red; 
                text-shadow: 0 0 5px red, 0 0 10px red; /* Red shadow effect */
            }
        }

        /* Apply the animations to the menu items */
        .live-package {
            animation: colorChange 3s infinite;  /* Slow color transition */
            font-weight: bold;
            text-transform: uppercase;  /* Uppercase letters for emphasis */
            font-size: 18px;  /* Make the text slightly bigger */
            transition: text-shadow 0.3s ease; /* Smooth transition for shadow effect */
        }

        .upcoming-package {
            animation: colorChange 3s infinite;  /* Slow color transition */
            font-weight: bold;
            text-transform: uppercase;  /* Uppercase letters for emphasis */
            font-size: 18px;  /* Make the text slightly bigger */
            transition: text-shadow 0.3s ease; /* Smooth transition for shadow effect */
        }
    </style>
</head>
<body>
    <!-- top-header -->
    <?php if (isset($_SESSION['userlogin']) && !empty($_SESSION['userlogin'])): ?>
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="main.php"><i class="fa fa-home"></i></a></li>
                    
                    <li><a href="admin/user-dashboard.php">Go to Dashboard</a></li> <!-- Dashboard link for user -->
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
                    <li class="tol">Welcome :</li>
                    <li class="sig"><?php echo htmlentities($_SESSION['userlogin']);?></li>
                    <li class="sigi"><a href="logout.php">/ Logout</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php elseif (isset($_SESSION['alogin']) && !empty($_SESSION['alogin'])): ?>
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="main.php"><i class="fa fa-home"></i></a></li>
                    <li class="prnt"><a href="admin/dashboard.php">Admin Dashboard</a></li> <!-- Admin Dashboard link -->
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
                    <li class=""><a href="admin/index.php"> 
                        <center>Identification System For Enhancing Access to Services (IDEA PHASE-2)</center></a></li>
                    <li class="tol">Helpline : 01684422703</li>                
                    <li class="sig"><a href="index.php" >Back to Home</a></li> 
                    <li class="tol">Welcome Admin :</li>
                    <li class="sig"><?php echo htmlentities($_SESSION['alogin']);?></li>
                    <li class="sigi"><a href="logout.php">/ Logout</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="index.php"><i class="fa fa-home"></i></a></li>
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s"> 
                    
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php else: ?>
        <!-- For users who are not logged in (no session or other credentials set) -->
        
    <?php endif; ?>
    <!-- /top-header -->

    <!-- footer-btm -->
    <div class="footer-btm wow fadeInLeft animated" data-wow-delay=".5s">
        <div class="container">
            <div class="navigation">
                <nav class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                        <nav class="cl-effect-1">
                            <ul class="nav navbar-nav">
                                <li><a href="main.php">Home</a></li>
                                <li><a href="package-list.php"> ALL NCS/GD Packages</a></li>
                                <li><a href="live-package.php" class="live-package"> LIVE NCS/GD Packages</a></li>
                                <li><a href="close-package.php"> CLOSED NCS/GD Packages</a></li>
                                <li><a href="upcoming-package.php" class="upcoming-package"> UPCOMING NCS/GD Packages</a></li>
                                <li><a href="admin/gallery.php">Photo Gallery</a></li>
                                <div class="clearfix"></div>
                            </ul>
                        </nav>
                    </div><!-- /.navbar-collapse -->    
                </nav>
            </div>

            <div class="clearfix"></div>
        </div>
    </div>
    <!-- /footer-btm -->
</body>
</html>
