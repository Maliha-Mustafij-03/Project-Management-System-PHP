<?php
session_start();
include('includes/config.php');

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit;
}

if (isset($_GET['id'])) {
    $reportId = $_GET['id'];
    
    // Fetch the report details
    $sql = "SELECT * FROM media_reports WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $reportId, PDO::PARAM_INT);
    $query->execute();
    $report = $query->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>View Media Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
    <style>
        .pdf-container {
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        .iframe-container {
            width: 100%;
            height: 600px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>View Media Report</li>
        </ol>
        <div class="container">
            <h2>View Media Report</h2>
            <div class="form-group">
                <label>Report Date</label>
                <input type="text" class="form-control" value="<?php echo htmlentities($report['report_date']); ?>" readonly>
            </div>
            <div class="form-group">
                <label>Division</label>
                <input type="text" class="form-control" value="<?php echo htmlentities($report['division']); ?>" readonly>
            </div>
            <div class="form-group">
                <label>Media</label>
                <input type="text" class="form-control" value="<?php echo htmlentities($report['media']); ?>" readonly>
            </div>
            <div class="form-group">
                <label>Topic</label>
                <input type="text" class="form-control" value="<?php echo htmlentities($report['topic']); ?>" readonly>
            </div>
            <div class="form-group">
                <label>Attachments</label>
                <div class="pdf-container">
                    <?php
                    $attachments = explode(',', $report['attachments']);
                    foreach ($attachments as $attachment) {
                        if ($attachment) {
                            // Display PDF using iframe or object
                            echo "<h5>Viewing PDF: $attachment</h5>";
                            echo "<div class='iframe-container'>";

                            // Check if it's a valid PDF file
                            $fileExtension = pathinfo($attachment, PATHINFO_EXTENSION);
                            if (strtolower($fileExtension) === 'pdf') {
                                // Embed the PDF using <iframe>
                                echo "<iframe src='$attachment' width='100%' height='600px' frameborder='0'></iframe>";

                                // Alternative way using <object> tag
                                // echo "<object data='$attachment' type='application/pdf' width='100%' height='600px'>
                                //        Your browser does not support PDFs. <a href='$attachment'>Download the PDF</a> instead.
                                //      </object>";
                            }
                            echo "</div>";
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php include('includes/footer.php'); ?>
    </div>
</body>
</html>
