<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

// Get the folder list inside 'uploads/'
$folderPath = "uploads/";
$folders = [];

if (is_dir($folderPath)) {
    // Open the uploads directory
    $dir = opendir($folderPath);

    // Loop through the directory to find all subdirectories (folders)
    while (($folder = readdir($dir)) !== false) {
        if ($folder != '.' && $folder != '..' && is_dir($folderPath . $folder)) {
            // Add folder to the folders array
            $folders[] = $folder;
        }
    }
    closedir($dir);
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Photo Folders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <script src="js/jquery-2.1.4.min.js"></script>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>
    <!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->     
    <style>
        html, body {
    height: 100%; /* Ensure full height */
    margin: 0;    /* Remove margin to avoid unwanted scrollbars */
    overflow: auto; /* Allow scrolling when necessary */
}



        /* Sidebar and Header Styling */
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 1000;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .content {
            margin-left: 250px;
            margin-top: 120px; /* Increased space to prevent overlap with the header */
            padding: 20px;
        }
        h1 {
            margin-top: 0;
            font-size: 28px;
            color: #333;
            font-weight: 600;
        }
        .folder-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start; /* Align items to the left */
            gap: 10px; /* Set a smaller gap between items */
            margin: 0;
        }
        .folder-item {
            width: 180px; /* Reduce the width to make it more compact */
            padding: 15px; /* Reduce padding for a smaller folder box */
            background: #f4f4f4;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease;
            margin-bottom: 40px; /* Reduced margin-bottom for less space between items */
        }
        .folder-item:hover {
            background-color: #f0ad4e;
            transform: translateY(-5px);
        }
        .folder-item a {
            display: block;
            color: #333;
            font-size: 1.4em;
            text-decoration: none;
        }
        .folder-item i {
            font-size: 50px; /* Smaller icon size */
            margin-bottom: 10px;
            color: #5bc0de; /* Blue color */
        }
        .folder-item:nth-child(odd) {
            background-color: #ffcd56; /* Yellow background for odd items */
        }
        .folder-item:nth-child(even) {
            background-color: #90EE90; /* Tea background for even items */
        }
        .add-photo-btn {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <?php include('includes/sidebarmenu.php'); ?>
    </div>

    <!-- Header -->
    <div class="header">
        <?php include('includes/header.php'); ?>
    </div>

    <!-- Content Area -->
    <div class="content">
        <div class="container">
            <h1>Photo Folders</h1>

            <!-- Add Photo Button -->
            <div class="add-photo-btn">
                <a href="add-photo.php" class="btn btn-success">
                    <i class="fa fa-plus"></i> Add Photo
                </a>
            </div>

            <!-- Folder List -->
            <div class="folder-list">
                <?php if (!empty($folders)) {
                    foreach ($folders as $folder) { ?>
                        <div class="folder-item">
                            <a href="view-folder.php?folder=<?php echo urlencode($folder); ?>">
                                <i class="fa fa-folder"></i>
                                <?php echo htmlentities($folder); ?>
                            </a>
                        </div>
                    <?php }
                } else { ?>
                    <p>No folders available.</p>
                <?php } ?>
            </div>
        </div>
    </div>
</body>
</html>
