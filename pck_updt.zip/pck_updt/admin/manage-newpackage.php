<?php
session_start();
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
} else {
    // Check if form is submitted
    if(isset($_POST['update'])) {
        $packageId = $_POST['package_id'];
        $category = $_POST['category'];
        $status = $_POST['status'];
        $submissionDeadline = $_POST['submission_deadline'];
        $relevance = $_POST['relevance'];
        $imageUpdate = '';

        // Check if image is being uploaded
        if(!empty($_FILES['package_image']['name'])) {
            $target_dir = "packageimages/";
            $target_file = $target_dir . basename($_FILES["package_image"]["name"]);
            if(move_uploaded_file($_FILES["package_image"]["tmp_name"], $target_file)) {
                $imageUpdate = ", PackageImage=:packageImage";
            } else {
                $error = "Failed to upload image.";
            }
        }

        // Update package information in the database
        $sql = "UPDATE package_overview 
                SET category=:category, status=:status, submission_deadline=:submissionDeadline, 
                    relevance=:relevance $imageUpdate
                WHERE id=:packageId";

        $query = $dbh->prepare($sql);
        $query->bindParam(':category', $category, PDO::PARAM_STR);
        $query->bindParam(':status', $status, PDO::PARAM_STR);
        $query->bindParam(':submissionDeadline', $submissionDeadline, PDO::PARAM_STR);
        $query->bindParam(':relevance', $relevance, PDO::PARAM_STR);
        if($imageUpdate) {
            $query->bindParam(':packageImage', $_FILES['package_image']['name'], PDO::PARAM_STR);
        }
        $query->bindParam(':packageId', $packageId, PDO::PARAM_INT);
        $query->execute();

        if ($query) {
            $msg = "Package Updated Successfully";
        } else {
            $error = "Something went wrong. Please try again";
        }
    }

    // Fetch package details
    $packageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $sql = "SELECT * FROM package_overview WHERE id=:packageId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':packageId', $packageId, PDO::PARAM_INT);
    $query->execute();
    $package = $query->fetch(PDO::FETCH_OBJ);
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Update Package</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
    <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .form-group img {
            max-width: 150px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!--header start here-->
        <?php include('includes/header.php');?>
        <div class="clearfix"> </div>    
        <!--header end here-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Update Package</li>
        </ol>
        <div class="container">
            <h2>Update Package</h2>
            <?php if($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
            <?php } else if($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
            <?php } ?>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="package_id" value="<?php echo htmlspecialchars($package->id); ?>">
                <div class="form-group">
                    <label>Category</label>
                    <input type="text" name="category" value="<?php echo htmlspecialchars($package->category); ?>" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control" required>
                        <option value="Open" <?php echo $package->status == 'Open' ? 'selected' : ''; ?>>Open</option>
                        <option value="Close" <?php echo $package->status == 'Close' ? 'selected' : ''; ?>>Close</option>
                        <option value="Awarded" <?php echo $package->status == 'Awarded' ? 'selected' : ''; ?>>Awarded</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Submission Deadline</label>
                    <input type="date" name="submission_deadline" value="<?php echo htmlspecialchars($package->submission_deadline); ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label>Relevance</label>
                    <textarea name="relevance" class="form-control" required><?php echo htmlspecialchars($package->relevance); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Package Image</label>
                    <input type="file" name="package_image" class="form-control">
                    <?php if($package->packageImage) { ?>
                        <img src="packageimages/<?php echo htmlspecialchars($package->packageImage); ?>" alt="Package Image">
                    <?php } ?>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Update Package</button>
            </form>
        </div>
        <!-- script-for sticky-nav -->
        <script>
        $(document).ready(function() {
            var navoffeset = $(".header-main").offset().top;
            $(window).scroll(function() {
                var scrollpos = $(window).scrollTop(); 
                if(scrollpos >= navoffeset) {
                    $(".header-main").addClass("fixed");
                } else {
                    $(".header-main").removeClass("fixed");
                }
            });
        });
        </script>
        <!--inner block start here-->
        <div class="inner-block"></div>
        <!--inner block end here-->
        <!--copy rights start here-->
        <?php include('includes/footer.php');?>
        <!--COPY rights end here-->
    </div>
    <!--/content-inner-->
    <!--/sidebar-menu-->
    <?php include('includes/sidebarmenu.php');?>
    <div class="clearfix"></div>     
</div>
<script>
var toggle = true;

$(".sidebar-icon").click(function() {                
  if (toggle) {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  } else {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }
  toggle = !toggle;
});
</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->      
</body>
</html>
<?php } ?>
