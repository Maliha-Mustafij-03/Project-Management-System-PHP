<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Initialize variables to avoid notices
$error = "";
$msg = "";
$searchQuery = "";

// Check if user is logged in (both admin and user)
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Handle deletion
if (isset($_GET['delete'])) {
    $reportId = $_GET['delete'];
    $sql = "DELETE FROM media_reports WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $reportId, PDO::PARAM_INT);
    if ($query->execute()) {
        $msg = "Media Report Deleted Successfully";
        // Redirect after deletion to prevent resubmission
        header('Location: manage-media.php');
        exit;
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Handle search query
if (isset($_POST['search'])) {
    $searchQuery = $_POST['search_query'];
}

// Fetch all media reports based on search query
$sql = "SELECT * FROM media_reports WHERE 
        report_date LIKE :searchQuery OR
        division LIKE :searchQuery OR
        media LIKE :searchQuery OR
        topic LIKE :searchQuery";
$query = $dbh->prepare($sql);
$query->bindValue(':searchQuery', '%' . $searchQuery . '%', PDO::PARAM_STR);
$query->execute();
$reports = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Manage Media Reports</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <style>
        .errorWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #dd3d36; }
        .succWrap { padding: 10px; margin: 0 0 20px 0; background: #fff; border-left: 4px solid #5cb85c; }
        .search-form {
            margin: 20px 0;
        }
        .page-container {
            padding-top: 40px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */
        }

        /* Bold and black text style */
        .table th, .table td {
            font-weight: bold;
            color: black;
        }
        .search-form label {
            font-weight: bold;
            color: black;
        }
        .breadcrumb-item {
            font-weight: bold;
            color: black;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">হোম</a><i class="fa fa-angle-right"></i>ম্যানেজ মিডিয়া রিপোর্ট</li>
        </ol>

        <!-- Search Form -->
        <div class="container search-form">
            <form method="POST">
                <div class="form-group">
                    <label for="search_query">রিপোর্ট অনুসন্ধান</label>
                    <input type="text" id="search_query" name="search_query" class="form-control" value="<?php echo htmlentities($searchQuery); ?>" placeholder="Search by report date, division, media, or topic" required>
                </div>
                <button type="submit" name="search" class="btn btn-primary">অনুসন্ধান</button>
            </form>
        </div>

        <!-- Results Section -->
        <div class="container">
            <h2>গণমাধ্যমে প্রকাশিত ও সম্প্রচারিত সংবাদ এবং বিশ্লেষণ</h2>
            
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>তারিখ</th>
                        <th>বিভাগ</th>
                        <th>মিডিয়া</th>
                        <th>বিষয়</th>
                        <th>সংযুক্তি</th>
                        <th>অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $report) { ?>
                        <tr>
                            <td><?php echo htmlentities($report['report_date']); ?></td>
                            <td><?php echo htmlentities($report['division']); ?></td>
                            <td><?php echo htmlentities($report['media']); ?></td>
                            <td><?php echo htmlentities($report['topic']); ?></td>
                            <td>
                                <?php
                                $attachments = explode(',', $report['attachments']);
                                foreach ($attachments as $attachment) {
                                    if ($attachment) {
                                        echo "<a href='$attachment' target='_blank'>View PDF</a><br>";
                                    }
                                }
                                ?>
                            </td>
                            <td>
                                <?php if (isset($_SESSION['alogin'])) { ?>
                                    <a href="edit-media.php?id=<?php echo $report['id']; ?>" class="btn btn-warning">এডিট</a>
                                    <a href="?delete=<?php echo $report['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this report?')">মুছুন</a>
                                <?php } elseif (isset($_SESSION['userlogin'])) { ?>
                                    <a href="edit-media.php?id=<?php echo $report['id']; ?>" class="btn btn-warning">এডিট</a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <?php include('includes/footer.php'); ?>
    </div>

    <?php include('includes/sidebarmenu.php'); ?>
    <div class="clearfix"></div>
</body>
</html>
