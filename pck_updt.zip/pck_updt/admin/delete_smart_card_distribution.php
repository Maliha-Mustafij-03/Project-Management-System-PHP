<?php
session_start();
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0) {    
    header('location:index.php');
    exit;
}

if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];

    // Delete the conditions first (to maintain referential integrity)
    $sqlConditions = "DELETE FROM smart_card_conditions WHERE distribution_id = :deleteId";
    $queryConditions = $dbh->prepare($sqlConditions);
    $queryConditions->bindParam(':deleteId', $deleteId, PDO::PARAM_INT);
    $queryConditions->execute();

    // Now delete the distribution record
    $sql = "DELETE FROM smart_card_distribution WHERE id = :deleteId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':deleteId', $deleteId, PDO::PARAM_INT);
    if ($query->execute()) {
        header('Location: managerequire.php');
        exit;
    } else {
        echo "Error: Unable to delete.";
    }
} else {
    header('Location: managerequire.php');
    exit;
}
?>
