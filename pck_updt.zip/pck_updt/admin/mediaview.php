<?php
session_start();
include('includes/config.php');

// Initialize variables to avoid notices
$error = "";
$msg = "";
$searchQuery = "";

// Check if user is logged in (both admin and user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit;
}

// Handle deletion
if (isset($_GET['delete'])) {
    $reportId = $_GET['delete'];
    $sql = "DELETE FROM media_reports WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $reportId, PDO::PARAM_INT);
    if ($query->execute()) {
        $msg = "Media Report Deleted Successfully";
        // Redirect after deletion to prevent resubmission
        header('Location: manage-media.php');
        exit;
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Handle search query
if (isset($_POST['search'])) {
    $searchQuery = $_POST['search_query'];
}

// Fetch all media reports based on search query
$sql = "SELECT * FROM media_reports WHERE 
        report_date LIKE :searchQuery OR
        division LIKE :searchQuery OR
        media LIKE :searchQuery OR
        topic LIKE :searchQuery";
$query = $dbh->prepare($sql);
$query->bindValue(':searchQuery', '%' . $searchQuery . '%', PDO::PARAM_STR);
$query->execute();
$reports = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Manage Media Reports</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type="text/css" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fa;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .errorWrap, .succWrap {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-size: 16px;
        }
        .errorWrap { 
            background: #f8d7da; 
            border-left: 4px solid #dc3545;
            color: #721c24; 
        }
        .succWrap { 
            background: #d4edda; 
            border-left: 4px solid #28a745; 
            color: #155724;
        }
        .page-container {
            padding-top: 60px;
            padding-left: 20px;
            padding-right: 20px;
        }
        .breadcrumb-item {
            font-weight: 600;
            color: #4e73df;
        }
        .breadcrumb-item a {
            color: #4e73df;
        }
        .breadcrumb-item a:hover {
            color: #0066cc;
        }
        h2 {
            font-size: 32px;
            font-weight: 600;
            color: #4e73df;
            margin-bottom: 20px;
        }
        .table th, .table td {
            font-size: 16px;
            font-weight: 500;
            color: #333;
            padding: 12px 15px;
        }
        .table {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .table-bordered {
            border: none;
        }
        .table thead {
            background-color: #4e73df;
            color: white;
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f8f9fc;
        }
        .search-form {
            margin: 20px 0;
        }
        .search-form label {
            font-weight: 600;
            color: #333;
        }
        .form-control {
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
        }
        .btn {
            border-radius: 5px;
            font-weight: 600;
            padding: 10px 15px;
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
        }
        .btn-primary:hover {
            background-color: #375a7f;
        }
        .btn-warning {
            background-color: #f39c12;
            border: none;
        }
        .btn-warning:hover {
            background-color: #e67e22;
        }
        .btn-danger {
            background-color: #e74a3b;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c0392b;
        }
        .btn-info {
            background-color: #17a2b8;
            border: none;
        }
        .btn-info:hover {
            background-color: #138496;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Manage Media Reports</li>
        </ol>

        <!-- Search Form -->
        <div class="container search-form">
            <form method="POST">
                <div class="form-group">
                    <label for="search_query">Search Reports</label>
                    <input type="text" id="search_query" name="search_query" class="form-control" value="<?php echo htmlentities($searchQuery); ?>" placeholder="Search by report date, division, media, or topic" required>
                </div>
                <button type="submit" name="search" class="btn btn-primary">Search</button>
            </form>
        </div>

        <!-- Results Section -->
        <div class="container">
            <h2>Manage Media Reports</h2>
            
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Report Date</th>
                            <th>Division</th>
                            <th>Media</th>
                            <th>Topic</th>
                            <th>Attachments</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $report) { ?>
                            <tr>
                                <td><?php echo htmlentities($report['id']); ?></td>
                                <td><?php echo htmlentities($report['report_date']); ?></td>
                                <td><?php echo htmlentities($report['division']); ?></td>
                                <td><?php echo htmlentities($report['media']); ?></td>
                                <td><?php echo htmlentities($report['topic']); ?></td>
                                <td>
                                    <?php
                                    $attachments = explode(',', $report['attachments']);
                                    foreach ($attachments as $attachment) {
                                        if ($attachment) {
                                            echo "<a href='$attachment' target='_blank' class='btn btn-info btn-sm'>View PDF</a><br>";
                                        }
                                    }
                                    ?>
                                </td>
                                
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php include('includes/footer.php'); ?>
    </div>

   
    <div class="clearfix"></div>
</body>
</html>
