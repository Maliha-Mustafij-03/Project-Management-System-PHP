<?php
session_start();

ini_set('display_errors', 0); // Hide all errors and notices
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

// Check if user is logged in
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit;
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Prepare SQL query to delete the record
    $sql_delete = "DELETE FROM financial_progress WHERE Serial_No = :delete_id";
    $delete_query = $dbh->prepare($sql_delete);
    $delete_query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);

    // Execute the deletion query
    if ($delete_query->execute()) {
        $_SESSION['msg'] = "Deleted Successfully";
    } else {
        $_SESSION['msg'] = "Error deleting record.";
    }

    // Redirect back to the same page to reflect changes
    header('Location: ManageFinanceReport.php');
    exit;
}

// Search functionality
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Set the number of records per page
$records_per_page = 10;

// Get the current page or set it to 1 if not set
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for the SQL query
$offset = ($page - 1) * $records_per_page;

// Prepare the SQL query to search across multiple fields
$sql = "SELECT * FROM financial_progress 
        WHERE Source_of_fund LIKE :search 
        OR Total_Cost LIKE :search 
        OR Cumulative_Cost LIKE :search
        OR Financial_year LIKE :search
        OR Current_fy_progress LIKE :search
        OR Comments LIKE :search
        LIMIT :limit OFFSET :offset";

// Prepare and execute the query
$query = $dbh->prepare($sql);
$search_term = "%" . $search . "%"; // Add wildcard for searching across fields
$query->bindParam(':search', $search_term, PDO::PARAM_STR);
$query->bindParam(':limit', $records_per_page, PDO::PARAM_INT);
$query->bindParam(':offset', $offset, PDO::PARAM_INT);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);

// Get the total number of rows for pagination
$sql_count = "SELECT COUNT(*) FROM financial_progress 
              WHERE Source_of_fund LIKE :search 
              OR Total_Cost LIKE :search 
              OR Cumulative_Cost LIKE :search
              OR Financial_year LIKE :search
              OR Current_fy_progress LIKE :search
              OR Comments LIKE :search";

$count_query = $dbh->prepare($sql_count);
$count_query->bindParam(':search', $search_term, PDO::PARAM_STR);
$count_query->execute();
$total_rows = $count_query->fetchColumn();

// Calculate the total number of pages
$total_pages = ceil($total_rows / $records_per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Financial Progress</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .btn {
            margin-right: 5px;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            height: 100%;
            overflow-y: auto;
        }

        .pagination {
            display: inline-block;
            margin-top: 20px;
        }

        .pagination a {
            padding: 10px 15px;
            margin: 0 5px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #000;
        }

        .pagination a.active {
            background-color: #007bff;
            color: white;
        }

        .pagination a:hover {
            background-color: #ddd;
        }

        /* Custom styles for search box */
        .search-box {
            width: 50%; /* Increase the width of the search box */
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .search-button {
            padding: 8px 16px;
            margin-left: 5px;
        }
        
        .alert {
            display: none;
            margin-top: 20px;
        }
    </style>

    <script>
        // Function to hide the success/error message after 4 seconds
        $(document).ready(function() {
            if ($('.alert').length) {
                setTimeout(function() {
                    $('.alert').fadeOut();
                }, 4000); // Hide message after 4 seconds
            }
        });
    </script>
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar -->
        
        <!-- Main Content -->
        <div class="main-content">
            <?php include('includes/header.php'); ?>
            <?php include('includes/sidebarmenu.php'); ?>
            <center>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="main.php">Home</a><i class="fa fa-angle-right"></i>Manage Financial Progress</li>
                </ol>

                <h3>Manage Financial Progress</h3>

                <!-- Search Form -->
                <form method="post" action="ManageFinanceReport.php">
                    <input type="text" name="search" class="search-box" placeholder="Search any data" value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn btn-primary search-button">Search</button>
                </form>

                <!-- Display Success or Error Messages -->
                <?php
                if (isset($_SESSION['msg'])) {
                    echo "<div class='alert alert-info'>{$_SESSION['msg']}</div>";
                    unset($_SESSION['msg']); // Clear the message after display
                }
                ?>

                <!-- Table to display data -->
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Source of Fund</th>
                            <th>Total Cost</th>
                            <th>Cumulative Cost</th>
                            <th>Last Date of Cumulative Cost</th>
                            <th>Cumulative Cost Percentage</th>
                            <th>Annual DPP Budget</th>
                            <th>Financial Year</th>
                            <th>Current FY Progress</th>
                            <th>Last Date of FY Cost</th>
                            <th>Current FY Progress Percentage</th>
                            <th>Current FY Allocation</th>
                            <th>Fund Release Installments</th>
                            <th>Funds Released So Far</th>
                            <th>Comments</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if($query->rowCount() > 0) {
                            foreach ($results as $result) {
                                echo "<tr>";
                                echo "<td>{$result->Serial_No}</td>";
                                echo "<td>{$result->Source_of_fund}</td>";
                                echo "<td>{$result->Total_Cost}</td>";
                                echo "<td>{$result->Cumulative_Cost}</td>";
                                echo "<td>{$result->Last_date_of_Cumulative_Cost}</td>";
                                echo "<td>{$result->Cumulative_Cost_percentage}</td>";
                                echo "<td>{$result->Annual_dpp_budget}</td>";
                                echo "<td>{$result->Financial_year}</td>";
                                echo "<td>{$result->Current_fy_progress}</td>";
                                echo "<td>{$result->Last_date_of_fy_cost}</td>";
                                echo "<td>{$result->current_fy_progress_per}</td>";
                                echo "<td>{$result->Current_FY_Allocation}</td>";
                                echo "<td>{$result->Fund_Release_Installments}</td>";
                                echo "<td>{$result->Funds_Released_So_Far}</td>";
                                echo "<td>{$result->Comments}</td>";
                                echo "<td>
                                    <a href='edit_monitoring.php?Serial_No=".$result->Serial_No."' class='btn btn-primary'>Edit</a>
                                    <a href='ManageFinanceReport.php?delete_id=".$result->Serial_No."' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>
                                </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='15'>No data found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>

                <!-- Pagination Links -->
                <div class="pagination">
                    <?php if($page > 1): ?>
                        <a href="ManageFinanceReport.php?page=<?php echo $page - 1; ?>">Previous</a>
                    <?php endif; ?>

                    <?php
                    // Display pagination links
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $active = ($i == $page) ? 'active' : '';
                        echo "<a href='ManageFinanceReport.php?page=$i' class='$active'>$i</a>";
                    }
                    ?>

                    <?php if($page < $total_pages): ?>
                        <a href="ManageFinanceReport.php?page=<?php echo $page + 1; ?>">Next</a>
                    <?php endif; ?>
                </div>

            </center>
        </div>
    </div>
</body>
</html>
