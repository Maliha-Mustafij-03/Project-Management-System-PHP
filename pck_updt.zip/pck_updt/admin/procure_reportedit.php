<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Get the record ID from the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the record details
    $sql = "SELECT * FROM procurement_plan WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        $error = "Record not found!";
    }
} else {
    $error = "ID parameter missing!";
}

// Handle form submission for editing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $total_packages = $_POST['total_packages'];
    $previous_contracts = $_POST['previous_contracts'];
    $signed_contracts = $_POST['signed_contracts'];
    $implementation_progress_rate = $_POST['implementation_progress_rate'];
    $packages_under_evaluation = $_POST['packages_under_evaluation'];
    $remaining_packages = $_POST['remaining_packages'];

    // Update the record
    $sql = "UPDATE procurement_plan SET total_packages = :total_packages, previous_contracts = :previous_contracts, signed_contracts = :signed_contracts, implementation_progress_rate = :implementation_progress_rate, packages_under_evaluation = :packages_under_evaluation, remaining_packages = :remaining_packages WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':total_packages', $total_packages);
    $query->bindParam(':previous_contracts', $previous_contracts);
    $query->bindParam(':signed_contracts', $signed_contracts);
    $query->bindParam(':implementation_progress_rate', $implementation_progress_rate);
    $query->bindParam(':packages_under_evaluation', $packages_under_evaluation);
    $query->bindParam(':remaining_packages', $remaining_packages);
    $query->bindParam(':id', $id);

    try {
        $query->execute();
        $msg = "Record updated successfully!";
        header("Location: procure_reportmanage.php");
        exit;
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}

?>
<?php include('includes/sidebarmenu.php'); ?>
  <?php include('includes/header.php'); ?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Procurement Progress</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        .container {
            margin-top: 40px;
            padding-left: 200px; /* Adjust based on sidebar width */sssss
        }
/* Custom styles for the form and inputs */
.form-group {
    margin-bottom: 15px;
}

.control-label {
    font-weight: bold;
}

.form-control {
    border-radius: 5px;
    padding: 10px;
    font-size: 16px;
    /* Allow resizing for all input fields */
    resize: both;
    min-height: 50px; /* Minimum height for text inputs */
    min-width: 150px; /* Minimum width for text inputs */
    max-width: 100%;   /* Prevent fields from overflowing */
}

textarea.form-control {
    resize: both;  /* Keep resize for text areas */
    min-height: 100px; /* Minimum height for text areas */
    min-width: 150px;  /* Minimum width for text areas */
    max-width: 100%;
}

/* Success and error messages */
.alert {
    margin-top: 20px;
}

/* Button Styling */
.btn-success {
    background-color: #28a745;
    border-color: #28a745;
}

    </style>
</head>
<body>
    <div class="container">
        <h3 class="mt-5">Edit Procurement Progress</h3>

        <!-- Display error or success message -->
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php elseif ($msg): ?>
            <div class="alert alert-success"><?php echo $msg; ?></div>
        <?php endif; ?>

        <!-- Edit Form -->
        <form method="POST" class="form-horizontal mt-4">
            <!-- Total Packages -->
            <div class="form-group">
                <label for="total_packages" class="control-label col-sm-2">২০২৪-২৫  ক্রয় পরিকল্পনায় অন্তর্ভুক্ত মোট প্যাকেজ সংখ্যা</label>
                <div class="col-sm-8">
                    <input type="text" name="total_packages" class="form-control" value="<?php echo htmlspecialchars($result['total_packages']); ?>" id="total_packages">
                </div>
            </div>

            <!-- Previous Contracts -->
            <div class="form-group">
                <label for="previous_contracts" class="control-label col-sm-2">পূর্বে চুক্তি সম্পন্ন প্যাকেজ</label>
                <div class="col-sm-8">
                    <input type="text" name="previous_contracts" class="form-control" value="<?php echo htmlspecialchars($result['previous_contracts']); ?>" id="previous_contracts">
                </div>
            </div>

            <!-- Signed Contracts -->
            <div class="form-group">
                <label for="signed_contracts" class="control-label col-sm-2">২০২৪-২৫ চুক্তি সম্পাদিত প্যাকেজ সংখ্যা</label>
                <div class="col-sm-8">
                    <input type="text" name="signed_contracts" class="form-control" value="<?php echo htmlspecialchars($result['signed_contracts']); ?>" id="signed_contracts">
                </div>
            </div>

            <!-- Implementation Progress Rate -->
            <div class="form-group">
                <label for="implementation_progress_rate" class="control-label col-sm-2">বাস্তবায়ন অগ্রগতির হার (%)</label>
                <div class="col-sm-8">
                    <input type="text" name="implementation_progress_rate" class="form-control" value="<?php echo htmlspecialchars($result['implementation_progress_rate']); ?>" id="implementation_progress_rate">
                </div>
            </div>

            <!-- Packages Under Evaluation -->
            <div class="form-group">
                <label for="packages_under_evaluation" class="control-label col-sm-2">দরপত্র প্রক্রিয়াধীন প্যাকেজ সংখ্যা (মূল্যায়ন চলমান, NOA, ইত্যাদি)*</label>
                <div class="col-sm-8">
                    <textarea name="packages_under_evaluation" class="form-control" id="packages_under_evaluation"><?php echo htmlspecialchars($result['packages_under_evaluation']); ?></textarea>
                </div>
            </div>

            <!-- Remaining Packages -->
            <div class="form-group">
                <label for="remaining_packages" class="control-label col-sm-2">অবশিষ্ট প্যাকেজসমূহ</label>
                <div class="col-sm-8">
                    <textarea name="remaining_packages" class="form-control" id="remaining_packages"><?php echo htmlspecialchars($result['remaining_packages']); ?></textarea>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="form-group">
                <div class="col-sm-8 col-sm-offset-2">
                    <button type="submit" name="update" class="btn btn-success">Update</button>
                </div>
            </div>
        </form>

    </div>
</body>
</html>
