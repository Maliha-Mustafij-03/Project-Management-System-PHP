<?php
session_start();
error_reporting(E_ERROR | E_PARSE);  // Hide warnings, but show errors
ini_set('display_errors', 0);  // Disable display of errors in the browser
include('includes/config.php');

// Initialize variables
$msg = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $created_at = $_POST['created_at'];  // Get the date input
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Insert the data into the database
    $sql = "INSERT INTO urgent_news (created_at, title, description) VALUES (:created_at, :title, :description)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':created_at', $created_at, PDO::PARAM_STR);  // Bind the date
    $query->bindParam(':title', $title, PDO::PARAM_STR);
    $query->bindParam(':description', $description, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();

    // Success or error message
    if ($lastInsertId) {
        $msg = "PD Sir's Commitment posted successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Project Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <style>
  <style>
        body, html {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }

        .page-container {
            display: flex;
            flex-direction: row;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
        }

        .header {
            background: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
            width: calc(100% - 250px); /* Adjust width to leave space for the sidebar */
            margin-left: 250px; /* Space for the sidebar */
            position: fixed;
            top: 0;
            left: 0; /* Align with the sidebar */
            z-index: 1000;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .content {
            margin-top: 80px; /* Space for the header */
            margin-left: 250px; /* Space for the sidebar */
            padding: 20px;
            width: calc(100% - 250px); /* Remaining width for content */
            overflow-y: auto;
        }

        footer {
            background: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
            margin-top: 20px;
        }

        .alert {
            margin-top: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            font-size: 16px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            box-sizing: border-box;
        }

        .form-control:focus {
            border-color: #5bc0de;
            box-shadow: 0 0 8px rgba(91, 188, 222, 0.5);
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            color: white;
        }
    </style>


    </style>
    <!-- Sidebar -->
    <?php include('includes/sidebarmenu.php'); ?>

    <!-- Content Area -->
    <div class="container-fluid">
        <div class="row">
            <!-- Main content starts after sidebar -->
            <div class="col-md-9 col-sm-12">
                <div class="content">
                    <div class="header">
                        <?php include('includes/header.php'); ?>
                    </div>
                    <div class="urgent-news">
                        <h1>PD Sir's Commitment</h1>
                        <?php if ($msg) { ?>
                            <div class="alert alert-success" role="alert"><?php echo htmlentities($msg); ?></div>
                        <?php } ?>
                        <?php if ($error) { ?>
                            <div class="alert alert-danger" role="alert"><?php echo htmlentities($error); ?></div>
                        <?php } ?>
                        <form method="post">
                            <div class="form-group">
                                <label for="created_at">Date</label>
                                <input type="date" class="form-control" id="created_at" name="created_at" required>
                            </div>
                            <div class="form-group">
                                <label for="title">Title</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="5" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2024 Project Management System
    </footer>

    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
sss