<?php
session_start();
include('includes/config.php');

// Check if user is logged in
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Get form data
        $Serial_No = $_POST['Serial_No'];
        $Source_of_fund = $_POST['Source_of_fund'];
        $Total_Cost = $_POST['Total_Cost'];
        $Cumulative_Cost = $_POST['Cumulative_Cost'];
        $Last_date_of_Cumulative_Cost = $_POST['Last_date_of_Cumulative_Cost'];
        $Cumulative_Cost_percentage = $_POST['Cumulative_Cost_percentage'];
        $Annual_dpp_budget = $_POST['Annual_dpp_budget'];
        $Financial_year = $_POST['Financial_year'];
        $Current_fy_progress = $_POST['Current_fy_progress'];
        $Last_date_of_fy_cost = $_POST['Last_date_of_fy_cost'];
        $current_fy_progress_per = $_POST['current_fy_progress_per'];
        
        // New fields
        $Current_FY_Allocation = $_POST['Current_FY_Allocation'];
        $Fund_Release_Installments = $_POST['Fund_Release_Installments'];
        $Funds_Released_So_Far = $_POST['Funds_Released_So_Far'];
        $Comments = $_POST['Comments'];

        // SQL query to update the record
        $sql = "UPDATE financial_progress SET
                    Source_of_fund = :Source_of_fund,
                    Total_Cost = :Total_Cost,
                    Cumulative_Cost = :Cumulative_Cost,
                    Last_date_of_Cumulative_Cost = :Last_date_of_Cumulative_Cost,
                    Cumulative_Cost_percentage = :Cumulative_Cost_percentage,
                    Annual_dpp_budget = :Annual_dpp_budget,
                    Financial_year = :Financial_year,
                    Current_fy_progress = :Current_fy_progress,
                    Last_date_of_fy_cost = :Last_date_of_fy_cost,
                    current_fy_progress_per = :current_fy_progress_per,
                    Current_FY_Allocation = :Current_FY_Allocation,
                    Fund_Release_Installments = :Fund_Release_Installments,
                    Funds_Released_So_Far = :Funds_Released_So_Far,
                    Comments = :Comments
                WHERE Serial_No = :Serial_No";
        
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':Source_of_fund', $Source_of_fund);
        $stmt->bindParam(':Total_Cost', $Total_Cost);
        $stmt->bindParam(':Cumulative_Cost', $Cumulative_Cost);
        $stmt->bindParam(':Last_date_of_Cumulative_Cost', $Last_date_of_Cumulative_Cost);
        $stmt->bindParam(':Cumulative_Cost_percentage', $Cumulative_Cost_percentage);
        $stmt->bindParam(':Annual_dpp_budget', $Annual_dpp_budget);
        $stmt->bindParam(':Financial_year', $Financial_year);
        $stmt->bindParam(':Current_fy_progress', $Current_fy_progress);
        $stmt->bindParam(':Last_date_of_fy_cost', $Last_date_of_fy_cost);
        $stmt->bindParam(':current_fy_progress_per', $current_fy_progress_per);
        $stmt->bindParam(':Current_FY_Allocation', $Current_FY_Allocation);
        $stmt->bindParam(':Fund_Release_Installments', $Fund_Release_Installments);
        $stmt->bindParam(':Funds_Released_So_Far', $Funds_Released_So_Far);
        $stmt->bindParam(':Comments', $Comments);
        $stmt->bindParam(':Serial_No', $Serial_No);

        // Execute the query
        if ($stmt->execute()) {
            // Redirect to the report page if update is successful
            header('location:Report.php');
            exit;
        } else {
            echo "Error updating record.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
