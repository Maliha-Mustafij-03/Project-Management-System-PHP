<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {    
    header('location:index.php');
    exit;
}

// Check if ID is provided for editing
if (isset($_GET['Serial_No'])) {
    $Serial_No = $_GET['Serial_No'];

    // Fetch the record to edit
    $sql = "SELECT * FROM financial_progress WHERE Serial_No = :Serial_No";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':Serial_No', $Serial_No);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_OBJ);

    // If record does not exist, redirect to manage page
    if (!$result) {
        header('location:Report.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Monitoring And Evaluation Creation</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/style.css" rel='stylesheet' type='text/css' />

    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        /* Flexbox layout for Sidebar and Main Content */
        .wrapper {
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2d3e50;
            padding: 20px;
            color: white;
            position: fixed;
            height: 100vh;
        }

        .main-content {
            margin-left: 250px; /* Ensure the content doesn't go under the sidebar */
            padding: 20px;
            flex-grow: 1;
            background-color: #f4f7fc;
        }

        .container {
            width: 100%;
            margin: 0 auto;
            padding: 40px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        h3 {
            color: #4CAF50;
            text-align: center;
            margin-bottom: 40px;
            font-size: 32px;
        }

        form {
            display: grid;
            grid-template-columns: 1fr 1fr; /* Two columns */
            gap: 20px;
        }

        label {
            font-weight: bold;  /* Makes the text bold */
            color: black;  /* Makes the text color black */
            display: block;
        }

        input[type="text"], input[type="number"], input[type="date"], select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            margin-bottom: 15px;
        }

        input[type="submit"], input[type="reset"], input[type="button"] {
            width: 140px;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #4CAF50;
            color: white;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover {
            background-color: #45a049;
        }

        /* Styling for form rows to display two fields in one line */
        .form-row {
            display: flex;
            justify-content: space-between;
        }

        .form-row .form-group {
            width: 48%; /* Making each input field 48% of the row */
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .wrapper {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                position: relative;
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            form {
                grid-template-columns: 1fr;
            }

            .form-row {
                flex-direction: column; /* Stacking the form fields vertically */
            }

            .form-row .form-group {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <?php include('includes/sidebarmenu.php'); ?>

        <div class="main-content">
            <?php include('includes/header.php'); ?>
            <center>
                <h3>Edit Financial Progress</h3>

                <!-- Edit form -->
                <form method="post" action="edit_monitoring_save.php">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="Source_of_fund">অর্থের উৎস</label>
                            <input type="text" name="Source_of_fund" value="<?= htmlspecialchars($result->Source_of_fund) ?>" >
                        </div>
                        <div class="form-group">
                            <label for="Total_Cost">মোট প্রকল্প বরাদ্দ</label>
                            <input type="number" name="Total_Cost" value="<?= htmlspecialchars($result->Total_Cost) ?>" >
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Cumulative_Cost">ক্রমপুঞ্জিত ব্যয়</label>
                            <input type="number" name="Cumulative_Cost" value="<?= htmlspecialchars($result->Cumulative_Cost) ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="Last_date_of_Cumulative_Cost">ক্রমোপঞ্জিত ব্যয়ের তারিখ</label>
                            <input type="date" name="Last_date_of_Cumulative_Cost" value="<?= htmlspecialchars($result->Last_date_of_Cumulative_Cost) ?>">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Cumulative_Cost_percentage">ক্রমঃপুঞ্জিত অগ্রগতির হার</label>
                            <input type="number" name="Cumulative_Cost_percentage" value="<?= htmlspecialchars($result->Cumulative_Cost_percentage) ?>" >
                        </div>
                        <div class="form-group">
                            <label for="Annual_dpp_budget">বার্ষিক উন্নয়ন কর্মসূচিতে বরাদ্দ</label>
                            <input type="number" name="Annual_dpp_budget" value="<?= htmlspecialchars($result->Annual_dpp_budget) ?>">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Financial_year">চলতি অর্থবছর</label>
                            <input type="text" name="Financial_year" value="<?= htmlspecialchars($result->Financial_year) ?>">
                        </div>
                        <div class="form-group">
                            <label for="Current_fy_progress">চলতি অর্থ বছরের ব্যায়</label>
                            <input type="number" name="Current_fy_progress" value="<?= htmlspecialchars($result->Current_fy_progress) ?>">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Last_date_of_fy_cost">আরএডিপিতে বরাদ্ধ</label>
                            <input type="text" name="Last_date_of_fy_cost" value="<?= htmlspecialchars($result->Last_date_of_fy_cost) ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="current_fy_progress_per">চলতি অর্থ বছরের অগ্রগতির হার</label>
                            <input type="number" name="current_fy_progress_per" value="<?= htmlspecialchars($result->current_fy_progress_per) ?>" required>
                        </div>
                    </div>

                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="Current_FY_Allocation">আরডিপিপিপিতে বরাদ্দ</label>
                            <input type="number" name="Current_FY_Allocation" value="<?= htmlspecialchars($result->Current_FY_Allocation) ?>" >
                        </div> 
                        <div class="form-group">
                            <label for="Fund_Release_Installments">ছাড়কৃত কিস্তি</label>
                            <input type="number" name="Fund_Release_Installments" value="<?= htmlspecialchars($result->Fund_Release_Installments) ?>" >
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="Funds_Released_So_Far">চলতি অর্থবছরে অর্থ ছাড়</label>
                            <input type="number" name="Funds_Released_So_Far" value="<?= htmlspecialchars($result->Funds_Released_So_Far) ?>" >
                        </div>
                        <!-- <div class="form-group">
                            <label for="Comments">মন্তব্য</label>
                            <input type="text" name="Comments" value="<?= htmlspecialchars($result->Comments) ?>" required>
                        </div> -->
                    </div>

                    <div>
                        <input type="hidden" name="Serial_No" value="<?= $result->Serial_No ?>">
                        <button type="submit" class="btn btn-success">Update</button>
                        <a href="Report.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </center>
        </div>
    </div>
</body>
</html>
