<?php
session_start();
include('includes/config.php');

// Fetch photo details if photo ID is provided
if (isset($_GET['photo'])) {
    $photoId = $_GET['photo'];
    
    // Fetch the photo from the database
    $sql = "SELECT * FROM photos WHERE id = :id";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':id', $photoId);
    $stmt->execute();
    $photo = $stmt->fetch();

    if (!$photo) {
        echo "Photo not found.";
        exit;
    }

    // Handle the form submission when the user clicks update
    if (isset($_POST['update'])) {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $image_url = $photo['image_url']; // Default to current image URL

        // Check if a new file is uploaded
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
            $targetDir = "uploads/" . $photo['folder'] . "/";
            $targetFile = $targetDir . basename($_FILES['photo']['name']);
            
            // Upload the new photo
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
                // Update the image URL in the database
                $image_url = $targetFile;
            } else {
                $errorMsg = "<div class='alert alert-danger'>Error uploading the file.</div>";
            }
        }

        // Update the photo details (title, description, and possibly the image)
        $sql = "UPDATE photos SET title = :title, description = :description, image_url = :image_url WHERE id = :id";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':image_url', $image_url);
        $stmt->bindParam(':id', $photoId);
        
        if ($stmt->execute()) {
            // Set success message
            $successMsg = "<div class='alert alert-success'>Photo updated successfully.</div>";
            
            // Redirect to prevent form resubmission and show updated results
            header("Location: edit-photo.php?photo=" . $photoId);
            exit;
        } else {
            $errorMsg = "<div class='alert alert-danger'>Error updating the photo.</div>";
        }
    }
} else {
    echo "No photo specified.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Photo</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-2.1.4.min.js"></script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->     

<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 1000;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .content {
            margin-left: 250px;
            margin-top: 60px;
            padding: 20px;
        }
        h1 {
            margin-top: 50px;
            color: blue;
            font-size: 24px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <?php include('includes/sidebarmenu.php'); ?>
</div>

<!-- Header -->
<div class="header">
    <?php include('includes/header.php'); ?>
</div>

<!-- Content Area -->
<div class="content">
    <div class="container">
        <h1>Edit Photo</h1>

        <!-- Display Success or Error Message -->
        <?php if (isset($successMsg)) echo $successMsg; ?>
        <?php if (isset($errorMsg)) echo $errorMsg; ?>

        <form method="POST" action="edit-photo.php?photo=<?php echo $photoId; ?>" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlentities($photo['title']); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" id="description" name="description"><?php echo htmlentities($photo['description']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="current_image">Current Image:</label><br>
                <img src="<?php echo htmlentities($photo['image_url']); ?>" alt="Current Image" width="200"><br><br>
                <input type="file" class="form-control" id="photo" name="photo">
            </div>

            <button type="submit" name="update" class="btn btn-primary">Update Photo</button>
        </form>
    </div>
</div>

</body>
</html>
