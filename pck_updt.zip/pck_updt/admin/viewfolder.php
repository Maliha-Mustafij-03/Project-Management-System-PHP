<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

// Get the folder parameter from the URL
if (isset($_GET['folder'])) {
    $folder = urldecode($_GET['folder']);
    
    // Fetch photos from the database for the specified folder
    $photos = [];

    // Prepare SQL query to fetch photos by folder
    $sql = "SELECT * FROM photos WHERE image_url LIKE :folderPath";
    $stmt = $dbh->prepare($sql);
    $folderPath = "uploads/$folder/%";  // Use a pattern to match folder-based photos
    $stmt->bindParam(':folderPath', $folderPath);
    $stmt->execute();
    
    // Fetch all matching photos
    $photos = $stmt->fetchAll();

    // Check if photos are found
    if (empty($photos)) {
        $message = "No photos found in this folder.";
    }
} else {
    $message = "No folder specified.";
    exit;
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Photos in Folder: <?php echo htmlentities($folder); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <script src="js/jquery-2.1.4.min.js"></script>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            overflow: hidden;
        }

        .header {
            background-color: #2c3e50;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            font-size: 26px;
            font-weight: bold;
        }

        .header .btn {
            background-color: #16a085;
            color: white;
            padding: 12px 25px;
            font-size: 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .header .btn:hover {
            background-color: #1abc9c;
        }

        .header .btn-back-main {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .header .btn-back-folder {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .content {
            margin-top: 100px;
            padding: 30px;
        }

        h1 {
            color: #34495e;
            font-size: 28px;
            font-weight: 700;
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 40px;
        }

        .photo-gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .photo-item {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            width: 250px;
            overflow: hidden;
            transition: all 0.3s ease-in-out;
        }

        .photo-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .photo-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease-in-out;
        }

        .photo-item:hover img {
            transform: scale(1.2);
            object-fit: contain;
        }

        .photo-item img:hover {
            opacity: 0.85;
        }

        .photo-item p {
            padding: 12px;
            background-color: #2980b9;
            text-align: center;
            font-size: 1.1em;
            color: #fff;
            font-weight: bold;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        /* Adjust modal to make images larger */
        .modal-dialog {
            width: 90%; /* Increased width */
            max-width: 90%; /* Ensure it fits smaller screens */
            margin: auto;
            padding: 0;
        }

        .modal-body {
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .modal-body img {
            width: 100%;
            max-width: 100%;
            max-height: 90vh; /* Allow more height for the image */
            object-fit: contain;
        }

        .modal-header {
            background-color: #2980b9;
            color: #fff;
            position: relative;
        }

        .modal-header .close {
            font-size: 40px;
            color: red;
            opacity: 1;
            border: none;
            background: none;
            padding: 0;
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .modal-header .close:hover {
            color: darkred;
        }

        .modal-footer {
            background-color: #ecf0f1;
        }

        .modal-footer .btn-secondary {
            background-color: #16a085;
            border: none;
            color: #fff;
        }

        .modal-footer .btn-secondary:hover {
            background-color: #1abc9c;
        }

    </style>

    <!-- Header -->
    <div class="header">
        Photo Gallery - Folder: <?php echo htmlentities($folder); ?>
        <!-- Back to Main Page Button -->
        <a href='/pck_updt/main.php' class="btn btn-back-main">Back to Main Page</a>
        <!-- Back to Folders Button -->
        <a href="gallery.php" class="btn btn-back-folder">Back to Folders</a>
    </div>

    <!-- Content Area -->
    <div class="content">
        <div class="container">
            <h1>Photos in Folder: <?php echo htmlentities($folder); ?></h1>

            <?php
            // Display success or error message if present
            if (isset($_GET['message'])) {
                echo "<div class='alert alert-info'>" . htmlentities($_GET['message']) . "</div>";
            }

            if (isset($message)) {
                echo "<p>$message</p>";
            } else {
                ?>
                <div class="photo-gallery">
                    <?php
                    foreach ($photos as $photo) {
                        $photoUrl = $photo['image_url'];  // Get the full URL from the database
                        ?>
                        <div class="photo-item">
                            <img src="<?php echo htmlentities($photoUrl); ?>" alt="<?php echo htmlentities($photo['title']); ?>" data-toggle="modal" data-target="#photoModal" data-img="<?php echo htmlentities($photoUrl); ?>" data-photo-name="<?php echo htmlentities($photo['title']); ?>">
                            <p><?php echo htmlentities($photo['title']); ?></p>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            }
            ?>
        </div>
    </div>

    <!-- Modal for Zooming Image -->
    <div class="modal fade" id="photoModal" tabindex="-1" role="dialog" aria-labelledby="photoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="photoModalLabel">View Photo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="" id="modalImage" alt="Photo">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Set the image source in the modal
        $('#photoModal').on('show.bs.modal', function (e) {
            var imageUrl = $(e.relatedTarget).data('img');
            var photoName = $(e.relatedTarget).data('photo-name');
            $('#modalImage').attr('src', imageUrl);
            $('#photoModalLabel').text('Viewing: ' + photoName);
        });

        // Reset image size when the modal is closed
        $('#photoModal').on('hidden.bs.modal', function () {
            var modalImage = $('#modalImage');
            modalImage.css({
                'width': '100%',
                'height': '100%',
                'object-fit': 'contain'
            });
        });
    </script>

</body>
</html>
