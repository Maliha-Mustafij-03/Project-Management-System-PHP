<?php
// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';  // Change as needed
$password = '';  // Change as needed

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize search term
$searchTerm = '';

// Check if the search form is submitted
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search']; // Capture the search term entered by the user

    // SQL query with UNION to search across multiple tables: main category, subcategory, and items
    $query = "(
                SELECT id, category_name AS name, total_count, 'main' AS source FROM snid_card_main_data
                WHERE category_name LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )
              UNION
              (
                SELECT id, subcategory_name AS name, subcategory_total AS total_count, 'subcategory' AS source FROM snid_card_subcategory_data
                WHERE subcategory_name LIKE '%$searchTerm%' 
                OR description LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )
              UNION
              (
                SELECT id, item_name AS name, item_count AS total_count, 'item' AS source FROM snid_card_item_data
                WHERE item_name LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )";
} else {
    // Default query to fetch all data if no search term is provided
    $query = "SELECT id, category_name AS name, total_count, 'main' AS source FROM snid_card_main_data";
}

// Fetch data based on the query
$result = $conn->query($query);

// Delete record
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Delete related items first (cascade delete)
    $conn->query("DELETE FROM snid_card_item_data WHERE subcategory_id IN (SELECT id FROM snid_card_subcategory_data WHERE main_category_id = $id)");

    // Delete related subcategories
    $conn->query("DELETE FROM snid_card_subcategory_data WHERE main_category_id = $id");

    // Delete the main category
    $conn->query("DELETE FROM snid_card_main_data WHERE id = $id");

    // Redirect after deletion
    header("Location: managestat.php");
    exit();
}
?>

<?php include('includes/header.php'); ?>
<?php include('includes/sidebarmenu.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>স্মার্ট কার্ড তথ্য পরিচালনা</title>
    
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
   
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
    

    <style>
        body, html {
            overflow-x: hidden;
            height: 100%;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 40px;
            
            padding-left: 200px; /* Adjust based on sidebar width */
        }
    /* Body and overall page styling */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f7f9fc; /* Soft light background */
        color: #2c3e50; /* Dark text for contrast */
        margin: 0;
        padding: 0;
    }

    /* Search bar styling */
    .search-bar {
        margin-bottom: 20px;
        text-align: center; /* Center the search bar */
    }

    .search-bar input {
        width: 350px;
        font-weight: bold;
        color: #2c3e50;
        border: 2px solid #2c3e50;
        padding: 10px;
        border-radius: 25px; /* Rounded input corners */
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow for the input */
        font-size: 16px;
        transition: all 0.3s ease;
    }

    .search-bar input:focus {
        border-color: #f39c12;
        outline: none;
        box-shadow: 0px 4px 6px rgba(243, 156, 18, 0.3); /* Focus effect */
    }

    .search-bar button {
        background-color: #f39c12;
        color: white;
        font-weight: bold;
        border: none;
        padding: 12px 30px;
        border-radius: 25px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.3s ease;
    }

    .search-bar button:hover {
        background-color: #e67e22;
    }

    /* Table styling */
    .table th, .table td {
        text-align: center;
        vertical-align: middle;
        font-weight: bold;
        color: #2c3e50; /* Dark text for better visibility */
        font-size: 16px; /* Increase font size for readability */
    }

    .table thead {
        background-color: #34495e;
        color: white; /* White text on dark background */
        font-weight: bold;
        font-size: 18px;
    }

    .table-bordered {
        border: 2px solid #ddd; /* Light border around table */
        border-radius: 8px; /* Rounded corners */
    }

    .table td {
        padding: 12px;
    }

    /* Styling for table rows */
    .table .table-light {
        background-color: #f9f9f9; /* Very light grey background */
        color: #333;
    }

    .table-secondary {
        background-color: #eaf2f8; /* Light blue background for subcategories */
        color: #1a252f;
    }

    /* Hover effect for rows */
    .table-hover tbody tr:hover {
        background-color: #f39c12;
        color: white;
    }

    
    }

    /* Button styling */
.btn-warning, .btn-danger {
    background-color: #f39c12;  /* Default background for the warning button */
    color: #000;  /* Make text black */
    font-weight: bold;  /* Bold text */
    padding: 12px 30px;  /* Consistent padding */
    border-radius: 5px;
    font-size: 16px;  /* Consistent font size */
    text-transform: uppercase;
    transition: all 0.3s ease;
    display: inline-block;  /* Ensure buttons are inline */
    width: 150px;  /* Set a consistent width for all buttons */
    text-align: center;  /* Center-align text */
    margin: 5px 0;  /* Margin between buttons */
}

/* Hover effect for buttons */
.btn-warning:hover, .btn-danger:hover {
    background-color: #e67e22;  /* Slightly darker background on hover */
    color: white;  /* Text becomes white on hover */
}

/* Specific styling for the delete button */
.btn-danger {
    background-color: #e74c3c;  /* Default red background for the delete button */
}

.btn-danger:hover {
    background-color: #c0392b;  /* Darker red background on hover */
}

    /* Heading styles */
    h2, h4 {
        font-weight: bold;
        color: #2c3e50;
        font-size: 28px; /* Increase heading size for visibility */
        text-align: center;
        margin-bottom: 20px;
    }

    /* Adding a vibrant background for table rows */
    .table-striped tbody tr:nth-child(odd) {
        background-color: #f0f3f4; /* Slightly off-white background for odd rows */
    }

    .table-striped tbody tr:nth-child(even) {
        background-color: #ecf0f1; /* Light grey for even rows */
    }

    .table-striped tbody tr:hover {
        background-color: #f39c12;
        color: white;
    }
</style>


</head>
<body>

<div class="container mt-5">
    <h2>স্মার্ট কার্ড তথ্য পরিচালনা</h2>
    
    <!-- Search Bar -->
    <form method="POST" action="" class="form-inline mb-3 search-bar">
        <input type="text" class="form-control" name="search" placeholder="অনুসন্ধান করুন" value="<?= htmlspecialchars($searchTerm); ?>" required>
        <button type="submit" class="btn btn-primary ml-2">অনুসন্ধান</button>
    </form>

    <!-- Main Category Table -->
    <div class="scrollable-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ক্রম নং</th>
                    <th>নাম</th>
                    <th>মোট সংখ্যা</th>
                    <th>অ্যাকশন</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0) : ?>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= $row['total_count']; ?></td>
                            <td>
                                <a href="editstat.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">সম্পাদনা</a>
                                <a href="viewstat.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">দেখুন</a>
                                <a href="managestat.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('আপনি কি নিশ্চিতভাবে এই শ্রেণীটি মুছে ফেলতে চান?')">মুছে ফেলুন</a>
                            </td>
                        </tr>

                        <!-- Fetch Subcategories for each Main Category -->
                        <?php if ($row['source'] === 'main') : ?>
                            <?php
                            $mainCategoryId = $row['id'];
                            $subquery = "SELECT * FROM snid_card_subcategory_data WHERE main_category_id = $mainCategoryId";
                            $subresult = $conn->query($subquery);
                            while ($subcategory = $subresult->fetch_assoc()) :
                            ?>
                                <tr class="table-secondary">
                                    <td colspan="4">
                                        <strong>সাব ক্যাটাগরি নাম:</strong> <?= htmlspecialchars($subcategory['subcategory_name']); ?><br>
                                        <strong>বিশদ বিবরনী::</strong> <?= htmlspecialchars($subcategory['description']); ?><br>
                                        <strong>মোট সংখ্যা:</strong> <?= $subcategory['subcategory_total']; ?>
                                    </td>
                                </tr>

                                <!-- Fetch Items for each Subcategory -->
                                <?php
                                $subcategoryId = $subcategory['id'];
                                $itemquery = "SELECT * FROM snid_card_item_data WHERE subcategory_id = $subcategoryId";
                                $itemresult = $conn->query($itemquery);
                                ?>

                                <tr class="table-light">
                                    <td colspan="4">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>আইটেম নাম</th>
                                                    <th>আইটেম সংখ্যা</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($item = $itemresult->fetch_assoc()) : ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($item['item_name']); ?></td>
                                                        <td><?= $item['item_count']; ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4" class="text-center">কোনও রেকর্ড পাওয়া যায়নি।</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>

<?php $conn->close(); ?>
