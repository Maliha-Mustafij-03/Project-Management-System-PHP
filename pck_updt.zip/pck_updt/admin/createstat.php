<?php
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';  // Change as needed
$password = '';  // Change as needed
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Insert main category data
    $category_name = $_POST['category_name'];

    // Initialize total count for main category to 0
    $main_total_count = 0;
    $subcategories = $_POST['subcategories'];

    // Insert main category data
    $sql = "INSERT INTO snid_card_main_data (category_name, total_count) 
            VALUES ('$category_name', 0)";  // Set initial total count as 0

    if ($conn->query($sql) === TRUE) {
        $main_category_id = $conn->insert_id; // Get the last inserted ID
        
        // Insert each subcategory and calculate its total
        foreach ($subcategories as $subcategory) {
            $subcategory_name = isset($subcategory['subcategory_name']) ? $subcategory['subcategory_name'] : null;
            $description = isset($subcategory['description']) ? $subcategory['description'] : null;
            $subcategory_total = isset($subcategory['subcategory_total']) ? (int)$subcategory['subcategory_total'] : 0;

            // Update main total count
            $main_total_count += $subcategory_total;

            // Insert subcategory data with description
            $sql_subcategory = "INSERT INTO snid_card_subcategory_data (main_category_id, subcategory_name, description, subcategory_total) 
                                VALUES ($main_category_id, '$subcategory_name', '$description', $subcategory_total)";
            $conn->query($sql_subcategory);
            $subcategory_id = $conn->insert_id;

            // Insert items for the subcategory
            foreach ($subcategory['items'] as $item) {
                $item_name = isset($item['name']) ? $item['name'] : null;
                $item_count = isset($item['count']) ? (int)$item['count'] : 0;

                $sql_item = "INSERT INTO snid_card_item_data (subcategory_id, item_name, item_count) 
                             VALUES ($subcategory_id, '$item_name', $item_count)";
                $conn->query($sql_item);
            }
        }

        // Update the main category total count after all subcategories are added
        $sql_update_main = "UPDATE snid_card_main_data SET total_count = $main_total_count WHERE id = $main_category_id";
        $conn->query($sql_update_main);

        $success_message = "Data saved successfully!";
    } else {
        $error_message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<?php include('includes/header.php');?>
<?php include('includes/sidebarmenu.php');?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NID কার্ড ডেটা ইনপুট</title>
    
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body, html {
            overflow-x: hidden;
            height: 100%;
            font-family: 'Arial', sans-serif;
        }
        .container {
            padding-top: 60px;
            padding-left: 250px;
        }
         
        .success-message, .error-message {
            display: none;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            z-index: 9999;
        }
        .error-message {
            background-color: #dc3545;
        }
        .btn {
            margin-top: 10px;
        }
        .btn-primary, .btn-secondary, .btn-success {
            background-color: #007bff;
            border: none;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-success {
            background-color: #28a745;
        }
    </style>
</head>
<body>

<div class="success-message" id="successMessage"><?= isset($success_message) ? $success_message : ''; ?></div>
<div class="error-message" id="errorMessage"><?= isset($error_message) ? $error_message : ''; ?></div>

<div class="container">
    <h2>স্মার্ট কার্ড ডেটা ইনপুট ফর্ম</h2>
    <form action="" method="post">
        <div class="form-group">
            <label for="category_name">নাম:</label>
            <input type="text" class="form-control" id="category_name" name="category_name">
        </div>

        <h3>সাব ক্যাটাগরী</h3>
        <div id="subcategories">
            <!-- Default Subcategory -->
            <div class="form-group subcategory" id="subcategory-0">
                <label for="subcategory_name">সাব ক্যাটাগরীর নাম:</label>
                <select class="form-control" name="subcategories[0][subcategory_name]">
                    <option value="" disabled selected>নির্বাচন করুন</option>
                    <option value="কার্যক্রম">কার্যক্রম</option>
                    <option value="মুদ্রণ চলমান এলাকা">মুদ্রণ চলমান এলাকা</option>
                    <option value="উপজেলা ও থানা ভিত্তিক মুদ্রণের তথ্য">উপজেলা ও থানা ভিত্তিক মুদ্রণের তথ্য</option>
                    <option value="বিতরণ এলাকা">বিতরণ এলাকা</option>
                    <option value="প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরণ">প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরণ</option>
                    <option value="বীর মুক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রণ ও প্রেরণ">বীর মুক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রণ ও প্রেরণ</option>
                    <option value="ব্ল্যাংক কার্ডের হিসাব">ব্ল্যাংক কার্ডের হিসাব</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                </select>
            </div>

            <div class="form-group subcategory">
                <label for="description[]">বিশদ বিবরনী:</label>
                <textarea class="form-control" name="subcategories[0][description]"></textarea>
            </div>
            <div class="form-group subcategory">
                <h5>এই সাব ক্যাটাগরীর আইটেম</h5>
                <div class="items-list" id="items-list-0">
                    <div class="form-group item">
                        <label>আইটেমের নাম:</label>
                        <input type="text" class="form-control" name="subcategories[0][items][0][name]">
                        <label>আইটেমের পরিমাণ:</label>
                        <input type="number" class="form-control" name="subcategories[0][items][0][count]" oninput="updateSubcategoryTotal(0)">
                    </div>
                </div>
                <button type="button" class="btn btn-primary" onclick="addItem(0)">আইটেম যোগ করুন</button>
                <button type="button" class="btn btn-danger" onclick="removeItem(0)">আইটেম মুছুন</button>
                <br>
                <label for="subcategory_total[]">সাব ক্যাটাগরীর মোট:</label>
                <input type="number" class="form-control" name="subcategories[0][subcategory_total]" readonly>
            </div>
        </div>

        <button type="button" class="btn btn-primary" onclick="addSubcategory()">আরো সাব ক্যাটাগরী যোগ করুন</button>
        
        
        <h4>সব উপশ্রেণীর মোট: <span id="main-category-total">0</span></h4>
        
        <button type="submit" class="btn btn-success">ডেটা সংরক্ষণ করুন</button>
    </form>
</div>

<script>
    let subcategoryCount = 1;
    let mainTotalCount = 0;

    function addSubcategory() {
        const subcategoryIndex = subcategoryCount++;
        const subcategoryHTML = `
            <div class="form-group subcategory" id="subcategory-${subcategoryIndex}">
                <label for="subcategory_name">সাব ক্যাটাগরীর নাম:</label>
                <select class="form-control" name="subcategories[${subcategoryIndex}][subcategory_name]">
                    <option value="" disabled selected>নির্বাচন করুন</option>
                    <option value="কার্যক্রম">কার্যক্রম</option>
                    <option value="মুদ্রণ চলমান এলাকা">মুদ্রণ চলমান এলাকা</option>
                    <option value="উপজেলা ও থানা ভিত্তিক মুদ্রণের তথ্য">উপজেলা ও থানা ভিত্তিক মুদ্রণের তথ্য</option>
                    <option value="বিতরণ এলাকা">বিতরণ এলাকা</option>
                    <option value="প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরণ">প্রবাসী বাংলাদেশীদের স্মার্ট কার্ড প্রেরণ</option>
                    <option value="বীর মুক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রণ ও প্রেরণ">বীর মুক্তিযোদ্ধা খচিত স্মার্ট কার্ড মুদ্রণ ও প্রেরণ</option>
                    <option value="ব্ল্যাংক কার্ডের হিসাব">ব্ল্যাংক কার্ডের হিসাব</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                </select>
            </div>
            <div class="form-group subcategory">
                <label for="description[]">বিশদ বিবরনী:</label>
                <textarea class="form-control" name="subcategories[${subcategoryIndex}][description]"></textarea>
            </div>
            <div class="form-group subcategory">
                <h5>এই সাব ক্যাটাগরীর আইটেম</h5>
                <div class="items-list" id="items-list-${subcategoryIndex}">
                    <div class="form-group item">
                        <label>আইটেমের নাম:</label>
                        <input type="text" class="form-control" name="subcategories[${subcategoryIndex}][items][0][name]">
                        <label>আইটেমের পরিমাণ:</label>
                        <input type="number" class="form-control" name="subcategories[${subcategoryIndex}][items][0][count]" oninput="updateSubcategoryTotal(${subcategoryIndex})">
                    </div>
                </div>
                <button type="button" class="btn btn-primary" onclick="addItem(${subcategoryIndex})">আইটেম যোগ করুন</button>
                <button type="button" class="btn btn-danger" onclick="removeItem(${subcategoryIndex})">আইটেম মুছুন</button>
                <br>
                <label for="subcategory_total[]">সাব ক্যাটাগরীর মোট:</label>
                <input type="number" class="form-control" name="subcategories[${subcategoryIndex}][subcategory_total]" readonly>
            </div>
        `;
        document.getElementById("subcategories").insertAdjacentHTML("beforeend", subcategoryHTML);
    }

    function removeSubcategory(index) {
        const subcategoryElement = document.getElementById(`subcategory-${index}`);
        if (subcategoryElement) {
            subcategoryElement.remove();
        }
    }

    function addItem(subcategoryIndex) {
        const itemHTML = `
            <div class="form-group item">
                <label>আইটেমের নাম:</label>
                <input type="text" class="form-control" name="subcategories[${subcategoryIndex}][items][][name]">
                <label>আইটেমের পরিমাণ:</label>
                <input type="number" class="form-control" name="subcategories[${subcategoryIndex}][items][][count]" oninput="updateSubcategoryTotal(${subcategoryIndex})">
            </div>
        `;
        document.getElementById(`items-list-${subcategoryIndex}`).insertAdjacentHTML("beforeend", itemHTML);
    }

    function removeItem(subcategoryIndex) {
        const itemList = document.getElementById(`items-list-${subcategoryIndex}`);
        const lastItem = itemList.lastElementChild;
        if (lastItem) {
            lastItem.remove();
        }
    }

    function updateSubcategoryTotal(subcategoryIndex) {
        let subcategoryTotal = 0;
        const itemInputs = document.querySelectorAll(`#items-list-${subcategoryIndex} input[type="number"]`);
        itemInputs.forEach(input => {
            subcategoryTotal += parseInt(input.value) || 0;
        });
        document.querySelector(`input[name="subcategories[${subcategoryIndex}][subcategory_total]"]`).value = subcategoryTotal;
        updateMainTotal();
    }

    function updateMainTotal() {
        mainTotalCount = 0;
        const subcategoryTotals = document.querySelectorAll("input[name$='[subcategory_total]']");
        subcategoryTotals.forEach(input => {
            mainTotalCount += parseInt(input.value) || 0;
        });
        document.getElementById("main-category-total").textContent = mainTotalCount;
    }
</script>

</body>
</html>
