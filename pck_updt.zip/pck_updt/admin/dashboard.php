<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');

if (strlen($_SESSION['alogin']) == 0) {    
    header('location:index.php');
} else {
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>TMS | Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> 
        addEventListener("load", function() { 
            setTimeout(hideURLbar, 0); 
        }, false); 
        function hideURLbar(){ 
            window.scrollTo(0,1); 
        } 
    </script>

    <!-- Bootstrap and Custom CSS -->
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

    <!-- Inline styles for box consistency -->
    <style>
        .container {
            padding: 0 15px;
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .four-grid {
            flex: 1 1 calc(33.33% - 15px); /* Ensure three items per row */
            margin-bottom: 30px;
        }
        .four-grid .four-wthree, .four-grid .four-agileits {
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            background: #4CAF50; /* Set background color to green */
            color: #fff; /* Set text color to white */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .four-grid .four-wthree .icon, .four-grid .four-agileits .icon {
            font-size: 40px;
            margin-bottom: 10px;
        }
        .four-grid .four-wthree h3, .four-grid .four-agileits h3 {
            font-size: 18px;
        }
        .four-grid .four-wthree h4, .four-grid .four-agileits h4 {
            font-size: 22px;
            font-weight: bold;
        }
        @media (max-width: 768px) {
            .four-grid {
                flex: 1 1 calc(50% - 15px); /* 2 items per row on smaller screens */
            }
        }
        @media (max-width: 480px) {
            .four-grid {
                flex: 1 1 100%; /* 1 item per row on very small screens */
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!--/content-inner-->
        <div class="left-content">
            <div class="mother-grid-inner">
                <!--header start here-->
                <?php include('includes/header.php'); ?>
                <!--header end here-->
                
                <!-- Sidebar -->
                <?php include('includes/sidebarmenu.php'); ?>
                
                <!-- Breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="/pck_updt/main.php"><i class="fa fa-file-text-o" aria-hidden="true">
                                        </i>  <span>Back to Home Page</span><div class="clearfix"></div></a></li>
                </ol>

                <!-- Dashboard Content -->
                <div class="container">
                    <div class="row">
                        <a href="manage-users.php" target="_blank" class="four-grid">
                            <div class="four-agileits">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-user" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>User</h3>
                                    <?php 
                                    $sql = "SELECT id from tblusers";
                                    $query = $dbh->prepare($sql);
                                    $query->execute();
                                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                                    $cnt = $query->rowCount();
                                    ?>            
                                    <h4><?php echo htmlentities($cnt);?></h4>
                                </div>
                            </div>
                        </a>

                        <a href="manage-packages.php" target="_blank" class="four-grid">
                            <div class="four-wthree">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-briefcase" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>Total Packages</h3>
                                    <?php 
                                    $sql3 = "SELECT PackageId from tbltenderpackages";
                                    $query3 = $dbh->prepare($sql3);
                                    $query3->execute();
                                    $results3 = $query3->fetchAll(PDO::FETCH_OBJ);
                                    $cnt3 = $query3->rowCount();
                                    ?>
                                    <h4><?php echo htmlentities($cnt3);?></h4>
                                </div>
                            </div>
                        </a>
                        
                        <!-- New Sections -->
                        <a href="manage-packages.php" target="_blank" class="four-grid">
                            <div class="four-wthree">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-briefcase" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>NCS Packages</h3>
                                </div>
                            </div>
                        </a>

                        <a href="package-overview.php" target="_blank" class="four-grid">
                            <div class="four-agileits">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-stats" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>Packages Overview</h3>
                                </div>
                            </div>
                        </a>

                        <a href="whats-new.php" target="_blank" class="four-grid">
                            <div class="four-wthree">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>Urgent News</h3>
                                </div>
                            </div>
                        </a>

                        <a href="photo-gallery.php" target="_blank" class="four-grid">
                            <div class="four-agileits">
                                <div class="icon">
                                    <i class="glyphicon glyphicon-picture" aria-hidden="true"></i>
                                </div>
                                <div class="four-text">
                                    <h3>Photo Gallery</h3>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Footer -->
                <?php include('includes/footer.php'); ?>
                
            </div>
        </div>

        <div class="clearfix"></div>        
    </div>

    <!-- Toggle Sidebar -->
    <script>
    var toggle = true;
    $(".sidebar-icon").click(function() {                
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({"position":"absolute"});
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({"position":"relative"});
            }, 400);
        }
        toggle = !toggle;
    });
    </script>

    <!-- Bootstrap and jQuery -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
<?php } ?>
