<?php
session_start();

ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices
include('includes/config.php');
// Initialize variables
$error = "";
$msg = "";

// Check if user is logged in ()
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');
    exit;
}

if (isset($_GET['id'])) {
    $reportId = $_GET['id'];
    
    // Fetch the report details
    $sql = "SELECT * FROM media_reports WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $reportId, PDO::PARAM_INT);
    $query->execute();
    $report = $query->fetch(PDO::FETCH_ASSOC);
}

// Handle update
if (isset($_POST['update'])) {
    $reportDate = $_POST['report_date'];
    $division = $_POST['division'];
    $media = $_POST['media'];
    $topic = $_POST['topic'];

    // Handling PDF file upload
    $attachments = $report['attachments']; // Keep the existing ones
    if (!empty($_FILES['attachments']['name'][0])) {
        $uploadedFiles = [];
        foreach ($_FILES['attachments']['tmp_name'] as $key => $tmpName) {
            $fileName = $_FILES['attachments']['name'][$key];
            $fileTmpName = $_FILES['attachments']['tmp_name'][$key];
            $filePath = 'uploads/' . basename($fileName);

            if (pathinfo($fileName, PATHINFO_EXTENSION) == 'pdf') {
                move_uploaded_file($fileTmpName, $filePath);
                $uploadedFiles[] = $filePath;
            }
        }
        $attachments = implode(',', $uploadedFiles); // Store new uploaded files
    }

    // Update the report
    $sql = "UPDATE media_reports SET report_date = :reportDate, division = :division, media = :media, topic = :topic, attachments = :attachments WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':reportDate', $reportDate, PDO::PARAM_STR);
    $query->bindParam(':division', $division, PDO::PARAM_STR);
    $query->bindParam(':media', $media, PDO::PARAM_STR);
    $query->bindParam(':topic', $topic, PDO::PARAM_STR);
    $query->bindParam(':attachments', $attachments, PDO::PARAM_STR);
    $query->bindParam(':id', $reportId, PDO::PARAM_INT);

    if ($query->execute()) {
        $msg = "Media Report Updated Successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Edit Media Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</head>
<style>
    .page-container {
            padding-top: 0px; /* Adjust based on header height */
            padding-left: 250px; /* Adjust based on sidebar width */
        }
    </style>
<body>
    <div class="page-container">
        <?php include('includes/header.php'); ?>
        <div class="clearfix"></div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="main.php">হোম</a><i class="fa fa-angle-right"></i>Edit Media Report</li>
        </ol>
        <div class="container">
            <h2>এডিট গণমাধ্যমে প্রকাশিত ও সম্প্রচারিত সংবাদ এবং বিশ্লেষণ রিপোর্ট</h2>
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>রিপোর্টের তারিখ</label>
                    <input type="date" name="report_date" class="form-control" value="<?php echo htmlentities($report['report_date']); ?>" required>
                </div>
                <div class="form-group">
                    <label>বিভাগ</label>
                    <input type="text" name="division" class="form-control" value="<?php echo htmlentities($report['division']); ?>">
                </div>
                <div class="form-group">
                    <label>গণমাধ্যম</label>
                    <input type="text" name="media" class="form-control" value="<?php echo htmlentities($report['media']); ?>">
                </div>
                <div class="form-group">
                    <label>বিষয়</label>
                    <input type="text" name="topic" class="form-control" value="<?php echo htmlentities($report['topic']); ?>">
                </div>
                <div class="form-group">
                    <label>সংযুক্তি(পিডিএফ)</label>
                    <input type="file" name="attachments[]" class="form-control" accept="application/pdf" multiple>
                    <small>বর্তমান সংযুক্তি(পিডিএফ): <?php echo htmlentities($report['attachments']); ?></small>
                </div>
                <button type="submit" name="update" class="btn btn-primary">আপডেট রিপোর্ট</button>
            </form>
        </div>
        <?php include('includes/footer.php'); ?>
        <?php include('includes/sidebarmenu.php'); ?>
    </div>
</body>
</html>
