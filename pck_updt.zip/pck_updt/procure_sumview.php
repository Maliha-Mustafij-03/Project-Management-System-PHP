<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Fetch all records from the database
$sql = "SELECT * FROM procurement_plan";
$query = $dbh->prepare($sql);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procurement Progress</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }

        .container {
            margin-top: 0px;
        }

        .search-bar {
            margin-bottom: 20px;
            padding: 10px;
        }

        .btn-print {
            margin-bottom: 20px;
        }

        .table-container {
            overflow-x: auto;
        }

        /* Vibrant and Bold table styles for print */
        .table {
            border-collapse: collapse;
            width: 100%;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            padding: 12px;
            text-align: left;
            vertical-align: middle;
            font-weight: normal;
            border: 1px solid #dee2e6;
            white-space: pre-line; /* Allow line breaks inside table cells */
        }

        .table thead {
            background-color: #343a40;
            color: white;
        }

        .table tbody tr:nth-child(odd) {
            background-color: #f8f9fa;
        }

        .table tbody tr:nth-child(even) {
            background-color: #e9ecef;
        }

        .table tbody tr:hover {
            background-color: #5bc0de;
            color: white;
        }

        /* Print styles */
        @media print {
            body * {
                visibility: hidden; /* Hide all content */
            }

            /* Show the table only */
            .table-container, .table-container * {
                visibility: visible;
            }

            /* Show the table container */
            .table-container {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                border: 1px solid #dee2e6;
            }

            /* Hide other elements during print */
            .search-bar, .btn-print, .container h3 {
                visibility: hidden; /* Hide search bar, print button, and main heading */
            }

            /* Make sure the page content is centered during print */
            @page {
                size: auto;
                margin: 0mm;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h3 class="mt-5 text-center">Procurement Progress</h3>

        <!-- Heading for Summary Report -->
        <h4 class="text-center">Summary Report</h4>

        <!-- Search bar -->
        <div class="search-bar">
            <input type="text" id="searchInput" class="form-control" placeholder="Search for records...">
        </div>
        
        <!-- Print button -->
        <div class="text-right">
            <button class="btn btn-success btn-print" onclick="printPage()">Print Report</button>
        </div>

        <!-- Table to display data -->
        <div class="table-container">
            <table class="table table-striped" id="dataTable">
                <thead>
                    <tr>
                        <th>২০২৪-২৫  ক্রয় পরিকল্পনায় অন্তর্ভুক্ত মোট প্যাকেজ সংখ্যা</th>
                        <th>পূর্বে চুক্তি সম্পন্ন প্যাকেজ</th>
                        <th>২০২৪-২৫ চুক্তি সম্পাদিত প্যাকেজ সংখ্যা</th>
                        <th>বাস্তবায়ন অগ্রগতির হার (%)</th>
                        <th>দরপত্র প্রক্রিয়াধীন প্যাকেজ সংখ্যা (মূল্যায়ন চলমান, NOA, ইত্যাদি)*</th>
                        <th>অবশিষ্ট প্যাকেজসমূহ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $row): ?>
                        <tr>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['total_packages'])); ?></td>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['previous_contracts'])); ?></td>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['signed_contracts'])); ?></td>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['implementation_progress_rate'])); ?></td>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['packages_under_evaluation'])); ?></td>
                            <td><?php echo str_replace('।', '।<br>', htmlspecialchars($row['remaining_packages'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Search function
        document.getElementById("searchInput").addEventListener("keyup", function() {
            var searchValue = this.value.toLowerCase();
            var tableRows = document.querySelectorAll("#dataTable tbody tr");

            tableRows.forEach(function(row) {
                var cells = row.querySelectorAll("td");
                var found = false;

                cells.forEach(function(cell) {
                    if (cell.textContent.toLowerCase().includes(searchValue)) {
                        found = true;
                    }
                });

                if (found) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });

        // Print page function
        function printPage() {
            var printContent = document.querySelector(".table-container").innerHTML; // Get table content
            var originalContent = document.body.innerHTML; // Get original page content

            // Replace the entire body with just the table content
            document.body.innerHTML = printContent;

            // Trigger the print dialog
            window.print();

            // Restore the original content after printing
            document.body.innerHTML = originalContent;
        }
    </script>
</body>
</html>
