<?php
session_start();
include('includes/config.php');

// Fetch package details
$pid = intval($_GET['pkgid']);
$sql = "SELECT * FROM tbltenderpackages WHERE PackageId = :pid";
$query = $dbh->prepare($sql);
$query->bindParam(':pid', $pid, PDO::PARAM_INT);
$query->execute();
$package = $query->fetch(PDO::FETCH_OBJ);

// Fetch package details for this package
$sqlDetails = "SELECT Detail, DetailPart2, Status, ActualCompletedDate FROM tblpackagedetails WHERE PackageId = :pid";
$queryDetails = $dbh->prepare($sqlDetails);
$queryDetails->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryDetails->execute();
$details = $queryDetails->fetchAll(PDO::FETCH_ASSOC);

// Fetch comments
$sqlComments = "SELECT CommentId, CreatedAt, Comment FROM tblcomments WHERE PackageId = :pid AND Status = 'active'";
$queryComments = $dbh->prepare($sqlComments);
$queryComments->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryComments->execute();
$comments = $queryComments->fetchAll(PDO::FETCH_OBJ);

// Handle comment submission
if (isset($_POST['submit2'])) {
    $comment = $_POST['comment'];
    $status = 'active';

    $sql = "INSERT INTO tblcomments (PackageId, Comment, Status) VALUES (:pid, :comment, :status)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':pid', $pid, PDO::PARAM_INT);
    $query->bindParam(':comment', $comment, PDO::PARAM_STR);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . $pid);
        exit;
    } else {
        $error = "কিছু ভুল হয়েছে। আবার চেষ্টা করুন।";
    }
}

// Handle comment deletion
if (isset($_GET['delete'])) {
    $commentId = intval($_GET['delete']);
    $sql = "DELETE FROM tblcomments WHERE CommentId = :commentId AND PackageId = :pid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':commentId', $commentId, PDO::PARAM_INT);
    $query->bindParam(':pid', $pid, PDO::PARAM_INT);
    $query->execute();

    header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . $pid);
    exit;
}
?>
<!DOCTYPE HTML>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>প্যাকেজ বিস্তারিত</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 0;
        }

        .banner {
            background-image: url('images/6.jpg');
            background-size: cover;
            height: 80px;
            text-align: center;
            color: white;
            padding: 60px 0;
            font-size: 30px;
            font-weight: bold;
        }

        .header {
            background-color: darkgreen;
            padding: 20px;
            text-align: center;
            color: white;
        }

        .header a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            font-size: 18px;
        }

        .header a:hover {
            color: #ddd;
        }

        .header a.blinking {
            animation: blink 1s infinite step-start;
        }

        @keyframes blink {
            50% {
                opacity: 0;
            }
        }

        .container {
            padding: 40px;
            max-width: 1000px;
            margin: 0 auto;
        }

        .print-button {
            background-color: red;
            color: white;
            padding: 10px 20px;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .print-button:hover {
            background-color: darkred;
        }

        .section-box {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
        }

        .section-box h3 {
            color: #333;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .details-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .details-row:last-child {
            border-bottom: none;
        }

        .detail-item {
            font-size: 18px;
            color: #333;
        }

        .gone {
            color: red;
            font-weight: bold;
        }

        .upcoming {
            color: green;
            font-weight: bold;
        }

        .not-updated {
            color: gray;
            font-weight: bold;
        }

        .today {
            color: blue;
            font-weight: bold;
        }

        .tentative-gone {
            color: red;
            font-weight: bold;
        }

        .tentative-upcoming {
            color: green;
            font-weight: bold;
        }

        .tentative-today {
            color: blue;
            font-weight: bold;
        }

        .date-label {
            font-size: 14px;
            color: gray;
        }

        .comment {
            padding: 10px;
            background-color: #fafafa;
            margin-bottom: 10px;
            border-radius: 5px;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid #ddd;
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .delete-btn:hover {
            background-color: darkred;
        }

        .comment-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: none;
            font-size: 16px;
        }

        .comment-form input[type="submit"] {
            background-color: red;
            color: white;
            padding: 10px 20px;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .comment-form input[type="submit"]:hover {
            background-color: darkred;
        }

        .package-info {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            border: 1px solid #ddd;
        }

        .package-info p {
            font-size: 18px;
            color: #555;
        }

        .package-info span {
            font-weight: bold;
            color: #333;
        }

        .grand {
            font-size: 22px;
            font-weight: bold;
            color: red;
        }

        /* Hide the header, print button, banner, and comment box when printing */
        @media print {
            .header, .print-button, .banner, .comment-form, .comment {
                display: none;
            }
            .container {
                width: 100%;
                padding: 0;
            }
            .section-box {
                border: 1px solid #000;
            }
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <div class="header">
        <a href="main.php">হোম</a>
        <a href="package-list.php">সমস্ত প্যাকেজ</a>
        <a href="live-package.php" class="">চলমান প্যাকেজ</a>
        <a href="upcoming-package.php" class="">আসন্ন প্যাকেজ</a>
        <a href="close-package.php" class="">সম্পন্ন প্যাকেজ</a>
        <a href="package-view.php">সারসংক্ষেপ</a>
        <a href="procure_sumview.php">রিপোর্ট</a>
    </div>

    <!-- Banner Section -->
    <div class="banner">
        NCS/GD প্যাকেজ বিস্তারিত
    </div>

    <!-- Main Content Section -->
    <div class="container">
        <button class="print-button" onclick="window.print()">প্রিন্ট করুন</button>

        <div class="package-info">
            <h2><?php echo htmlentities($package->PackageNo); ?></h2>
            <div>
                 <p><strong>দরপত্র আহবান এর তারিখ:</strong> 
                    <?php echo ($package->Consultant == '0000-00-00' ? 'এখনও আপডেট হয়নি' : htmlentities($package->Consultant)); ?>
                </p>
                <p><strong>ক্রয় পদ্ধতি ও ধরণ:</strong> <span><?php echo htmlentities($package->PurchaseMethodType); ?></span></p>
            </div>
            <div>
                <p><strong>ক্রয় অনুমোদনকারী কর্তৃপক্ষ:</strong> <span><?php echo htmlentities($package->ResponsiblePerson); ?></span></p>
                <p><strong>চুক্তির অগ্রগতির তারিখ:</strong> 
                    <?php echo ($package->SpecificationForwardingDate == '0000-00-00' ? 'এখনও আপডেট হয়নি' : htmlentities($package->SpecificationForwardingDate)); ?>
                </p>
                <p><strong>ডিপিপি অনুযায়ী ক্রয়ের জন্য প্যাকেজ বর্ননা:</strong> <span><?php echo htmlentities($package->Details); ?></span></p>
            </div>
            <div class="grand">
                প্রাক্কলিত ব্যায়(লক্ষ টাকায়): <?php echo htmlentities($package->EstimatedExpenditure); ?>
            </div>
        </div>

        <!-- Update Details Section -->
        <div class="section-box">
            <h3>আপডেট বিস্তারিত</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ddd; padding: 10px; text-align: left;">কর্মের অগ্রগতি</th>
                        <th style="border: 1px solid #ddd; padding: 10px; text-align: left;">নির্ধারিত তারিখ</th>
                        <th style="border: 1px solid #ddd; padding: 10px; text-align: left;">দ্বায়িত্বপ্রাপ্ত কর্মকর্তা/কর্মচারী</th>
                        <th style="border: 1px solid #ddd; padding: 10px; text-align: left;">বাস্তবায়নের তারিখ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($details as $detail): ?>
                        <tr>
                            <td style="border: 1px solid #ddd; padding: 10px;"><?php echo htmlentities($detail['Detail']); ?></td>
                            <td style="border: 1px solid #ddd; padding: 10px;">
                                <?php
                                    $tentativeDate = $detail['DetailPart2'];
                                    $currentDate = date('Y-m-d');
                                    if ($tentativeDate < $currentDate) {
                                        echo "<span class='tentative-gone'>$tentativeDate (সময় শেষ)</span>";
                                    } elseif ($tentativeDate == $currentDate) {
                                        echo "<span class='tentative-today'>$tentativeDate (আজ)</span>";
                                    } else {
                                        echo "<span class='tentative-upcoming'>$tentativeDate (আসন্ন)</span>";
                                    }
                                ?>
                            </td>
                            <td style="border: 1px solid #ddd; padding: 10px;"><?php echo htmlentities($detail['Status']); ?></td>
                            <td style="border: 1px solid #ddd; padding: 10px;">
                                <?php 
                                    $completionDate = $detail['ActualCompletedDate'];
                                    if ($completionDate == '0000-00-00' || $completionDate == '') {
                                        echo "<span class='not-updated'>এখনও আপডেট হয়নি</span>";
                                    } else {
                                        $currentDate = date('Y-m-d');
                                        if ($completionDate == $currentDate) {
                                            echo "<span class='today'>$completionDate (আজ)</span>";
                                        } elseif ($completionDate < $currentDate) {
                                            echo "<span class='gone'>$completionDate (সময় শেষ)</span>";
                                        } else {
                                            echo "<span class='upcoming'>$completionDate (আসন্ন)</span>";
                                        }
                                    }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Comments Section -->
        <div class="section-box">
            <h3>মন্তব্যসমূহ</h3>
            <div>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <p><?php echo htmlentities($comment->Comment); ?></p>
                        <a href="?pkgid=<?php echo $pid; ?>&delete=<?php echo $comment->CommentId; ?>" class="delete-btn">মুছে ফেলুন</a>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="comment-form">
                <form method="post">
                    <textarea name="comment" placeholder="আপনার মন্তব্য যোগ করুন..."></textarea>
                    <input type="submit" name="submit2" value="মন্তব্য জমা দিন">
                </form>
            </div>
        </div>
    </div>
</body>
</html>
