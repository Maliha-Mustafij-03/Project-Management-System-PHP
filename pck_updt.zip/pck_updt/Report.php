<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');
// Initialize search query variable
$search = '';
if (isset($_POST['search'])) {
    $search = trim($_POST['search']);
} 
$sql = "SELECT * FROM financial_progress ORDER BY Serial_No DESC LIMIT 1";
$query = $dbh->prepare($sql);

$query->execute();
$result = $query->fetch(PDO::FETCH_OBJ);
$next_year = $result->Financial_year + 1;

$en_to_bn_digits = array (
    0 => '০',
    1 => '১',
    2 => '২',
    3 => '৩',
    4 => '৪',
    5 => '৫',
    6 => '৬',
    7 => '৭',
    8 => '৮',
    9 => '৯',
);
?>                   

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Progress</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 8px;
        }
        th, td {
            text-align: center;
        }
        h1 {
            text-align: center;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .print-btn {
            margin: 20px auto;
            display: block;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            text-align: center;
        }
        .print-btn:hover {
            background-color: #0056b3;
        }
        
        /* Print-specific CSS */
        @media print {
            body * {
                visibility: hidden;
            }

            .print-area, .print-area * {
                visibility: visible;
            }

            header, .breadcrumb, .navbar, .admin-info, footer, .print-btn {
                display: none !important;
            }

            head, style, script {
                display: none !important;
            }

            .print-area {
                width: 100%;
            }

            /* Ensuring borders show up for all tables and elements */
            table, th, td {
                border: 1px solid black !important;
                border-collapse: collapse !important;
            }
            th, td {
                padding: 8px !important;
                text-align: center !important;
            }
        }
    </style>
</head>
<body>
    <header>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>আর্থিক অগ্রগতিঃ </li>
        </ol>
    </header>

    <!-- Print Area - This is the content you want to print -->
    <div class="print-area">
        <h1>চলতি বছরের আর্থিক প্রতিবেদন(লক্ষ টাকায়):</h1>
       <p style="text-align: center;"><?= date('M d Y', strtotime($result->Last_date_of_Cumulative_Cost)) ?> পর্যন্ত প্রকল্পের আর্থিক অগ্রগতির সারসংক্ষেপ(লক্ষ টাকায়):</p>

        <!-- Table 1 -->
        <table style="width: 80%; margin: 0 auto; margin-bottom: 20px;">
            <tr>
                <th>খাত</th>
                <th><?= $result->Financial_year ?> অর্থবছরে এডিপিতে বরাদ্দ</th> 
                <th><?= $result->Financial_year ?> অর্থবছরে আরএডিপিতে বরাদ্দ</th>
                <th><?= $result->Fund_Release_Installments ?> কিস্তিতে অর্থছাড়</th>
                <th><?= date('M d Y', strtotime($result->Last_date_of_Cumulative_Cost)) ?><br> তারিখ পর্যন্ত অর্থ ব্যয়</th> 
                <th><?= $result->Financial_year ?> চলতি বছরে অগ্রগতির হার</th>
                
                 
            </tr>
            <tr>
                <th>জিওবি</th>
                <td><?php echo $result->Annual_dpp_budget ?></td>
                <td><?php echo $result->Last_date_of_fy_cost; ?></td>
                <td><?php echo $result->Funds_Released_So_Far; ?></td>
                <td><?php echo $result->Current_fy_progress; ?></td>
                <td><?php echo $result->current_fy_progress_per.'%' ?></td>
                       
            </tr>
            <tr>
                <td>আরপিএ</td>
                <td> 0.00 </td>
                <td> 0.00 </td>
                <td> 0.00 </td>
                <td> 0.00 </td>
                <td> 0.00 </td>
                
            </tr>
            <tr>
                <td>মোট</td>
                <td><?php echo $result->Annual_dpp_budget ?></td>
                <td><?php echo $result->Last_date_of_fy_cost ?></td>
                <td><?php echo $result->Funds_Released_So_Far; ?></td>
                <td><?php echo $result->Current_fy_progress; ?> </td>
                <td><?php echo $result->current_fy_progress_per.'%' ?></td>
                
 
            </tr>
        </table>
        <br>
<h1>ক্রমঃপুঞ্জিত আর্থিক প্রতিবেদন(লক্ষ টাকায়):</h1>
        <!-- Table 2 - Same table, repeated -->
        <table style="width: 80%; margin: 0 auto; margin-top: 50px;">
            <tr>
                <th>ক্রম</th>
                <th>ডিপিপি অনুসারে মোট বরাদ্দ </th> 
                <th>আরডিপিপিতে বরাদ্দ </th>
                <th><?= date('M d Y', strtotime($result->Last_date_of_Cumulative_Cost)) ?><br> তারিখ পর্যন্ত ক্রমঃপুঞ্জিত মোট ব্যয়</th>
                <th>মোট অগ্রগতির হার (ডিপিপি অনুসারে)</th> 
        </tr>
           
            <tr>
                <td>জিওবি</td>
                <td><?php echo $result->Total_Cost ?></td>
                <td><?php echo $result->Current_FY_Allocation ?></td>
                <td><?php echo $result->Cumulative_Cost ?></td>
                <td><?php echo $result->Cumulative_Cost_percentage.'%' ?></td>
            </tr>
            <tr>
                <td>আরপিএ</td>
                <td>0.00</td>
                <td>0.00</td>            
                <td>0.00</td>            
                <td>0.00</td>            
                
           

            </tr>
            <tr>
                <td>মোট</td>
                <td><?php echo $result->Total_Cost ?></td>
                <td><?php echo $result->Current_FY_Allocation ?></td>
                <td><?php echo $result->Cumulative_Cost ?></td>
                <td><?php echo $result->Cumulative_Cost_percentage.'%' ?></td>
                
            </tr>

        </table>

    </div>
    
    <!-- Print Button -->
    <button class="print-btn" onclick="window.print();">প্রিন্ট করুন</button>

</body>
</html> 
