<?php
// Start the session at the very beginning of the PHP file
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create A Schedule</title>

    <!-- FullCalendar CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" />

    <!-- jQuery and FullCalendar JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">

    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

    <style>
        /* General Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: #006400; /* Bottle green background */
            color: #fff;
            text-align: center;
            overflow: hidden;
        }

        .header-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: #004d00; /* Darker shade of bottle green */
            color: #fff;
        }

        .header-bar .back-button {
            position: absolute;
            left: 20px;
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .header-bar .back-button:hover {
            background: #45a049;
        }

        .header-bar h2 {
            font-size: 32px;
            margin: 0;
            color: #fff;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.5);
            animation: textGlow 2s ease-in-out infinite alternate;
        }

        @keyframes textGlow {
            from {
                text-shadow: 3px 3px 6px rgba(255, 255, 255, 0.5);
            }

            to {
                text-shadow: 6px 6px 20px rgba(255, 255, 255, 0.8);
            }
        }

        #calendar-container {
            width: 100%;
            height: 100vh;
            padding: 10px;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            background: rgba(0, 128, 0, 0.8); /* Bottle green background with opacity */
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            transition: all 0.5s ease-in-out;
        }

        #calendar-container.fullscreen {
            width: 100%;
            height: 100vh;
            padding: 0;
            border-radius: 0;
        }

        #calendar {
            width: 100%;
            height: 100%;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            animation: slideIn 1s ease-in-out forwards;
        }

        @keyframes slideIn {
            from {
                transform: translateY(50px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* FullCalendar Custom Styles */
        .fc-toolbar {
            background: #006400; /* Bottle green toolbar background */
            color: #fff;
        }

        .fc-toolbar button {
            background: #4CAF50;
            border: none;
            padding: 10px 25px;
            border-radius: 5px;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .fc-toolbar button:hover {
            background: #45a049;
            transform: translateY(-3px);
        }

        .fc-button-group > .fc-button {
            margin-left: 10px;
        }

        .fc-view-container {
            transition: all 0.5s ease;
        }

        .fc-scroller {
            overflow-y: auto;
            max-height: 75vh;
            padding-bottom: 20px;
        }

        .fc-title {
            font-size: 16px;
            font-weight: 700;
            color: #333;
        }

        /* Day and Week View Styles */
        .fc-day-number {
            font-size: 18px;
            font-weight: bold;
            color: #006400; /* Bottle green color */
            border: 2px solid #006400;
            border-radius: 50%;
            padding: 5px;
            transition: all 0.3s ease;
        }

        .fc-day-number:hover {
            background-color: #f1c40f;
            color: #000;
            border-color: #e67e22;
        }

        .fc-day-header {
            background-color: #006400; /* Bottle green background for day headers */
            color: #fff;
        }

        .fc-day-grid-day {
            border: 1px solid #006400;
        }

        .fc-event {
            cursor: pointer;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .fc-event:hover {
            transform: scale(1.1);
            background-color: #ffdd57 !important;
            color: #333;
            z-index: 10000;
        }

        .fc-event-category-1 {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }

        .fc-event-category-2 {
            background-color: #8e44ad;
            border-color: #8e44ad;
        }

        .fc-event-category-3 {
            background-color: #3498db;
            border-color: #3498db;
        }

        .fc-event-category-4 {
            background-color: #2ecc71;
            border-color: #2ecc71;
        }

        /* Delete Confirmation */
        .delete-confirmation {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            max-width: 400px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 10002;
            padding: 20px;
            text-align: center;
            color: #333;
            animation: fadeIn 0.5s ease;
        }

        .delete-confirmation button {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 0 10px;
        }

        .delete-confirmation button:hover {
            background: #c0392b;
        }

        .delete-confirmation .cancel-btn {
            background: #3498db;
        }

        .delete-confirmation .cancel-btn:hover {
            background: #2980b9;
        }
    </style>
</head>

<body>
    <div class="header-bar">
        <button class="back-button" onclick="window.location.href='main.php'">Back to Main Page</button>
        <h2>Create A Schedule</h2>
    </div>

    <div id="calendar-container">
        <div id='calendar'></div>
    </div>

    <div class="delete-confirmation">
        <p>Are you sure you want to delete this event?</p>
        <button id="confirmDelete" class="delete-btn">Yes, Delete</button>
        <button id="cancelDelete" class="cancel-btn">Cancel</button>
    </div>

    <div class="response"></div>

    <script>
        $(document).ready(function () {
            var currentEvent;

            var calendar = $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                editable: <?php echo isset($_SESSION['alogin']) ? 'true' : 'false'; ?>,  // Only allow editing if logged in
                events: "fetch-event.php",
                displayEventTime: true,
                eventRender: function (event, element) {
                    if (event.allDay === 'true') {
                        event.allDay = true;
                    } else {
                        event.allDay = false;
                    }
                    element.addClass('fc-event-category-' + event.category);
                    element.find('.fc-time').text(moment(event.start).format("hh:mm A"));  // Use AM/PM format

                    // Check if the event starts at 12:00 AM, and hide the time
                    if (moment(event.start).format("hh:mm A") === "12:00 AM") {
                        element.find('.fc-time').hide();
                    }
                },
                selectable: true,
                selectHelper: true,
                select: function (start, end, allDay) {
                    if (<?php echo isset($_SESSION['alogin']) ? 'true' : 'false'; ?>) {
                        var title = prompt('Event Title:');
                        var category = prompt('Event Category (1-4):');
                        if (title) {
                            var start = $.fullCalendar.formatDate(start, "YYYY-MM-DD HH:mm:ss");
                            var end = $.fullCalendar.formatDate(end, "YYYY-MM-DD HH:mm:ss");

                            $.ajax({
                                url: 'add-event.php',
                                data: 'title=' + title + '&start=' + start + '&end=' + end + '&category=' + category,
                                type: "POST",
                                success: function () {
                                    displayMessage("Added Successfully");
                                }
                            });
                            calendar.fullCalendar('renderEvent', {
                                title: title,
                                start: start,
                                end: end,
                                allDay: allDay,
                                category: category
                            }, true);
                        }
                        calendar.fullCalendar('unselect');
                    } else {
                        alert("You need to be logged in to add events.");
                    }
                },

                editable: true,
                eventDrop: function (event) {
                    if (<?php echo isset($_SESSION['alogin']) ? 'true' : 'false'; ?>) {
                        var start = $.fullCalendar.formatDate(event.start, "YYYY-MM-DD HH:mm:ss");
                        var end = $.fullCalendar.formatDate(event.end, "YYYY-MM-DD HH:mm:ss");
                        $.ajax({
                            url: 'edit-event.php',
                            data: 'title=' + event.title + '&start=' + start + '&end=' + end + '&id=' + event.id,
                            type: "POST",
                            success: function () {
                                displayMessage("Updated Successfully");
                            }
                        });
                    }
                },

                eventClick: function (event) {
                    if (<?php echo isset($_SESSION['alogin']) ? 'true' : 'false'; ?>) {
                        currentEvent = event;
                        $('.delete-confirmation').fadeIn(400);
                    } else {
                        alert("You need to be logged in to delete events.");
                    }
                }
            });

            $('#confirmDelete').click(function () {
                $.ajax({
                    type: "POST",
                    url: "delete-event.php",
                    data: { id: currentEvent.id },
                    success: function (response) {
                        if (parseInt(response) > 0) {
                            $('#calendar').fullCalendar('removeEvents', currentEvent.id);
                            displayMessage("Deleted Successfully");
                        }
                        $('.delete-confirmation').fadeOut(400);
                    }
                });
            });

            $('#cancelDelete').click(function () {
                $('.delete-confirmation').fadeOut(400);
            });

            $('#calendar-container').dblclick(function () {
                $(this).toggleClass('fullscreen');
            });
        });

        function displayMessage(message) {
            $(".response").html("<div class='success'>" + message + "</div>");
            setTimeout(function () { $(".success").fadeOut(); }, 2000);
        }
    </script>
</body>

</html>
