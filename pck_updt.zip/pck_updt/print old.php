<?php
session_start();
include('includes/config.php');

// Fetch package details
$pid = intval($_GET['pkgid']);
$sql = "SELECT * FROM tbltenderpackages WHERE PackageId = :pid";
$query = $dbh->prepare($sql);
$query->bindParam(':pid', $pid, PDO::PARAM_INT);
$query->execute();
$package = $query->fetch(PDO::FETCH_OBJ);

// Fetch package details for this package
$sqlDetails = "SELECT Detail, DetailPart2 FROM tblpackagedetails WHERE PackageId = :pid";
$queryDetails = $dbh->prepare($sqlDetails);
$queryDetails->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryDetails->execute();
$details = $queryDetails->fetchAll(PDO::FETCH_ASSOC);

// Fetch comments
$sqlComments = "SELECT CommentId, Comment FROM tblcomments WHERE PackageId = :pid AND Status = 'active'";
$queryComments = $dbh->prepare($sqlComments);
$queryComments->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryComments->execute();
$comments = $queryComments->fetchAll(PDO::FETCH_OBJ);

// Handle comment submission
if (isset($_POST['submit2'])) {
    $comment = $_POST['comment'];
    $status = 'active';

    $sql = "INSERT INTO tblcomments (PackageId, Comment, Status) VALUES (:pid, :comment, :status)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':pid', $pid, PDO::PARAM_INT);
    $query->bindParam(':comment', $comment, PDO::PARAM_STR);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . $pid);
        exit;
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Handle comment deletion (if needed)
if (isset($_GET['delete'])) {
    $commentId = intval($_GET['delete']);
    $sql = "DELETE FROM tblcomments WHERE CommentId = :commentId AND PackageId = :pid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':commentId', $commentId, PDO::PARAM_INT);
    $query->bindParam(':pid', $pid, PDO::PARAM_INT);
    $query->execute();

    header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . $pid);
    exit;
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Package Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
        }
        .header, .banner-3 {
            background: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: 3px solid #388E3C;
        }
        .header h1, .banner-3 h1 {
            margin: 0;
            font-size: 2.5em;
        }
        .header a {
            color: white;
            text-decoration: none;
            padding: 10px;
            border: 2px solid #1E90FF;
            border-radius: 5px;
            margin: 0 10px;
        }
        .header a:hover {
            background: #1E90FF;
            color: white;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        .selectroom, .details-box, .comments {
            background: #ffffff;
            font-size: 1.2em;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .selectroom h2, .details-box h3 {
            font-size: 2em;
            margin-bottom: 15px;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        .printableArea {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }
        .printableArea div {
            flex: 1;
        }
        .printableArea p {
            border: 1px solid #ddd;
            margin: 0;
            padding: 10px;
            font-size: 1em;
            background: #ffffff;
        }
        .printableArea b {
            font-size: 1.2em;
            font-weight: bold;
            margin-right: 10px;
        }
        .printableArea span {
            display: block;
        }
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            text-align: center;
            z-index: 1000;
        }
        .print-button:hover {
            background-color: #388E3C;
        }
        @media print {
            body {
                background: #fff;
            }
            .container {
                width: 100%;
                border: none;
                box-shadow: none;
            }
            .header, .banner-3, .print-button {
                display: none;
            }
            .box-container, .comments .comment .delete-btn {
                display: none;
            }
            .comment {
                font-size: 1.8em;
            }
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-item {
            font-size: 1.2em;
            color: #333;
        }
        .comment {
            padding: 10px;
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 1.2em;
            position: relative;
        }
        .comment p {
            margin: 0;
        }
        .comment .delete-btn {
            position: absolute;
            top: 5px; /* Adjust this value to move the button upwards */
            right: 10px;
            background: #f44336;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background 0.3s ease;
        }
        .comment .delete-btn:hover {
            background: #d32f2f;
        }
        .box-container {
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .box-container h3 {
            font-size: 1.5em;
            margin-bottom: 15px;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        .box-container textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        .box-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        .box-container input[type="submit"]:hover {
            background-color: #388E3C;
        }
        .grand {
            text-align: center;
            background: #d0f0c0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 1.5em;
            font-weight: bold;
            color: #4CAF50;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal form input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        .modal form input[type="submit"]:hover {
            background-color: #388E3C;
        }
    </style>
    <script>
        function printPage() {
            window.print();
        }

        function deleteComment(commentId) {
            if (confirm('Are you sure you want to delete this comment?')) {
                window.location.href = '?pkgid=<?php echo $pid; ?>&delete=' + commentId;
            }
        }

        // Show the login modal
        function showModal() {
            var modal = document.getElementById('loginModal');
            if (modal) {
                modal.style.display = 'block';
            }
        }

        // Close the modal when the user clicks on (x)
        document.addEventListener('DOMContentLoaded', function() {
            var closeModal = document.querySelector('.close');
            if (closeModal) {
                closeModal.addEventListener('click', function() {
                    document.getElementById('loginModal').style.display = 'none';
                });
            }

            // Close the modal when the user clicks anywhere outside of the modal
            window.onclick = function(event) {
                var modal = document.getElementById('loginModal');
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            };
        });
    </script>
</head>
<body>
    <div class="header">
        <a href="index.php">হোমপেজ</a>
        <a href="package-list.php">এনসিএস/জিডি প্যাকেজ</a>
        <a href="photo-gallery.php">ফটো গ্যালারী</a>
    </div>
    <button class="print-button" onclick="printPage()">Print Now</button>
    <div class="container">
        <div class="banner-3">
            <h1 class="wow zoomIn animated" data-wow-delay=".5s" style="text-align: center;">NCS/GD-প্যাকেজ ম্যানেজমেন্ট সিস্টেমে আপনাকে স্বাগতম।</h1>
            <img src="images/bluesky.jpg" alt="Banner 3" style="width: 100%; height: auto;">
        </div>
        <div class="selectroom">
            <h2><?php echo htmlentities($package->PackageNo); ?></h2>
            <div class="printableArea">
                <div>
                    <p><b>স্পেসিফিকেশন ফরওয়ার্ডিং তারিখ:</b> <span><?php echo htmlentities($package->SpecificationForwardingDate); ?></span></p>
                    <p><b>ক্রয় পদ্ধতি:</b> <span><?php echo htmlentities($package->PurchaseMethodType); ?></span></p>
                    <p><b>প্রাক্কলিত ব্যায়:</b> <span><?php echo htmlentities($package->EstimatedExpenditure); ?></span></p>
                </div>
                <div>
                    <p><b>দ্বায়িত্বপ্রাপ্ত ব্যাক্তি:</b> <span><?php echo htmlentities($package->ResponsiblePerson); ?></span></p>
                    <p><b>পরামর্শক:</b> <span><?php echo htmlentities($package->Consultant); ?></span></p>
                    <p><b>বিস্তারিত:</b> <span><?php echo htmlentities($package->Details); ?></span></p>
                </div>
            </div>
            <div class="grand">
                মোট পরিমাণ (লাখ): <?php echo htmlentities($package->EstimatedExpenditure); ?>
            </div>
        </div>
        <div class="details-box">
            <h3>পর্যালোচনা</h3>
            <?php foreach ($details as $detail): ?>
                <div class="detail-row">
                    <div class="detail-item"><strong>স্ট্যটাস:</strong> <?php echo htmlentities($detail['Detail']); ?></div>
                    <div class="detail-item"><strong>তারিখ:</strong> <?php echo htmlentities($detail['DetailPart2']); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="comments">
            <h3>মন্তব্য</h3>
            <?php if (!empty($comments)): ?>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <p><?php echo htmlentities($comment->Comment); ?></p>
                        <!-- Red cross delete button -->
                        <button class="delete-btn" onclick="deleteComment(<?php echo $comment->CommentId; ?>)">&#10006;</button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>এখন পর্যন্ত কোনো মন্তব্য করা হয়নি।</p>
            <?php endif; ?>
        </div>
        <div class="box-container">
            <form method="post" action="">
                <h3>মন্তব্য যোগ করুন</h3>
                <textarea name="comment" rows="4" cols="50" placeholder="এখানে মন্তব্য করুন..." required></textarea><br />
                <input type="submit" name="submit2" value="সাবমিট" />
            </form>
        </div>
    </div>
</body>
</html>
