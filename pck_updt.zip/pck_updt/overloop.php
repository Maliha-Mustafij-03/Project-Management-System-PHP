<?php
// Assuming contactDao has methods to insert contacts into a database

// Define a Contact class
class Contact {
    public $id;
    public $name;
    public $email;
    public $phone;
    public $address;

    public function __construct($id, $name, $email, $phone, $address) {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->phone = $phone;
        $this->address = $address;
    }
}

// Function to print contactDao.insert() statements
function insertContact($contact) {
     echo "contactDao.insert(new Contact(" . $contact->id . ',"' . $contact->name . '","' . $contact->email . '","+880' . $contact->phone . '","' . $contact->address . '"))' . ";\n";
}

// File path to the CSV file
$csvFile = 'ocdemo.csv';

// Read the CSV file
if (($handle = fopen($csvFile, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $contact = new Contact(intval($data[0]), $data[1], $data[2], $data[3], $data[4]);
        insertContact($contact); // Print contactDao.insert() statement
    }
    fclose($handle);
}

echo "Data processed.\n";
?>
