<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

$id = $_GET['id'];

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

$sql = "SELECT * FROM emp_profile_list_view WHERE emp_id = $id";
    $query = $dbh->prepare($sql);
    $query->execute();
$data = $query->fetch(PDO::FETCH_ASSOC);
$job_id = $data['job_id'];
$emp_id = $data['emp_id'];

$sql1 = "SELECT * FROM view_emp_education WHERE exam_emp_id = $id";
$query1 = $dbh->prepare($sql1);
$query1->execute();
$edata = $query1->fetch(PDO::FETCH_ASSOC);

$sql2 = "SELECT * FROM view_emp_transfer WHERE transfer_emp_id = $id";
$query2 = $dbh->prepare($sql2);
$query2->execute();
$transfer_data = $query2->fetchAll(PDO::FETCH_ASSOC);

$sql3 = "SELECT * FROM view_emp_training WHERE job_id = $job_id";
$query3 = $dbh->prepare($sql3);
$query3->execute();
$training_data = $query3->fetchAll(PDO::FETCH_ASSOC);

$sql4 = "SELECT * FROM emp_tour WHERE tour_emp_id = $emp_id";
$query4 = $dbh->prepare($sql4);
$query4->execute();
$tour_data = $query4->fetchAll(PDO::FETCH_ASSOC);
?>

 <style type="text/css">
.test {
  text-align: center;
}
.selected {
  color: orange;
}
</style>
<link href="css/font-awesome.css" rel="stylesheet">

  <!-- Content Wrapper. Contains page content -->
  <div class="container"><br><br>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-md-12 col-xs-12">
          
          <div class="box box-success">
            <div class="box-body">
              <div class="row"> 
                <div class="col-md-2">
                  <?php if($data['emp_photo']  != NULL){ ?>
                    <img src="../hrm/uploads/profile_images/<?= $data['emp_photo'] ?>" alt="Image" height="100%" width="100%" class="img-thumbnail">
                  <?php }else{ ?>
                    <img src="../hrm/uploads/profile_images/no_image.jpg" alt="Image" height="100%" width="100%" class="img-thumbnail">
                  <?php } ?>
                </div>
                <div class="col-md-8">
                  <ul class="list-unstyled">
                    <li><i><h2><?=$data['emp_name'];?></h2></i></li>
                    <li><?= $data['desig_name'].', '.$data['section_name'] ?></li>
                    <li><?= '+880 '.$data['emp_mobile'] ?></li>
                    <li><?= $data['emp_email'] ?></li>
                    <li><b>Job ID</b> <?= $data['job_id'] ?></li>
                    <li><?= $data['emp_present_address'] ?></li>
                  </ul>
                </div>
              </div><br>
              <div class="row">
                <div class="col-md-12">
                  <h3>Educational Background</h3>
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Level of Education</th>
                        <th>Exam/Degree Title</th>
                        <th>Concentration/Major/Group</th>
                        <th>Institute Name</th>
                        <th>Passing Year</th>
                        <th>GPA/CGPA/Class</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php if($edata['ssc_level'] !=null && $edata['ssc_name'] != null && $edata['ssc_subject'] != null && $edata['ssc_ins'] != null && $edata['ssc_year'] != null && $edata['ssc_result'] != null){?>
                          <tr>
                            <td><?= $edata['ssc_level'] ; ?></td>'] 
                            <td><?= $edata['ssc_name'] ;?></td>
                            <td><?= $edata['ssc_subject'] ;?></td>
                            <td><?= $edata['ssc_ins'] ;?></td>
                            <td><?= $edata['ssc_year'] ;?></td>
                            <td><?= $edata['ssc_result'] ;?></td>
                          </tr>
                        <?php }if($edata['hsc_level'] !=null && $edata['hsc_name'] != null && $edata['hsc_subject'] != null && $edata['hsc_ins'] != null && $edata['hsc_year'] != null && $edata['hsc_result'] != null){?>
                          <tr>
                            <td><?= $edata['hsc_level']  ?></td>
                            <td><?= $edata['hsc_name']  ?></td>
                            <td><?= $edata['hsc_subject'] ?></td>
                            <td><?= $edata['hsc_ins'] ?></td>
                            <td><?= $edata['hsc_year'] ?></td>
                            <td><?= $edata['hsc_result'] ?></td>
                          </tr>
                        <?php }if($edata['hons_level'] !=null && $edata['hons_name'] != null && $edata['hons_subject'] != null && $edata['hons_ins'] != null && $edata['hons_year'] != null && $edata['hons_result'] != null){?>
                          <tr>
                            <td><?= $edata['hons_level'] ?></td>
                            <td><?= $edata['hons_name'] ?></td>
                            <td><?= $edata['hons_subject']?></td>
                            <td><?= $edata['hons_ins']?></td>
                            <td><?= $edata['hons_year']?></td>
                            <td><?= $edata['hons_result']?></td>
                          </tr>
                        <?php }if($edata['msc_level'] != null && $edata['msc_name'] != null && $edata['msc_subject'] != null && $edata['msc_ins'] != null && $edata['msc_year'] != null && $edata['msc_result'] != null){?>
                          <tr>
                            <td><?= $edata['msc_level']  ?></td>
                            <td><?= $edata['msc_name']  ?></td>
                            <td><?= $edata['msc_subject'] ?></td>
                            <td><?= $edata['msc_ins'] ;?></td>
                            <td><?= $edata['msc_year'] ?></td>
                            <td><?= $edata['msc_result'] ?></td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>                 
                </div>
              </div>
              <?php if(!empty($experience_data)):?>
              <div class="row">
                <div class="col-md-12">
                  <h3>Experiance</h3>
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Company Name</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Duration</th>
                        <th>Responsibility</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                        <?php foreach($experience_data->result() as $i=>$value){ 
                          $bday = new DateTime($value->duration_from); 
                          $today = new Datetime($value->duration_to);
                          $diff = $today->diff($bday);
                        ?>
                          <tr>
                            <td><?php echo $i+1; ?></td>
                            <td class="text-wrap">
                              <?php echo $value->name.'<br>';
                              echo $value->location
                              ?>  
                            </td>
                            <td><?php echo $value->designation?></td>
                            <td><?= $value->department ?></td>
                            <td><?php if($diff != null){
                                printf('Working term :</b> %d years %d month %d days', $diff->y, $diff->m, $diff->d);
                              }?>
                            </td>
                            <td><?php echo $value->duty ?></td>
                          </tr>
                      <?php } ?>                      
                    </tbody>
                  </table>
                </div>
              </div>
              <?php endif; ?>

              <?php if($tour_data != null):?>
              <div class="row">
                <div class="col-md-12">
                  <h3>Tour</h3>
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Reason</th>
                        <th>Destination</th>
                        <th>From Date</th>
                        <th>To Date</th>
                        <th>Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                        <?php foreach($tour_data as $i=>$value){ 
                          $datetime1 = date_create($value['duration_from']);
                          $datetime2 = date_create($value['duration_to']);
                          $interval = date_diff($datetime1, $datetime2);
                        ?>
                          <tr>
                            <td><?php echo $i+1; ?></td>
                            <td class="text-wrap" width="40%"><?php echo $value['reason'];?></td>
                            <td><?php echo $value['destination'];?></td>
                            <td><?php echo $value['duration_from'];?></td>
                            <td><?php echo $value['duration_to']; ?></td>
                            <td><?php echo $interval->format('%a days');?></td>
                          </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <?php endif;?>

              
              <div class="row">
                <div class="col-md-12">
                  <h3>Training</h3>
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Duration</th>
                        <th>Venue</th>
                        <th>Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(isset($training_data)): ?>
                        <?php foreach($training_data as $i=>$row){ ?>
                        <tr>
                          <td><?php echo $i+1; ?></td>
                          <td><?php echo $row['title_name'] ;?></td>
                          <td><?php echo $row['type_name'] ;?></td>
                          <td><?= '<i> from '.$row['duration_from'].' to '.$row['duration_to'].'</i>' ?></td>
                          <td><?= $row['venue_name']; ?></td>
                          <td><?= $row['score'] ?></td>
                        </tr>
                      <?php } ?>
                        <?php else:?>
                          <tr>No results found</tr>
                      <?php endif;?>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <h3>Transfer</h3>
                  <table class="table table-bordered table-striped ">
                    <thead>
                      <tr>
                        <th>Branch</th>
                        <th>Department</th>
                        <th>Region</th>
                        <th>District</th>
                        <th>Upazila</th>
                        <th>Role</th>
                        <th>From Date</th>
                        <th>To Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(isset($transfer_data)): ?>
                        <?php foreach($transfer_data as $value){
                          $role = unserialize($value['emp_role']);
                         ?>
                        <tr>
                          <td><?= $value['branch_name'] ?></td>
                          <td><?= $value['section_name'] ?></td>
                          <td><?= $value['region_name'] ?></td>
                          <td><?= $value['district_name'] ?></td>
                          <td><?= $value['upazila_name'] ?></td>
                          <td><?php
                          foreach ($role as $cont){
                            echo htmlspecialchars($cont).'<br/>'; }?></td>
                          <td><?php echo $value['from_date'] ?></td>
                          <td><?php if($value['to_date'] == NULL){
                            echo "<span class='label label-success'>working</span>";
                          }else{
                            echo $value['to_date'];
                          } 
                          ?></td>
                        </tr>
                      <?php }else:
                          echo '<tr>No results found</tr>';
                      endif;?>
                    </tbody>
                  </table>
                </div>
              </div> <!-- end row -->
              <div class="row">
                <div class="col-md-12">
                  <h3>Personal Information</h3>
                  <div class="table-responsive">
                    <table class="table">
                      <tbody>
                        <tr>
                          <th scope="row" class="align-right">Father Name</th>
                          <td><?=$data['emp_father'] ?></td>
                          <th scope="row" class="align-right">Mother Name</th>
                          <td><?=$data['emp_mother'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Date of Birth</th>
                          <td><?=$data['emp_dob'] ?></td>
                          <th scope="row" class="align-right">Gender</th>
                          <td><?=$data['emp_gender'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Religion</th>
                          <td><?=$data['emp_religion'] ?></td>
                          <th scope="row" class="align-right">Blood Group</th>
                          <td><?=$data['emp_bgroup'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Marital Status</th>
                          <td><?=$data['emp_marital_status'] ?></td>
                          <th scope="row" class="align-right">Spouse Name</th>
                          <td><?=$data['emp_spouse'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Family Information</th>
                          <td><?= $data['family_info'] ?></td>
                          <th scope="row" class="align-right">Spouse's Contact</th>
                          <td><?= $data['emp_spouse_mobile'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Present Address</th>
                          <td class="text-wrap"><?=$data['emp_present_address'] ?></td>
                          <th scope="row" class="align-right">Permanent Address</th>
                          <td class="text-wrap"><?=$data['emp_permanent_address'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">National ID</th>
                          <td><?=$data['emp_nid'] ?></td>
                          <th scope="row" class="align-right">Emergency Contact</th>
                          <td><?=$data['emp_emg_contact'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Home District</th>
                          <td><?=$data['emp_district'] ?></td>
                          <th scope="row" class="align-right">Home Upazila</th>
                          <td><?= $data['emp_upazila'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Passport</th>
                          <td><?=$data['emp_passport'] ?></td>
                          <th scope="row" class="align-right">eTIN</th>
                          <td><?=$data['emp_tin'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Joining Date</th>
                          <td><?=$data['emp_joining_date'] ?></td>
                          <th scope="row" class="align-right">Salary</th>
                          <td><?='BDT '.$data['emp_salary'].' /-'?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Bank Account</th>
                          <td><?=$data['bank_account'] ?></td>
                          <th scope="row" class="align-right">Firm's Name</th>
                          <td><?= $data['firm_name'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Training (Before Joining)</th>
                          <td><?=$data['training'] ?></td>
                          <th scope="row" class="align-right">Professional Course</th>
                          <td><?= $data['course'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Driving License</th>
                          <td><?=$data['driving_license'] ?></td>
                          <th scope="row" class="align-right">Relative in ECS</th>
                          <td><?= $data['relative_ecs'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Strength</th>
                          <td class="text-wrap"><?=$data['strength'] ?></td>
                          <th scope="row" class="align-right">Weakness</th>
                          <td><?= $data['weakness'] ?></td>
                        </tr>
                        <tr>
                          <th scope="row" class="align-right">Facebook</th>
                          <td><?=$data['facebook_id'] ?></td>
                          <th scope="row" class="align-right">WhatsApp</th>
                          <td><?= $data['whatsapp_id'] ?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-body -->
        </div>
          <!-- /.box -->
      </div>
        <!-- col-md-12 -->
    </div>
      <!-- /.row -->
  </section>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->

