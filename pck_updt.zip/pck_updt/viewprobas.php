<?php
session_start();
ini_set('display_errors', 0); // Hide all errors and notices, you can also use 1 for debugging in dev environment
error_reporting(E_ALL & ~E_NOTICE); // Hide only notices

include('includes/config.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Delete functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tblsmartcards WHERE id = :delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    $msg = "Smartcard Deleted Successfully";
}

// Initialize filter and search values
$filter_date = isset($_POST['filter_date']) ? $_POST['filter_date'] : 'today'; // Default to 'today'
$search = "";

// Check if the search button is clicked
if (isset($_POST['search'])) {
    $search = $_POST['search_query'];
}

// Build the SQL query based on the search and filter conditions
$sql = "SELECT * FROM tblsmartcards WHERE 1"; // Default SQL query to select all records

// Apply date filter if selected
if ($filter_date == 'today') {
    $sql .= " AND DATE(তারিখ) = CURDATE()"; // Filter for today's entries
}

// Apply search filter if provided
if (!empty($search)) {
    $search_value = '%' . $search . '%';
    $sql .= " AND (ক্রম_নং LIKE :search_query OR 
                   নাম LIKE :search_query OR 
                   মোট_আবেদন LIKE :search_query OR 
                   মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ LIKE :search_query OR 
                   তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন LIKE :search_query OR 
                   তদন্ত_সম্পন্ন_এপ্রুভ LIKE :search_query OR 
                   বাতিল LIKE :search_query OR 
                   মোট LIKE :search_query OR 
                   উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন LIKE :search_query OR 
                   মিশন_থেকে_আপলোড_অপেক্ষাধীন LIKE :search_query OR 
                   আপলোড LIKE :search_query OR 
                   প্রিন্ট_করার_উপযোগী LIKE :search_query OR 
                   প্রিন্টেড LIKE :search_query OR 
                   তারিখ LIKE :search_query)";
}

$query = $dbh->prepare($sql);

// Bind the search parameter if search is used
if (!empty($search)) {
    $query->bindParam(':search_query', $search_value, PDO::PARAM_STR);
}

$query->execute();
$smartcards = $query->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals for each field
$total_মোট_আবেদন = 0;
$total_মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ = 0;
$total_তদন্ত_সম্পন্ন_এপ্রুভ = 0;
$total_তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন = 0;
$total_বাতিল = 0;
$total_মোট = 0;
$total_উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন = 0;
$total_মিশন_থেকে_আপলোড_অপেক্ষাধীন = 0;
$total_আপলোড = 0;
$total_প্রিন্ট_করার_উপযোগী = 0;
$total_প্রিন্টেড = 0;

foreach ($smartcards as $smartcard) {
    $total_মোট_আবেদন += (int)$smartcard['মোট_আবেদন'];
    $total_মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ += (int)$smartcard['মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ'];
    $total_তদন্ত_সম্পন্ন_এপ্রুভ += (int)$smartcard['তদন্ত_সম্পন্ন_এপ্রুভ'];
    $total_তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন += (int)$smartcard['তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন'];
    $total_বাতিল += (int)$smartcard['বাতিল'];
    $total_মোট += (int)$smartcard['মোট'];
    $total_উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন += (int)$smartcard['উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন'];
    $total_মিশন_থেকে_আপলোড_অপেক্ষাধীন += (int)$smartcard['মিশন_থেকে_আপলোড_অপেক্ষাধীন'];
    $total_আপলোড += (int)$smartcard['আপলোড'];
    $total_প্রিন্ট_করার_উপযোগী += (int)$smartcard['প্রিন্ট_করার_উপযোগী'];
    $total_প্রিন্টেড += (int)$smartcard['প্রিন্টেড'];
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS-GD | Manage Smartcards</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            font-size: 18px;
            background-color: #f8f9fa;
        }
        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 10px;
            color: #0056b3;
        }
        .table-responsive {
            margin-top: 20px;
            width: 100%;
        }
        .table th, .table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }
        .search-bar {
            margin: 20px 0;
            text-align: center;
        }
        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
        }
        .btn-custom {
            font-size: 18px;
            padding: 12px 20px;
        }
        .alert {
            text-align: center;
            font-size: 18px;
            background-color: #28a745;
            color: white;
            padding: 15px;
            border-radius: 5px;
        }
        @media print {
            @page {
                size: landscape;
                margin: 10mm;
            }
            body {
                font-size: 12px;
            }
            .search-bar, .btn-custom, .alert {
                display: none;
            }
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="container">
        <h1>প্রবাসে জাতীয় পরিচয়পত্র সেবা</h1>
        <div class="search-bar">
            <form method="POST" class="form-inline">
                <!-- Search Input -->
                <input type="text" name="search_query" class="form-control" value="<?php echo htmlentities($search); ?>" placeholder="Search">
                <button type="submit" name="search" class="btn btn-primary ml-2 btn-custom">Search</button>

                <!-- Radio Buttons for Date Filtering -->
                <label class="ml-4">Date wise Data:</label>
                <label><input type="radio" name="filter_date" value="today" <?php echo $filter_date == 'today' ? 'checked' : ''; ?>>Today's Entries</label>
                <label><input type="radio" name="filter_date" value="all" <?php echo $filter_date == 'all' || empty($filter_date) ? 'checked' : ''; ?>>All Day's Entries</label>

                <button type="submit" name="filter" class="btn btn-primary ml-2 btn-custom">Filter Data</button>
            </form>
        </div>
        
        <?php if (isset($msg)) { ?>
            <div class="alert"><?php echo htmlentities($msg); ?></div>
        <?php } ?>
        
        <div class="text-center">
            <button class="btn btn-primary btn-custom" onclick="printTable()">Print</button>
        </div>

        <div class="table-responsive">
            <table class="table" id="printableTable">
                <thead>
                    <tr>
                        <th>নাম</th>
                        <th>তারিখ</th>
                        <th>মোট আবেদন</th>
                        <th>মিশন অফিসে বায়োমেট্রিক গ্রহণ</th>
                        <th>তদন্ত সম্পন্ন,এপ্রুভ</th>
                        <th>তদন্ত সম্পন্ন,এপ্রুভ এর অপেক্ষাধীন</th>
                        <th>বাতিল</th>
                        <th>মোট</th>
                        <th>উপজেলা/থানা নির্বাচন অফিস কর্তৃক তদন্ত প্রক্রিয়াধীন</th>
                        <th>মিশন থেকে আপলোড অপেক্ষাধীন</th>
                        <th>আপলোড</th>
                        <th>প্রিন্ট করার উপযোগী</th>
                        <th>প্রিন্টেড</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($smartcards as $smartcard) { ?>
                        <tr>
                            <td><?php echo htmlentities($smartcard['নাম']); ?></td>
                            <td><?php echo htmlentities($smartcard['তারিখ']); ?></td>
                            <td><?php echo htmlentities($smartcard['মোট_আবেদন']); ?></td>
                            <td><?php echo htmlentities($smartcard['মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ']); ?></td>
                            <td><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ']); ?></td>
                            <td><?php echo htmlentities($smartcard['তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['বাতিল']); ?></td>
                            <td><?php echo htmlentities($smartcard['মোট']); ?></td>
                            <td><?php echo htmlentities($smartcard['উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['মিশন_থেকে_আপলোড_অপেক্ষাধীন']); ?></td>
                            <td><?php echo htmlentities($smartcard['আপলোড']); ?></td>
                            <td><?php echo htmlentities($smartcard['প্রিন্ট_করার_উপযোগী']); ?></td>
                            <td><?php echo htmlentities($smartcard['প্রিন্টেড']); ?></td>
                        </tr>
                    <?php } ?>
                    <!-- Totals Row -->
                    <tr>
                        <th>সর্বমোট:</th>
                        <td><?php echo number_format($total_মোট_আবেদন); ?></td>
                        <td><?php echo number_format($total_মিশন_অফিসে_বায়োমেট্রিক_গ্রহণ); ?></td>
                        <td><?php echo number_format($total_তদন্ত_সম্পন্ন_এপ্রুভ); ?></td>
                        <td><?php echo number_format($total_তদন্ত_সম্পন্ন_এপ্রুভ_এর_অপেক্ষাধীন); ?></td>
                        <td><?php echo number_format($total_বাতিল); ?></td>
                        <td><?php echo number_format($total_মোট); ?></td>
                        <td><?php echo number_format($total_উপজেলা_থানা_নির্বাচন_অফিস_কর্তৃক_তদন্ত_প্রক্রিয়াধীন); ?></td>
                        <td><?php echo number_format($total_মিশন_থেকে_আপলোড_অপেক্ষাধীন); ?></td>
                        <td><?php echo number_format($total_আপলোড); ?></td>
                        <td><?php echo number_format($total_প্রিন্ট_করার_উপযোগী); ?></td>
                        <td><?php echo number_format($total_প্রিন্টেড); ?></td>
                        <td></td> <!-- Empty cell for the last column (Date) -->
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function printTable() {
            var printWindow = window.open('', '', 'height=700,width=1000');
            printWindow.document.write('<html><head><title>Smartcards Print</title>');
            printWindow.document.write('<style>');
            printWindow.document.write('body { font-size: 12px; text-align: center; }');
            printWindow.document.write('table { border-collapse: collapse; width: 100%; margin-top: 20px; }');
            printWindow.document.write('th, td { border: 3px solid black; padding: 10px; text-align: center; }');
            printWindow.document.write('</style></head><body>');
            printWindow.document.write('<img src="ecs.png" alt="ECS Logo" style="display:block; margin:auto; width:100px;"/>');
            printWindow.document.write('<h4>অদ্যাবধি প্রবাসে বসবাসরত বাংলাদেশী নাগরিকগণের ভোটার নিবন্ধন ও জাতীয় পরিচয়পত্র প্রদানের তথ্যাদির</h4>');
            printWindow.document.write('<h4>সার-সংক্ষেপ</h4>');
            printWindow.document.write(document.getElementById('printableTable').outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }
    </script>
</body>
</html>
