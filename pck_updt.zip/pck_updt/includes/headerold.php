<?php


// Check if user is logged in (either as admin or regular user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');  // Redirect to the login page if neither is logged in
    exit;  // Ensure script stops after redirect
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
   
    
</html>
<?php
// Check if user is logged in (either as admin or regular user)
if (!isset($_SESSION['alogin']) && !isset($_SESSION['userlogin'])) {
    header('location:index.php');  // Redirect to the login page if neither is logged in
    exit;  // Ensure script stops after redirect
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Dropdown Fix</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    
    <style>
        /* Dropdown customization */
        .navbar .dropdown-menu {
            background-color: rgba(0, 0, 0, 0.8); /* Transparent black background */
            color: white;
            border-radius: 5px;
            padding: 10px 0;
            margin-top: 5px; /* Slight offset from the parent */
            position: absolute; /* Ensures it stays positioned relative to the parent */
            z-index: 9999; /* Keep the dropdown above other elements */
        }

        /* Backdrop customization */
        .dropdown-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Transparent overlay */
            z-index: 999; /* Set this below the dropdown but still above other elements */
            display: none; /* Hide by default */
        }

        /* Highlighting the dropdown items */
        .navbar .dropdown-menu li a {
            color: white; /* White text for dropdown items */
            padding: 8px 20px;
            display: block;
            text-decoration: none;
        }

        .navbar .dropdown-menu li a:hover {
            background-color: yellow; /* Highlight on hover */
            color: black; /* Change text to black */
        }

        /* Fix dropdown overlap issue */
        .dropdown:hover .dropdown-menu {
            display: block; /* Ensure dropdown stays open */
            opacity: 1; /* Ensure full visibility */
            visibility: visible;
        }
    </style>
</head>
<body>
     <!-- top-header -->
    <?php if (isset($_SESSION['userlogin']) && !empty($_SESSION['userlogin'])): ?>
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="main.php"><i class="fa fa-home"></i></a></li>
                    
                    <li><a href="admin/user-dashboard.php">Go to Dashboard</a></li> <!-- Dashboard link for user -->
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
                    <li class="tol">Welcome :</li>
                    <li class="sig"><?php echo htmlentities($_SESSION['userlogin']);?></li>
                    <li class="sigi"><a href="logout.php">/ Logout</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php elseif (isset($_SESSION['alogin']) && !empty($_SESSION['alogin'])): ?>
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="main.php"><i class="fa fa-home"></i></a></li>
                    <li class="prnt"><a href="admin/dashboard.php">Admin Dashboard</a></li> <!-- Admin Dashboard link -->
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
                    <li class=""><a href="admin/index.php"> 
                        <center>Identification System For Enhancing Access to Services (IDEA PHASE-2)</center></a></li>
                    <li class="tol">Helpline : 01796052223</li>                
                   
                    <li class="tol">Welcome Admin :</li>
                    <li class="sig"><?php echo htmlentities($_SESSION['alogin']);?></li>
                    <li class="sigi"><a href="logout.php">/ Logout</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php else: ?>
        <!-- For users who are not logged in (no session or other credentials set) -->
        <div class="top-header">
            <div class="container">
                <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
                    <li class="hm"><a href="index.php"><i class="fa fa-home"></i></a></li>
                </ul>
                <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s"> 
                    <li class=""><a href="admin/index.php"> 
                        <center>Identification System For Enhancing Access to Services (IDEA PHASE-2)</center></a></li>
                    <li class="tol">Helpline : 01796052223</li>                
                    <li class="sig"><a href="index.php" >Back to Home</a></li> 
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php endif; ?>
    <!-- /top-header -->

    <div class="footer-btm">
        <div class="container">
            <div class="navigation">
                <nav class="navbar navbar-default">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                        <nav class="cl-effect-1">
                            <ul class="nav navbar-nav">
                                <li><a href="main.php">Home</a></li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Procurement <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="package-view.php">Package Overview</a></li>
                                        <li><a href="procure_sumview.php">Progress at a glance</a></li>
                                        
                                        <li><a href="live-package.php">Live Progress</a></li>
                                        <li><a href="package-list.php">Detail Progress</a></li>
                                        <li><a href="upcoming-package.php">Upcoming Packages</a></li>
                                        <li><a href="close-package.php">Closed Packages</a></li>
                                    </ul>
                                </li>
                                <li><a href="mediaview.php">Communication</a></li>
                                <li><a href="admin/gallery.php">Photo Gallery</a></li>
                                <div class="clearfix"></div>
                            </ul>
                        </nav>
                    </div>
                </nav>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>

    <!-- Backdrop for dropdown -->
    <div class="dropdown-backdrop"></div>

    <script>
    $(document).ready(function () {
        // Toggle dropdown when clicking "Procurement"
        $('.dropdown-toggle').on('click', function (e) {
            var $dropdown = $(this).next('.dropdown-menu');

            // Toggle the visibility of the dropdown
            $dropdown.toggleClass('stay-open');

            // Show or hide the backdrop based on dropdown visibility
            if ($dropdown.hasClass('stay-open')) {
                $('.dropdown-backdrop').fadeIn();  // Fade in the backdrop when dropdown is open
            } else {
                $('.dropdown-backdrop').fadeOut();  // Fade out the backdrop when dropdown is closed
            }

            // Prevent the event from bubbling up to avoid closing the dropdown when clicking inside
            e.stopPropagation();
        });

        // Prevent dropdown from closing when clicking inside the menu
        $(document).on('click', '.dropdown-menu', function (e) {
            e.stopPropagation();
        });

        // Hide dropdown when clicking outside the dropdown area or backdrop
        $(document).on('click', function () {
            $('.dropdown-menu').removeClass('stay-open');
            $('.dropdown-backdrop').fadeOut();  // Hide the backdrop when clicking outside
        });

        // Handle backdrop visibility
        $('.dropdown').on('show.bs.dropdown', function () {
            $('.dropdown-backdrop').fadeIn();
        });

        $('.dropdown').on('hide.bs.dropdown', function () {
            $('.dropdown-backdrop').fadeOut();
        });
    });
    </script>

</body>
</html>
