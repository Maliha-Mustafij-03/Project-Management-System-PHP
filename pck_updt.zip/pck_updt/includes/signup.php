<?php
error_reporting(0);
session_start(); // Start session if not already started

// Check if form is submitted
if(isset($_POST['submit']))
{
    // Assign user input to variables
    $fname = $_POST['fname'];
    $mnumber = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    // Prepare the SQL query with placeholders
    $sql = "INSERT INTO tblusers (FullName, MobileNumber, EmailId, Password) VALUES (:fname, :mnumber, :email, :password)";
    
    // Prepare the query using PDO
    $query = $dbh->prepare($sql);

    // Bind parameters
    $query->bindParam(':fname', $fname, PDO::PARAM_STR);
    $query->bindParam(':mnumber', $mnumber, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);

    // Execute the query
    $query->execute();

    // Get the last inserted ID to confirm success
    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        $_SESSION['msg'] = "You have successfully registered. Now you can log in.";
        header('location:thankyou.php');
    } else {
        $_SESSION['msg'] = "Something went wrong. Please try again.";
        header('location:thankyou.php');
    }
}
?>

<!-- HTML Structure for the Modal -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>

    <!-- Add some basic CSS for styling -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .modal-dialog {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            max-width: 400px;
            margin: 100px auto;
        }

        .modal-header {
            border-bottom: none;
            padding-bottom: 0;
            position: relative; /* Make sure close button is positioned properly */
        }

        .login-right {
            padding: 20px;
        }

        .login-right h3 {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .login-right input[type="text"], .login-right input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            font-size: 16px;
            font-weight: bold;
            color: black;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .login-right input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
        }

        .login-right input[type="submit"]:hover {
            background-color: #45a049;
        }

        #user-availability-status {
            font-size: 14px;
            color: red;
        }

        .clearfix {
            clear: both;
        }

        /* Close Button */
        .close-btn {
            background-color: red;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 10px;
            z-index: 1;
        }

        .close-btn:hover {
            background-color: #d9534f;
        }
    </style>
</head>
<body>

    <!-- Modal Code -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close-btn" data-dismiss="modal" aria-label="Close">X</button>
                    <h4 class="modal-title" id="myModalLabel">Create an Account</h4>
                </div>
                <section>
                    <div class="modal-body modal-spa">
                        <div class="login-grids">
                            <div class="login">
                                <div class="login-right">
                                    <!-- User Registration Form -->
                                    <form name="signup" method="post">
                                        <h3>Create your account</h3>

                                        <input type="text" value="" placeholder="Full Name" name="fname" autocomplete="off" required>
                                        <input type="text" value="" placeholder="Mobile number" maxlength="20" name="mobilenumber" autocomplete="off" required>
                                        <input type="text" value="" placeholder="Email id" name="email" id="email" onBlur="checkAvailability()" autocomplete="off" required>
                                        <span id="user-availability-status" style="font-size:12px;"></span>
                                        <input type="password" value="" placeholder="Password" name="password" required>
                                        <input type="submit" name="submit" id="submit" value="CREATE ACCOUNT">
                                    </form>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <p>By logging in you agree to our <a href="page.php?type=terms">Terms and Conditions</a> and <a href="page.php?type=privacy">Privacy Policy</a></p>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- JavaScript for checking email availability -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function checkAvailability() {
            // Show loading spinner (you can create an actual loader icon if desired)
            $("#loaderIcon").show();

            // AJAX request to check email availability
            jQuery.ajax({
                url: "check_availability.php",
                data: 'emailid=' + $("#email").val(),
                type: "POST",
                success: function(data) {
                    $("#user-availability-status").html(data);
                    $("#loaderIcon").hide();
                },
                error: function() {
                    alert("Error while checking availability.");
                }
            });
        }
    </script>

</body>
</html>
