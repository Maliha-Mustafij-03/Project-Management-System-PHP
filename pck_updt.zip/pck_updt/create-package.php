<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit; // Make sure to exit after redirecting
}

// Handle package creation for both admin and user
if (isset($_POST['submit'])) {
    $pno = $_POST['packageno'];
    $pdetails = $_POST['packagedetails'];    
    $sfd = $_POST['specificationforwardingdate'];
    $pmt = $_POST['purchasemethodtype'];
    $ee = $_POST['estimatedexpenditure'];
    $rp = $_POST['responsibleperson'];
    $consultant = $_POST['consultant'];
    $lc = $_POST['lc'];
    $pimage = $_FILES["packageimage"]["name"];
    
    move_uploaded_file($_FILES["packageimage"]["tmp_name"], "packageimages/" . $pimage);

    // Insert package into tbltenderpackages
    $sql = "INSERT INTO tbltenderpackages (PackageNo, Details, SpecificationForwardingDate, PurchaseMethodType, EstimatedExpenditure, ResponsiblePerson, Consultant, liveorclose) 
            VALUES (:pno, :pdetails, :sfd, :pmt, :ee, :rp, :consultant, :lc)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':pno', $pno, PDO::PARAM_STR);
    $query->bindParam(':pdetails', $pdetails, PDO::PARAM_STR);
    $query->bindParam(':sfd', $sfd, PDO::PARAM_STR);
    $query->bindParam(':pmt', $pmt, PDO::PARAM_STR);
    $query->bindParam(':ee', $ee, PDO::PARAM_STR);
    $query->bindParam(':rp', $rp, PDO::PARAM_STR);
    $query->bindParam(':consultant', $consultant, PDO::PARAM_STR);
    $query->bindParam(':lc', $lc, PDO::PARAM_STR);
    $query->execute();

    $lastInsertId = $dbh->lastInsertId();
    if ($lastInsertId) {
        // Insert details into tblpackagedetails
        foreach ($_POST['package_details'] as $index => $detail) {
            if (!empty($detail)) {
                $detailPart2 = $_POST['detail_part2'][$index];
                $status = $_POST['status'][$index];
                $completionDate = $_POST['completion_date'][$index];

                // Insert status and completion date into tblpackagedetails
                $sqlDetail = "INSERT INTO tblpackagedetails (PackageId, Detail, DetailPart2, Status, ActualCompletedDate) 
                            VALUES (:packageId, :detail, :detailPart2, :status, :completionDate)";
                $queryDetail = $dbh->prepare($sqlDetail);
                $queryDetail->bindParam(':packageId', $lastInsertId, PDO::PARAM_INT);
                $queryDetail->bindParam(':detail', $detail, PDO::PARAM_STR);
                $queryDetail->bindParam(':detailPart2', $detailPart2, PDO::PARAM_STR);
                $queryDetail->bindParam(':status', $status, PDO::PARAM_STR);
                $queryDetail->bindParam(':completionDate', $completionDate, PDO::PARAM_STR);
                $queryDetail->execute();
            }
        }
        $msg = "Package Created Successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>NCS | Admin Package Creation</title>

<script type="application/x-javascript"> 
    addEventListener("load", function() { 
        setTimeout(hideURLbar, 0); 
    }, false); 
    
    function hideURLbar(){ 
        window.scrollTo(0,1); 
    } 
</script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery-2.1.4.min.js"></script>

    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>

<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<style>

/* Ensure the page is scrollable */
html, body {
    height: 100%; /* Ensure full height */
    margin: 0;    /* Remove margin to avoid unwanted scrollbars */
    overflow: auto; /* Allow scrolling when necessary */
}

/* Make the page-container scrollable */
.page-container {
    height: 100%;  /* Allow the container to take full height */
    overflow: auto; /* Enable scrolling for the page-container */
}

/* Make sure content doesn't overflow unintentionally */
.mother-grid-inner {
    height: auto;  /* Allow content to adjust its height */
    padding-bottom: 30px; /* Add padding for some space at the bottom */
}

/* Fix for other elements to improve layout */
.form-group {
    margin-bottom: 15px; /* Add margin to prevent crowded elements */
}


/* Style for the select dropdown field */
.dropdown-style {
    position: relative;            /* For positioning the arrow */
    padding-right: 30px;           /* Space for the dropdown arrow */
    font-size: 16px;               /* Font size */
    font-weight: bold;             /* Font weight */
    appearance: none;              /* Remove the default dropdown arrow */
    -webkit-appearance: none;      /* For Safari */
    -moz-appearance: none;         /* For Firefox */
    background-color: #ffffff;     /* White background */
    color: #333333;                /* Dark text color */
    border: 2px solid #008CBA;     /* Blue border to make the dropdown noticeable */
    border-radius: 5px;            /* Rounded corners */
    padding: 10px 12px;            /* Padding for input */
    transition: all 0.3s ease;     /* Smooth transition for hover and focus effects */
}

/* Arrow for the dropdown */
.dropdown-style::after {
    content: '\25BC';              /* Unicode for the downward triangle (▾) */
    position: absolute;
    right: 10px;                   /* Right-align the arrow */
    top: 50%;                       /* Vertically center the arrow */
    transform: translateY(-50%);    /* Align the arrow in the middle */
    font-size: 16px;                /* Size of the arrow */
    color: #008CBA;                 /* Matching blue color for the arrow */
    pointer-events: none;           /* Prevents the arrow from blocking interaction */
}

/* Change the background and border color on focus */
.dropdown-style:focus {
    border-color: #005f73;          /* Darker blue border on focus */
    background-color: #f0f8ff;      /* Light blue background on focus */
    outline: none;                  /* Removes the default focus outline */
}

/* Styling for the dropdown items */
.dropdown-style option {
    font-size: 16px;                /* Ensure dropdown options have the same font size */
    color: #333;                    /* Text color for the options */
}

/* Hover effect for the dropdown */
.dropdown-style:hover {
    background-color: #e6f7ff;      /* Light blue background on hover */
    border-color: #005f73;          /* Darker blue border on hover */
}

/* Added scrollbar for details container */


.form-control1 {
    font-size: 16px;
    font-weight: bold;
}

.form-group label {
    font-weight: bold;
}

.detail-row {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.detail-row input, .detail-row select {
    margin-right: 10px;
}

.btn-container {
    margin-top: 10px;
    margin-bottom: 20px;
}

.btn-container button {
    margin-right: 10px;
}
#detailsContainer {
    max-height: 300px;  /* Adjust this height as needed */
    overflow-y: auto;   /* Enables vertical scrolling */
    border: 1px solid #ccc;  /* Border for better visibility */
    padding: 10px;
}

</style>

</style>

<script>
function addDetail() {
    var container = document.getElementById('detailsContainer');
    var row = document.createElement('div');
    row.className = 'detail-row';

    // Add description for Tender Details
    var tenderLabel = document.createElement('label');
    tenderLabel.innerHTML = 'কর্মের অগ্রগতি:';
    row.appendChild(tenderLabel);

    // Detail dropdown for "কার্যক্রম সমূহ"
    var detailInput = document.createElement('select');
    detailInput.name = 'package_details[]';
    detailInput.className = 'form-control1';

    // Add the options for "কার্যক্রম সমূহ"
    var options = [
        'স্পেসিফিকেশন প্রণয়ন', 
        'দাপ্তরিক প্রাক্কলন প্রণয়ন', 
        'দরপত্র দলিল প্রস্তুত', 
        'দরপত্র দলিল অনুমোদন সচিব(HoPE)', 
        'দরপত্র দলিল অনুমোদন প্রকল্প পরিচালক(PE)', 
        'দরপত্র আহবান/বিজ্ঞাপন প্রকাশ', 
        'প্রি-বিড সভা', 
        'দরপত্র উন্মুক্তকরণ', 
        'দরপত্র মূল্যায়ন', 
        'মূল্যায়ন প্রতিবেদন সুপারিশ অনুমোদন', 
        'NoA/LoA (কার্যাদেশ) প্রদান', 
        'NoA/LoA গ্রহণ', 
        'চুক্তি স্বাক্ষর', 
        'চুক্তি বাস্তবায়ন/প্রণয়ন', 
        'অন্যান্য'
    ];

    options.forEach(function(optionText) {
        var option = document.createElement('option');
        option.value = optionText;
        option.innerHTML = optionText;
        detailInput.appendChild(option);
    });

    row.appendChild(detailInput);

    // Tentative Date input
    var dateLabel = document.createElement('label');
    dateLabel.innerHTML = 'নির্ধারিত তারিখ:';
    row.appendChild(dateLabel);

    var dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.name = 'detail_part2[]';
    dateInput.className = 'form-control1';
    row.appendChild(dateInput);

    // Responsibility Officer/Employee (Text Input)
    var statusLabel = document.createElement('label');
    statusLabel.innerHTML = 'দ্বায়িত্বপ্রাপ্ত কর্মকর্তা/কর্মচারী:';
    row.appendChild(statusLabel);

    var statusInput = document.createElement('input');
    statusInput.type = 'text';
    statusInput.name = 'status[]';
    statusInput.className = 'form-control1';
    statusInput.placeholder = 'কর্মকর্তা/কর্মচারী নাম';
    row.appendChild(statusInput);

    // Actual Completion Date input
    var completionDateLabel = document.createElement('label');
    completionDateLabel.innerHTML = 'বাস্তবায়নের তারিখ:';
    row.appendChild(completionDateLabel);

    var completionDateInput = document.createElement('input');
    completionDateInput.type = 'date';
    completionDateInput.name = 'completion_date[]';
    completionDateInput.className = 'form-control1';
    row.appendChild(completionDateInput);

    container.appendChild(row);
}


function removeDetail() {
    var container = document.getElementById('detailsContainer');
    if (container.children.length > 1) { // Keep at least one field
        container.removeChild(container.lastChild);
    }
}
</script>

</head> 
<body>
   <div class="page-container">
       <div class="left-content">
           <div class="mother-grid-inner">
               <?php include('includes/header.php');?>
               <div class="clearfix"> </div>    
           </div>

           <ol class="breadcrumb">
               <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>নতুন প্যাকেজ এন্ট্রি করুন </li>
           </ol>

           <div class="grid-form">
               <div class="grid-form1">
                   <h3>বর্তমান অর্থবছর ২০২৩-২০২৪-এর জন্য অনুমোদিত নিম্নলিখিত প্যাকেজগুলির দ্রুত কেনাকাটা প্রক্রিয়া সম্পন্ন করার জন্য টেন্ডার আহবানের জন্য প্রয়োজনীয় টেকনিক্যাল স্পেসিফিকেশন </h3>
                   <?php if($error) { ?>
                       <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
                   <?php } else if($msg) { ?>
                       <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
                   <?php } ?>

                   <div class="tab-content">
                       <div class="tab-pane active" id="horizontal-form">
                           <form class="form-horizontal" name="package" method="post" enctype="multipart/form-data">
                               <!-- Basic package details -->
                               <div class="form-group">
                                   <label for="focusedinput" class="col-sm-2 control-label">প্যাকেজ নম্বর</label>
                                   <div class="col-sm-8">
                                       <input type="text" class="form-control1" name="packageno" id="packageno" placeholder="প্যাকেজ নম্বর" required>
                                   </div>
                               </div>

                               <div class="form-group">
                                   <label for="focusedinput" class="col-sm-2 control-label">ডিপিপি অনুযায়ী ক্র্রয়ের জন্য প্যাকেজ বর্ননা</label>
                                   <div class="col-sm-8">
                                       <textarea name="packagedetails" id="packagedetails" class="form-control1" rows="3" placeholder="বিস্তারিত" required></textarea>
                                   </div>
                               </div>

                               
                               
                               <div class="form-group">
    <label for="focusedinput" class="col-sm-2 control-label">দরপত্র আহবান এর তারিখ</label>
    <div class="col-sm-8">
        <input type="text" class="form-control1" name="consultant" id="consultant" placeholder="" >
    </div>
</div>
                                <!-- Additional Fields for Purchase method, Estimated expenditure, etc. -->
                               <div class="form-group">
                                   <label for="focusedinput" class="col-sm-2 control-label">ক্রয় পদ্ধতি ও ধরণ</label>
                                   <div class="col-sm-8">
                                       <input type="text" class="form-control1" name="purchasemethodtype" id="purchasemethodtype" placeholder="ক্রয় পদ্ধতি ও ধরণ" required>
                                   </div>
                               </div>
                               <div class="form-group">
                               <label for="focusedinput" class="col-sm-2 control-label">প্রাক্কলিত ব্যয় (লক্ষ টাকা)</label>
                               <div class="col-sm-8">
                                   <input type="number" step="0.01" class="form-control1" name="estimatedexpenditure" id="estimatedexpenditure" placeholder="প্রাক্কলিত ব্যয় (লক্ষ টাকা)" required>
                               </div>
                           </div>
                           <div class="form-group">
                               <label for="focusedinput" class="col-sm-2 control-label">ক্রয় অনুমোদনকারী কর্তৃপক্ষ</label>
                               <div class="col-sm-8">
                                   <input type="text" class="form-control1" name="responsibleperson" id="responsibleperson" placeholder="ক্রয় অনুমোদনকারী কর্তৃপক্ষ" >
                               </div>
                           </div>
                           <div class="form-group">
                                   <label for="focusedinput" class="col-sm-2 control-label">চুক্তির অগ্রগতির তারিখ</label>
                                   <div class="col-sm-8">
                                       <input type="date" class="form-control1" name="specificationforwardingdate" id="specificationforwardingdate" required>
                                   </div></div>
                           

<div class="form-group">
    <label for="lc" class="col-sm-2 control-label">চলমান/সম্পন্ন/আসন্ন</label>
    <div class="col-sm-8">
        <!-- Using inline-block to align radio buttons horizontally -->
        <label class="radio-inline">
            <input type="radio" class="form-check-input" name="lc" id="lc_cholman" value="চলমান" required>
            চলমান
        </label>
        <label class="radio-inline">
            <input type="radio" class="form-check-input" name="lc" id="lc_shomponno" value="সম্পন্ন" required>
            সম্পন্ন
        </label>
        <label class="radio-inline">
            <input type="radio" class="form-check-input" name="lc" id="lc_assonno" value="আসন্ন" required>
            আসন্ন
        </label>
    </div>
</div>

                               <!-- Package details rows -->
                               <div class="form-group">
                                   <div class="col-sm-12">
                                       <div id="detailsContainer"></div>
                                       <div class="btn-container">
                                           <button type="button" class="btn btn-primary" onclick="addDetail()">নতুন যোগ করুন</button>
                                           <button type="button" class="btn btn-danger" onclick="removeDetail()">আগের তথ্য মুছুন</button>
                                       </div>
                                   </div>
                               </div>

                               <!-- Submit -->
                               <div class="form-group">
                                   <div class="col-sm-8">
                                       <button type="submit" name="submit" class="btn btn-success">তথ্য সংরক্ষন</button>
                                   </div>
                               </div>
                           </form>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>

</body>
</html>
