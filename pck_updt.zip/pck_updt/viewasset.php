<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

$sql = "SELECT * FROM stock_report_list_view";
    $query = $dbh->prepare($sql);
    $query->execute();
$data = $query->fetchAll(PDO::FETCH_ASSOC);

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    
    <link href="css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="datatable/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/dataTables.bootstrap.min.css" />

    <script src="js/bootstrap.min.js"></script>
    <script src="script/js/jquery.min.js"></script>
    <script src="datatable/js/dataTables.bootstrap.min.js"></script>
    <script src="datatable/js/jquery.dataTables.min.js"></script>
    <script src="datatable/js/dataTables.buttons.min.js"></script>
    <script src="datatable/js/jszip.min.js"></script>
    <script src="datatable/js/buttons.html5.min.js"></script>
    <script src="datatable/js/buttons.print.min.js"></script>

    <style>
        /* Global Styles */
        
        h1 {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            background-color: #007bff;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            position: relative;
            top: 0;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>এ্যাসেট ম্যানেজমেন্ট </h1>
        <!-- <a href="http://172.16.243.112/asset/auth/login" class="pull-right blinking-link package-overview">Asset Module</a> -->
        <!-- Assets Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="userTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Supplier Name</th>
                <th>GSRN No.</th>
                <th>Recieved Date</th>
                <th>Item Name</th>
                <th>Brand Name</th>
                <th>Model Name</th>
                <th>Total Purchased</th>
                <th>In Store</th>
              </tr>
            </thead>
            <tbody>
              <?php if($data): ?>
                <?php foreach($data as $key => $value): ?>
                  <tr>
                    <td><?= $key+1; ?></td>
                    <td><?= $value['vendor_name'] ?></td>
                    <td><?= $value['gsrn_no'] ?></td>
                    <td><?= date('M d, Y', $value['purchase_date']) ?></td>
                    <td><?= $value['item_name'] ?></td>
                    <td><?= $value['brand_name'] ?></td>
                    <td><?= $value['model_name'] ?></td>
                    <td><?= $value['qty']; ?></td>
                    <td><?php if ($value['stock_qty'] < 10) {
                      echo "<span class='label label-danger'>".$value['stock_qty']."</span>";
                      } else {
                        echo "<span class='label label-success'>".$value['stock_qty']."</span>";
                    }?></td>
                    </tr>
                  <?php endforeach ?>
                <?php endif; ?>
              </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<script type="text/javascript">

$(document).ready(function(){

    $('#userTable').DataTable({
        dom: 'lBfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'print'
        ]
    });

});



</script>
