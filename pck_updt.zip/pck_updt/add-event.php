<?php
require_once "db.php";

// Check if data is being sent via POST
$title = isset($_POST['title']) ? $_POST['title'] : "";
$start = isset($_POST['start']) ? $_POST['start'] : "";
$end = isset($_POST['end']) ? $_POST['end'] : "";
$category = isset($_POST['category']) ? $_POST['category'] : 1; // Default to category 1 if not provided

// Map categories to colors
$colors = [
    1 => '#e74c3c', // Red
    2 => '#8e44ad', // Purple
    3 => '#3498db', // Blue
    4 => '#2ecc71'  // Green
];

// Set color based on category
$color = isset($colors[$category]) ? $colors[$category] : '#000000'; // Default to black if category is invalid

// Prepare the SQL query to insert the event into the database
$sqlInsert = "INSERT INTO tbl_events (title, start, end, color) VALUES ('".$title."', '".$start."', '".$end."', '".$color."')";

// Execute the query
$result = mysqli_query($conn, $sqlInsert);

// Check if the insertion was successful
if ($result) {
    echo "Event added successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
