<?php
session_start();
include('includes/config.php');

// Check if login form is submitted
if (isset($_POST['login'])) {
    $uname = $_POST['username'];
    $password = md5($_POST['password']); // Ensure this matches the hash method used in your database

    // Check in admin table
    $sql = "SELECT UserName, Password FROM admin WHERE UserName = :uname AND Password = :password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':uname', $uname, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();

    if ($query->rowCount() > 0) {
        $_SESSION['alogin'] = $uname;
        // Redirect directly to the main.php page after successful login
        header('location: main.php');
        exit(); // Always use exit() after header redirection
    } else {
        // Check in user table
        $sql = "SELECT FullName, Password, UserType FROM tblusers WHERE FullName = :uname AND Password = :password";
        $query = $dbh->prepare($sql);
        $query->bindParam(':uname', $uname, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR);
        $query->execute();

        if ($query->rowCount() > 0) {
            $_SESSION['userlogin'] = $uname;
            // Get the user type from the database and store it in session
            $user = $query->fetch(PDO::FETCH_ASSOC);
            $_SESSION['usertype'] = $user['UserType']; // Store user type in session
            // Redirect directly to the main.php page after successful login
            header('location: main.php');
            exit(); // Always use exit() after header redirection
        } else {
            $errorMessage = "Invalid Username or Password"; // Display error message
        }
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | NCS/GD</title>
    <style>
        /* General page layout */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Main wrapper */
        .main-wthree {
            background: url('images/bluesky.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Container for the login form */
        .container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Styling for the login form */
        .sin-w3-agile {
            padding: 40px;
            text-align: center;
        }

        /* Heading */
        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        /* Form elements */
        .username,
        .password-agileits,
        .user-type {
            margin-bottom: 20px;
            text-align: left; /* Align text to the left for all form fields */
        }

        .username span,
        .password-agileits span,
        .user-type span {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }

        /* Submit button */
        .login-w3 input[type="submit"] {
            width: 100%;
            background-color: #5cb85c;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }

        .login-w3 input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        /* Register button */
        .register-w3 a {
            display: inline-block;
            background-color: #f0ad4e;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }

        .register-w3 a:hover {
            background-color: #ec971f;
        }

        /* Forgot password link */
        a {
            color: #337ab7;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Back to home link */
        .back a {
            color: #000000; /* Black color */
            font-size: 14px;
            margin-top: 15px;
            display: block;
        }

        .back a:hover {
            text-decoration: underline;
        }

        /* Error message */
        div[style="color: red; margin-top: 10px;"] {
            font-size: 14px;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }

    </style>
</head>
<body>
    <div class="main-wthree">
        <div class="container">
            <div class="sin-w3-agile">
                <h2>Sign In</h2>
                <form method="post">
                    <div class="username">
                        <span class="username">User Name:</span>
                        <input type="text" name="username" class="name" placeholder="Enter your username" required=""/>
                    </div>

                    <div class="password-agileits">
                        <span class="username">Password:</span>
                        <input type="password" name="password" class="password" placeholder="Enter your password" required=""/>
                    </div>

                   <!--  <div class="user-type">
                        <span class="user-type">User Type:</span>
                        <select name="usertype" required="true">
                            <option value="">Select User Type</option>
                            <option value="Procurement">Procurement</option>
                            <option value="Communication">Communication</option>
                            <option value="Smartcard Expatriate">Smartcard Expatriate</option>
                            <option value="Smartcard Statistics">Smartcard Statistics</option>
                            <option value="PD Dept">PD Dept</option>
                             <option value="PD Dept">Finance</option>
                            <option value="Others">Others</option>
                        </select>
                    </div> -->

                    <div class="login-w3">
                        <input type="submit" class="login" name="login" value="Sign In"/>
                    </div>

                    <div class="clearfix"></div>

                    <?php if (isset($errorMessage)) { ?>
                        <div style="color: red; margin-top: 10px;"><?php echo $errorMessage; ?></div>
                    <?php } ?>
                </form>

                <!-- Registration link -->
                <div class="back">
                    
                </div>
            </div>
        </div>
    </div>
</body>
</html>
