<?php
session_start();
error_reporting(0);
include('includes/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    $sql = "INSERT INTO urgent_news (title, description) VALUES (:title, :description)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':title', $title, PDO::PARAM_STR);
    $query->bindParam(':description', $description, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        $msg = "Urgent News posted successfully";
    } else {
        $error = "Something went wrong. Please try again";
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>NCS Package Record System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script>
        new WOW().init();
    </script>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Open Sans', sans-serif;
        }

        header, footer {
            background: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        .marquee {
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            box-sizing: border-box;
            font-size: 40px;
            padding: 10px 0;
            background-color: #ff4757;
            color: white;
            text-align: center;
        }

        .marquee span {
            display: inline-block;
            padding-left: 100%;
            animation: marquee 60s linear infinite;
        }

        @keyframes marquee {
            0%   { transform: translate(0, 0); }
            100% { transform: translate(-100%, 0); }
        }

        .marquee a {
            text-decoration: none;
            color: #fff;
        }

        .marquee a:hover {
            text-decoration: underline;
        }

        .carousel-inner img {
            width: 100%;
            height: 100vh;
            object-fit: cover;
        }

        .holiday, .urgent-news {
            background-color: #f5f5f5;
            padding: 50px 0;
            margin-top: 50px;
        }

        .holiday h3, .urgent-news h4 {
            text-align: center;
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }

        .room-btm {
            /* Add your custom styles here */
        }
    </style>
</head>
<body>
    <header>
        <?php include('includes/header.php');?>
        <h1>NCS Package Record System</h1>
    </header>
    <div class="container">
        <div class="urgent-news">
            <h4>Post Urgent News</h4>
            <?php if($msg){ ?><div class="alert alert-success" role="alert"><?php echo htmlentities($msg); ?></div><?php } ?>
            <?php if($error){ ?><div class="alert alert-danger" role="alert"><?php echo htmlentities($error); ?></div><?php } ?>
            <form method="post">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <footer>
        &copy; 2024 NCS-GD Package Record System
    </footer>
</body>
</html>
