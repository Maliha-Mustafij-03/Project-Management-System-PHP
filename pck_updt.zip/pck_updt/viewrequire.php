<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);  // Enable error display for debugging
include('includes/config.php');

// Initialize error and success messages
$error = "";
$msg = "";

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Get search term if any
$searchTerm = isset($_POST['search']) ? $_POST['search'] : '';

// Fetch smart card distributions along with conditions (one-to-many) and handle search
$sql = "SELECT s.id, s.serial_no, s.country_name, c.card_number, c.remaining, c.condition_date 
        FROM smart_card_distribution s
        LEFT JOIN smart_card_conditions c ON s.id = c.distribution_id
        WHERE s.country_name LIKE :searchTerm OR c.card_number LIKE :searchTerm";
$query = $dbh->prepare($sql);
$query->execute([':searchTerm' => '%' . $searchTerm . '%']);
$results = $query->fetchAll(PDO::FETCH_ASSOC);

// Get today's date for comparison
$today = date('Y-m-d');
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Smart Card Distribution</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <style>
        /* General table styling */
        .table-container {
            margin-top: 20px;
        }
        .btn-container {
            margin-top: 10px;
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
            font-weight: bold; /* Make text bold */
            color: black; /* Set text color to black */
        }

        /* Corporate look */
        .table {
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .table th {
            background-color: #007BFF;
            color: #fff;
        }

        .table td {
            background-color: #f9f9f9;
        }

        .btn-container {
            margin-top: 15px;
        }

        /* Red for past dates */
        .past-date {
            background-color: #FF6347; /* Tomato Red */
            color: white;
        }

        /* Green for today's and upcoming dates */
        .future-date {
            background-color: #28a745; /* Green */
            color: white;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php'); ?>
                <div class="clearfix"> </div>    
            </div>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/pck_updt/main.php">হোম</a><i class="fa fa-angle-right"></i>স্মার্ট কার্ড বিতরণ পরিচালনা</li>
            </ol>

            <div class="grid-form">
                <div class="grid-form1">
                    <h3>স্মার্ট কার্ড বিতরণ ব্যবস্থাপনা</h3>
                    <?php if ($error) { ?>
                        <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div>
                    <?php } else if ($msg) { ?>
                        <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div>
                    <?php } ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <input type="text" name="search" class="form-control" placeholder="Search by Country Name or Card Number" value="<?php echo htmlentities($searchTerm); ?>" />
                        </div>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>

                    <div class="table-container">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ক্রম নং</th>
                                    <th>দেশের নাম</th>
                                    <th>মুদ্রিত কার্ডের সংখ্যা</th>
                                    <th>মুদ্রন বাকি কার্ড সংখ্যা</th>
                                    <th>তারিখ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Display all records and associated conditions
                                $currentDistributionId = null;
                                foreach ($results as $row) {
                                    // Get the condition date
                                    $conditionDate = $row['condition_date'];
                                    
                                    // Determine if the condition date is in the past, today, or future
                                    if ($conditionDate < $today) {
                                        $rowClass = 'past-date'; // Past date will be red
                                    } else {
                                        $rowClass = 'future-date'; // Future or today's date will be green
                                    }

                                    // Check if this is the first row for a new distribution
                                    if ($currentDistributionId != $row['id']) {
                                        // This is a new distribution row, so print the distribution info
                                        $currentDistributionId = $row['id'];
                                        echo "<tr class='$rowClass'>
                                                <td>" . htmlentities($row['serial_no']) . "</td>
                                                <td>" . htmlentities($row['country_name']) . "</td>
                                                <td>" . htmlentities($row['card_number']) . "</td>
                                                <td>" . htmlentities($row['remaining']) . "</td>
                                                <td>" . htmlentities($row['condition_date']) . "</td>
                                              </tr>";
                                    } else {
                                        // This is a continuation of the same distribution, so just repeat the conditions
                                        echo "<tr class='$rowClass'>
                                                <td></td>
                                                <td></td>
                                                <td>" . htmlentities($row['card_number']) . "</td>
                                                <td>" . htmlentities($row['remaining']) . "</td>
                                                <td>" . htmlentities($row['condition_date']) . "</td>
                                              </tr>";
                                    }
                                }
                                if (!$results) {
                                    echo "<tr><td colspan='5'>কোনো তথ্য নেই</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php include('includes/footer.php'); ?>
        </div>
    </div>
</body>
</html>
