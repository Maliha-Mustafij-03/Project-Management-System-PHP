<?php
session_start();
error_reporting(0);
include('includes/config.php');

$msg = '';
$error = '';

// Handle comment submission
if (isset($_POST['submit2'])) {
    $pid = intval($_GET['pkgid']);
    $useremail = $_SESSION['login'];
    $comment = $_POST['comment'];
    $status = 'active';

    $sql = "INSERT INTO tblcomments (PackageId, UserEmail, Comment, Status) VALUES (:pid, :useremail, :comment, :status)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':pid', $pid, PDO::PARAM_INT);
    $query->bindParam(':useremail', $useremail, PDO::PARAM_STR);
    $query->bindParam(':comment', $comment, PDO::PARAM_STR);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        $msg = "Comment Stored Successfully";
        header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . $pid);
        exit;
    } else {
        $error = "Something went wrong. Please try again";
    }
}

// Handle comment update
if (isset($_POST['update'])) {
    $commentId = intval($_POST['commentId']);
    $updatedComment = $_POST['updatedComment'];

    $sql = "UPDATE tblcomments SET Comment = :updatedComment WHERE CommentId = :commentId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':updatedComment', $updatedComment, PDO::PARAM_STR);
    $query->bindParam(':commentId', $commentId, PDO::PARAM_INT);
    $query->execute();

    if ($query->rowCount()) {
        $msg = "Comment Updated Successfully";
        header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . intval($_GET['pkgid']));
        exit;
    } else {
        $error = "Failed to update comment";
    }
}

// Handle comment deletion
if (isset($_GET['delete'])) {
    $commentId = intval($_GET['delete']);

    $sql = "UPDATE tblcomments SET Status = 'deleted' WHERE CommentId = :commentId";
    $query = $dbh->prepare($sql);
    $query->bindParam(':commentId', $commentId, PDO::PARAM_INT);
    $query->execute();

    if ($query->rowCount()) {
        $msg = "Comment Deleted Successfully";
        header("Location: " . $_SERVER['PHP_SELF'] . "?pkgid=" . intval($_GET['pkgid']));
        exit;
    } else {
        $error = "Failed to delete comment";
    }
}

// Fetch comments for the package
$pid = intval($_GET['pkgid']);
$sqlComments = "SELECT CommentId, Comment, UserEmail FROM tblcomments WHERE PackageId = :pid AND Status = 'active'";
$queryComments = $dbh->prepare($sqlComments);
$queryComments->bindParam(':pid', $pid, PDO::PARAM_INT);
$queryComments->execute();
$comments = $queryComments->fetchAll(PDO::FETCH_OBJ);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>NCS | Package Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-2phE2g3zUfhZQ9k6F3aZCz8m1hF4Dj0a2Juq2D8FbIKzT0dO9A1g6BdN4qO7e8Nh0A9H0ZqDT5RkFa9XG1GTvg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .header, .banner-3 {
            background: #4CAF50; /* Green background */
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: 5px solid #388E3C; /* Darker green border */
        }
        .header h1, .banner-3 h1 {
            margin: 0;
            font-size: 2.5em;
        }
        .container {
            width: 80%;
            margin: auto;
        }
        .box-container {
            background: #ffffff;
            border: 1px solid #ddd; /* Light grey border */
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .selectroom, .details-box {
            padding: 20px;
        }
        .selectroom h2, .details-box h3 {
            font-size: 2em;
            margin-bottom: 20px;
            border-bottom: 2px solid #4CAF50; /* Green underline */
            padding-bottom: 10px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ddd; /* Light grey border */
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-item {
            font-size: 1.2em;
            color: #333;
        }
        .comment {
            padding: 15px;
            background: #ffffff;
            border: 1px solid #ddd; /* Light grey border */
            border-radius: 5px;
            margin-bottom: 20px;
            position: relative;
        }
        .comment .fa-times {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #E53935; /* Red color */
            cursor: pointer;
            font-size: 1.5em;
        }
        .comment .fa-times:hover {
            color: #B71C1C; /* Darker red color */
        }
        .inputLabel {
            font-size: 1.2em;
            margin-bottom: 10px;
            display: block;
            color: #4CAF50;
        }
        .special {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            color: #555;
            margin-bottom: 20px;
        }
        .btn-primary, .btn-danger {
            font-size: 1.2em;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            border: none;
            cursor: pointer;
            display: inline-block;
        }
        .btn-primary {
            background-color: #4CAF50;
            border: 2px solid #388E3C;
        }
        .btn-primary:hover {
            background-color: #388E3C;
            border: 2px solid #2C6B2F;
        }
        .btn-danger {
            background-color: #E53935;
            border: 2px solid #C62828;
        }
        .btn-danger:hover {
            background-color: #C62828;
            border: 2px solid #B71C1C;
        }
        .grand {
            background: #e8f5e9; /* Light green background */
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
            border: 1px solid #ddd; /* Light grey border */
        }
        .grand p {
            font-size: 1.5em;
            color: #333;
            margin: 0;
        }
        .grand h3 {
            font-size: 2.5em;
            color: #4CAF50;
            margin-top: 10px;
        }
        .printableArea {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }
        .printableArea div {
            flex: 1;
        }
        .printableArea p {
            border: 1px solid #ddd;
            margin: 0;
            padding: 15px;
            font-size: 1.2em;
            background: #ffffff;
        }
        .printableArea b {
            font-size: 1.5em;
            font-weight: bold;
            margin-right: 10px;
        }
        .printableArea span {
            display: block;
        }
        @media print {
            body * {
                visibility: hidden;
            }
            .printableArea, .printableArea * {
                visibility: visible;
            }
            .printableArea {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                background: #fff;
                border: none;
                padding: 20px;
            }
            .header, .banner-3, .btn-primary, .btn-danger, .comments-form, .fa-times {
                display: none;
            }
            .printableArea p {
                border: 1px solid #000;
            }
            .printableArea b {
                font-size: 1.8em;
            }
            .printableArea span {
                font-size: 1.5em;
            }
            .grand {
                border: 1px solid #000;
                background: #fff;
            }
            .grand p, .grand h3 {
                margin: 0;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="banner-3">
        <div class="container">
            <h1 class="wow zoomIn animated" data-wow-delay=".5s">NCS Package Details</h1>
        </div>
    </div>
    <div class="container">
        <div class="box-container">
            <?php if ($error) { ?>
                <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
                <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>

            <?php
            $pid = intval($_GET['pkgid']);
            $sql = "SELECT * FROM tbltenderpackages WHERE PackageId = :pid";
            $query = $dbh->prepare($sql);
            $query->bindParam(':pid', $pid, PDO::PARAM_INT);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);

            if ($query->rowCount() > 0) {
                foreach ($results as $result) {
            ?>
                <div class="selectroom_top">
                    <h2><?php echo htmlentities($result->PackageNo); ?></h2>
                    <div class="printableArea">
                        <div>
                            <p><b>Specification Forwarding Date:</b> <span><?php echo htmlentities($result->SpecificationForwardingDate); ?></span></p>
                            <p><b>Purchase Method Type:</b> <span><?php echo htmlentities($result->PurchaseMethodType); ?></span></p>
                            <p><b>Estimated Expenditure:</b> <span><?php echo htmlentities($result->EstimatedExpenditure); ?></span></p>
                        </div>
                        <div>
                            <p><b>Responsible Person:</b> <span><?php echo htmlentities($result->ResponsiblePerson); ?></span></p>
                            <p><b>Consultant:</b> <span><?php echo htmlentities($result->Consultant); ?></span></p>
                            <p><b>Details:</b> <span><?php echo htmlentities($result->Details); ?></span></p>
                        </div>
                    </div>
                    <div class="grand">
                        <p>Grand Total (In Lakhs)</p>
                        <h3><?php echo htmlentities($result->EstimatedExpenditure); ?></h3>
                    </div>
                </div>
                <div class="details-box">
                    <h3>পর্যালোচনা</h3>
                    <?php
                    $sqlDetails = "SELECT Detail, DetailPart2 FROM tblpackagedetails WHERE PackageId = :pid";
                    $queryDetails = $dbh->prepare($sqlDetails);
                    $queryDetails->bindParam(':pid', $pid, PDO::PARAM_INT);
                    $queryDetails->execute();
                    $details = $queryDetails->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($details as $detail) {
                        echo '<div class="detail-row">';
                        echo '<div class="detail-item"><strong>Status:</strong> ' . htmlentities($detail['Detail']) . '</div>';
                        echo '<div class="detail-item"><strong>Date:</strong> ' . htmlentities($detail['DetailPart2']) . '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>

                <!-- Display Comments -->
                <div class="comments">
                    <h2>মন্তব্য</h2>
                    <?php if (count($comments) > 0) { ?>
                        <?php foreach ($comments as $comment) { ?>
                            <div class="comment">
                                <p><strong>Comment:</strong> <?php echo htmlentities($comment->Comment); ?></p>
                                <a href="?pkgid=<?php echo $pid; ?>&delete=<?php echo htmlentities($comment->CommentId); ?>" onclick="return confirm('Are you sure you want to delete this comment?');" class="fa fa-times"></a>
                            </div>
                        <?php } ?>
                    <?php } else { ?>
                        <p>এখনও কোনো মন্তব্য করা হয়নি।</p>
                    <?php } ?>
                </div>
            <?php }} ?>
        </div>

        <!-- Comment Form -->
        <div class="box-container">
            <div class="comments-form">
                <form name="book" method="post">
                    <div class="selectroom_top">
                        <label class="inputLabel">Add your Comments</label>
                        <input class="special" type="text" name="comment" value="<?php echo isset($_POST['comment']) ? htmlentities($_POST['comment']) : ''; ?>" required="">
                        <?php if ($_SESSION['login']) { ?>
                            <button type="submit" name="submit2" class="btn-primary">Save</button>
                        <?php } else { ?>
                            <a href="#" data-toggle="modal" data-target="#myModal4" class="btn-primary">Save</a>
                        <?php } ?>
                    </div>
                </form>
            </div>
        </div>

        <a href="print.php?pkgid=<?php echo $pid; ?>" class="btn-primary" target="_blank">Print Package Details</a>

    </div>

    <?php include('includes/signup.php'); ?>
    <?php include('includes/signin.php'); ?>
    <?php include('includes/write-us.php'); ?>

    <script>
        function printPage() {
            window.print();
        }
    </script>
</body>
</html>
