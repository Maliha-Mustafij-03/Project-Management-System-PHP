<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

$sql = "SELECT * FROM view_emp_training ";
    $query = $dbh->prepare($sql);
    $query->execute();
$data = $query->fetchAll(PDO::FETCH_ASSOC);



?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    
    <link rel="stylesheet" type="text/css" href="datatable/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/dataTables.bootstrap.min.css" />

    <style>
        /* Global Styles */
        
        h1 {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            background-color: #007bff;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            position: relative;
            top: 0;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Training Module</h1>
        <!-- <a href="http://172.16.243.112/asset/auth/login" class="pull-right blinking-link package-overview">Asset Module</a> -->

        <!-- Assets Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="userTable">
            <thead>
              <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Type</th>
                <th>Title</th>
                <th>Duration</th>
                <th>Venue</th>
              </tr>
            </thead>
            <tbody>
              <?php if($data): ?>
                <?php foreach($data as $key => $value): 
                    $bday = new DateTime($value['duration_from']); 
                    $today = new Datetime($value['duration_to']);
                    $diff = $today->diff($bday);
                ?>
                <tr>
                  <td><?= $key+1 ?></td>
                  <td><?= $value['emp_name'] ?></td>
                  <td><?= $value['type_name'] ?></td>
                  <td><?= $value['title_name'] ?></td>
                  <td><i><?= $diff->d.' days' ?></i></td>
                  <td><?= $value['venue_name'] ?></td>
                </tr>
                <?php endforeach ?>
                <?php endif; ?>
              </tbody>
            </table>
        </div>
    </div>
</body>
    <script src="datatable/js/dataTables.bootstrap.min.js"></script>
    <script src="datatable/js/jquery.dataTables.min.js"></script>
    <script src="datatable/js/dataTables.buttons.min.js"></script>
    <script src="datatable/js/jszip.min.js"></script>
    <script src="datatable/js/buttons.html5.min.js"></script>
    <script src="datatable/js/buttons.print.min.js"></script>
</html>

<script type="text/javascript">

$(document).ready(function(){

    $('#userTable').DataTable({
        dom: 'lBfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'print'
        ]
    });

});



</script>
