<?php
require_once "db.php";

// Fetch events from the database
$query = "SELECT * FROM tbl_events ORDER BY start ASC";
$result = mysqli_query($conn, $query);

$events = [];
while ($row = mysqli_fetch_assoc($result)) {
    $events[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'start' => $row['start'],
        'end' => $row['end'],
        'color' => $row['color']  // Include the color in the response
    ];
}

// Return events as JSON
echo json_encode($events);
?>
