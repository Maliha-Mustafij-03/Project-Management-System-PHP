
<?php 
session_start(); 
error_reporting(0); 
include('includes/config.php'); 
include('includes/header.php'); 

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {     
    header('location:index.php');     
    exit; 
}
// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';  // Change as needed
$password = '';  // Change as needed

$conn = new mysqli($host, $username, $password, $dbname);

// Initialize search term
$searchTerm = '';

// Check if the search form is submitted
if (isset($_POST['search'])) {
    $searchTerm = $_POST['search']; // Capture the search term entered by the user

    // SQL query with UNION to search across multiple tables: main category, subcategory, and items
    $query = "(
                SELECT id, category_name AS name, total_count, 'main' AS source FROM snid_card_main_data
                WHERE category_name LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )
              UNION
              (
                SELECT id, subcategory_name AS name, subcategory_total AS total_count, 'subcategory' AS source FROM snid_card_subcategory_data
                WHERE subcategory_name LIKE '%$searchTerm%' 
                OR description LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )
              UNION
              (
                SELECT id, item_name AS name, item_count AS total_count, 'item' AS source FROM snid_card_item_data
                WHERE item_name LIKE '%$searchTerm%' 
                OR id LIKE '%$searchTerm%'
              )";
} else {
    // Default query to fetch all data if no search term is provided
    $query = "SELECT id, category_name AS name, total_count, 'main' AS source FROM snid_card_main_data";
}

// Fetch data based on the query
$result = $conn->query($query);

// Delete record
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Delete related items first (cascade delete)
    $conn->query("DELETE FROM snid_card_item_data WHERE subcategory_id IN (SELECT id FROM snid_card_subcategory_data WHERE main_category_id = $id)");

    // Delete related subcategories
    $conn->query("DELETE FROM snid_card_subcategory_data WHERE main_category_id = $id");

    // Delete the main category
    $conn->query("DELETE FROM snid_card_main_data WHERE id = $id");

    // Redirect after deletion
    header("Location: managestat.php");  // Redirect to the same page or another page after deletion
    exit();  // Ensure no further code is executed
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>স্মার্ট কার্ড তথ্য পরিচালনা</title>
    
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        <style>
        /* Remove sidebar and ensure main content takes full width */
        .page-container {
            display: flex;
            flex-direction: column; /* Stack the content vertically */
            height: 100vh; /* Full height of the viewport */
        }

        /* Main content area takes full width */
        .main-content {
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto;
            margin-left: 0; /* Remove left margin */
        }

        .mother-grid-inner {
            margin: 0 auto;
            width: 100%;
        }

        /* Scrollbar customization */
        .main-content {
            height: calc(100vh - 60px); /* Deduct header height */
            overflow-y: auto;
        }

        /* Ensuring table text is large enough and well formatted */
        body {
            font-size: 18px;
        }

        .table th, .table td {
            font-size: 16px;
            text-align: center;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .table td {
            text-align: left;
        }

        .search-bar {
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .search-bar input[type="text"] {
            padding: 12px;
            font-size: 18px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
        }

        .alert {
            text-align: center;
            font-size: 18px;
        }

        h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
        }
    </style>
    </style>
</head>
<body>

<div class="container mt-5">
    <h2>স্মার্ট কার্ড তথ্য পরিচালনা</h2>
    
    <!-- Search Bar -->
    <form method="POST" action="" class="form-inline mb-3 search-bar">
        <input type="text" class="form-control" name="search" placeholder="শ্রেণী, সাব ক্যাটাগরি, বা আইটেম দ্বারা অনুসন্ধান করুন" value="<?= htmlspecialchars($searchTerm); ?>" required>
        <button type="submit" class="btn btn-primary ml-2">অনুসন্ধান</button>
    </form>

    <!-- Main Category Table -->
    <div class="scrollable-table">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ক্রম নং</th>
                    <th>নাম</th>
                    <th>মোট সংখ্যা</th>
                    <th>অ্যাকশন</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0) : ?>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= $row['total_count']; ?></td>
                            <td>
                                <a href="individualstatefront.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">দেখুন</a>
                            </td>
                        </tr>

                        <!-- Fetch Subcategories for each Main Category -->
                        <?php if ($row['source'] === 'main') : ?>
                            <?php
                            $mainCategoryId = $row['id'];
                            $subquery = "SELECT * FROM snid_card_subcategory_data WHERE main_category_id = $mainCategoryId";
                            $subresult = $conn->query($subquery);
                            while ($subcategory = $subresult->fetch_assoc()) :
                            ?>
                                <tr class="table-secondary">
                                    <td colspan="4">
                                        <strong>সাব ক্যাটাগরি নাম:</strong> <?= htmlspecialchars($subcategory['subcategory_name']); ?><br>
                                        <strong>বিশদ বিবরনী:</strong> <?= htmlspecialchars($subcategory['description']); ?><br>
                                        <strong>মোট সংখ্যা:</strong> <?= $subcategory['subcategory_total']; ?>
                                    </td>
                                </tr>

                                <!-- Fetch Items for each Subcategory -->
                                <?php
                                $subcategoryId = $subcategory['id'];
                                $itemquery = "SELECT * FROM snid_card_item_data WHERE subcategory_id = $subcategoryId";
                                $itemresult = $conn->query($itemquery);
                                ?>

                                <tr class="table-light">
                                    <td colspan="4">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>আইটেম নাম</th>
                                                    <th>আইটেম সংখ্যা</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while ($item = $itemresult->fetch_assoc()) : ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($item['item_name']); ?></td>
                                                        <td><?= $item['item_count']; ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4" class="text-center">কোনও রেকর্ড পাওয়া যায়নি।</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>

<?php $conn->close(); ?>
