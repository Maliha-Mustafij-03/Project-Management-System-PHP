<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Initialize search query variable
$search = '';
if (isset($_POST['search'])) {
    $search = trim($_POST['search']);
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>NCS | Package List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            font-size: 16px;
            color: #333;
        }
        .banner-3 {
            background: #007bff;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .banner-3 h1 {
            font-size: 36px;
            margin: 0;
        }
        .rooms {
            padding: 40px 0;
            background: #f9f9f9;
        }
        .rooms h3 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
            color: #007bff;
        }
        .search-form {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-form input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 300px;
        }
        .search-form input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        .search-form input[type="submit"]:hover {
            background: #0056b3;
        }
        .print-button {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        .print-button:hover {
            background: #0056b3;
        }
        .package-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .package-table th, .package-table td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd; /* Border for normal view */
        }
        .package-table th {
            background-color: #f4f4f4;
            font-weight: bold;
            color: #007bff;
        }
        .package-table tr:hover {
            background-color: #f1f1f1;
        }
        .package-table a.view {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background: #007bff;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .package-table a.view:hover {
            background: #0056b3;
        }
        .package-table .price {
            color: #007bff;
        }
        .details-column {
            display: table-cell; /* Ensure 'Details' column is visible by default */
        }
        .clearfix {
            clear: both;
        }
        @media (max-width: 768px) {
            .package-table {
                font-size: 14px;
            }
        }
        @media (max-width: 480px) {
            .package-table {
                font-size: 12px;
            }
        }
        @media print {
            /* Hide everything except the table content */
            body * {
                visibility: hidden;
            }
            .printable, .printable * {
                visibility: visible;
            }
            .printable {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%; /* Ensure full-width on print */
            }
            .package-table {
                border-collapse: collapse; /* Ensure border collapse */
                width: 100%; /* Full width for printing */
            }
            .package-table th, .package-table td {
                border: 1px solid black; /* Border for all cells */
                padding: 8px; /* Padding adjustment for print */
            }
            .package-table .details-column {
                display: none; /* Hide the 'Details' column on print */
            }
        }
    </style>
    <script>
        function printPage() {
            window.print();
        }
    </script>
</head>
<body>
    <?php include('includes/header.php');?>

    <!--- banner ---->
    <div class="banner-3">
        <div class="container">
           
        </div>
    </div>
    <!--- /banner ---->
    
    <!--- rooms ---->
    <div class="rooms">
        <div class="container">
            <h3>প্যাকেজ লিষ্ট</h3>
            <!-- Search Form -->
            <div class="search-form">
                <form method="POST" action="">
                    <input type="text" name="search" placeholder="প্যাকেজ খুজুন..." value="<?php echo htmlspecialchars($search); ?>">
                    <input type="submit" value="সার্চ">
                    <button type="button" class="print-button" onclick="printPage()">প্রিন্ট</button>
                </form>
            </div>

            <!-- Printable Section -->
            <div class="printable">
                <table class="package-table">
                    <thead>
                        <tr>
                            <th>প্যাকেজ নম্বর</th>
                            <th>ডিপিপি অনুযায়ী ক্র্রয়ের জন্য প্যাকেজ বর্ননা</th>
                            <th>চুক্তির অগ্রগতির তারিখ</th>
                            <th>ক্রয় পদ্ধতি ও ধরণ</th>
                            <th>প্রাক্কলিত ব্যয় (লক্ষ টাকা)</th>
                            <th>ক্রয় অনুমোদনকারী কর্তৃপক্ষ</th>
                            <th>দরপত্র আহবান এর তারিখ</th>
                            <th>চলমান/সম্পন্ন/আসন্ন</th>

                            <th class="details-column">বিস্তারিত</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql = "SELECT PackageId, PackageNo, Details, SpecificationForwardingDate, PurchaseMethodType, EstimatedExpenditure, ResponsiblePerson, Consultant, liveorclose FROM tbltenderpackages";
                        
                        // Modify query if search is provided
                        if (!empty($search)) {
                            $sql .= " WHERE (PackageNo LIKE :search 
              OR Details LIKE :search 
              OR PackageId LIKE :search
              OR SpecificationForwardingDate LIKE :search
              OR PurchaseMethodType LIKE :search
              OR EstimatedExpenditure LIKE :search
              OR ResponsiblePerson LIKE :search
              OR Consultant LIKE :search
             ) AND liveorclose = 'আসন্ন'";
                        } else {
                            $sql .= " WHERE liveorclose = 'আসন্ন'";
                        }
                        
                        $query = $dbh->prepare($sql);
                        
                        // Bind the search parameter if needed
                        if (!empty($search)) {
                            $query->bindValue(':search', '%' . $search . '%');
                        }
                        
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                        
                        if ($query->rowCount() > 0) {
                            foreach ($results as $result) {
                        ?>
                        <tr>
                            <td><?php echo htmlentities($result->PackageNo); ?></td>
                            <td class="details"><?php echo htmlentities($result->Details); ?></td>
                            <td><?php echo htmlentities($result->SpecificationForwardingDate); ?></td>
                            <td><?php echo htmlentities($result->PurchaseMethodType); ?></td>
                            <td class="price">(Lakh)<?php echo htmlentities($result->EstimatedExpenditure); ?></td>
                            <td><?php echo htmlentities($result->ResponsiblePerson); ?></td>
                            <td><?php echo htmlentities($result->Consultant); ?></td>
                            <td><?php echo htmlentities($result->liveorclose); ?></td>
                            
                            <td class="details-column"><a href="print.php?pkgid=<?php echo htmlentities($result->PackageId); ?>" class="view">বিস্তারিত</a></td>
                        </tr>
                        <?php 
                            }
                        } else {
                            echo '<tr><td colspan="8">No packages found matching your criteria.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--- /rooms ---->
    <!-- footer-top -->
   
    <!-- signup -->
    <?php include('includes/signup.php');?>            
    <!-- signin -->
    <?php include('includes/signin.php');?>            
    <!-- write us -->
    <?php include('includes/write-us.php');?>

</body>
</html>
