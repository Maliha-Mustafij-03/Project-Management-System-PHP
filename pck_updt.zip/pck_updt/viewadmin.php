<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

$sql = "SELECT * FROM emp_profile_list_view p LEFT JOIN emp_last_education_list_view e ON e.exam_emp_id = p.emp_id";
    $query = $dbh->prepare($sql);
    $query->execute();
$data = $query->fetchAll(PDO::FETCH_ASSOC);



?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    
    <link rel="stylesheet" type="text/css" href="datatable/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/css/dataTables.bootstrap.min.css" />

    <style>
        /* Global Styles */
        
        h1 {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            background-color: #007bff;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            position: relative;
            top: 0;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Management</h1>
        <!-- <a href="http://172.16.243.112/asset/auth/login" class="pull-right blinking-link package-overview">Asset Module</a> -->

        <!-- Assets Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="userTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Image</th>
                <th>Name</th>
                <th>Joning Date</th>
                <th>DOB</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Blood Group</th>
                <th>Educational Qualification</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if($data): ?>
                <?php foreach($data as $key => $value): ?>
                  <tr>
                        <td><?= $key+1; ?></td>
                        <td>
                            <?php if($value['emp_photo'] != NULL){ ?>
                            <img src="../hrm/uploads/profile_images/<?= $value['emp_photo'] ?>" alt="Image" height="60" width="45" class="img-thumbnail">
                          <?php }else{ ?>
                            <img src="../hrm/uploads/profile_images/no_image.jpg" alt="Image" height="60" width="45" class="img-thumbnail">
                          <?php } ?>
                        </td>
                        <td><?= $value['emp_name'] ?></td>
                        <td><?= $value['emp_joining_date'] ?></td>
                        <td><?= $value['emp_dob'] ?></td>
                        <td><?=$value['section_name'] ?></td>
                        <td><?= $value['desig_name'] ?></td>
                        <td><?= $value['emp_bgroup'] ?></td>
                        <td><?= $value['educational_qualification'] ?></td>
                        <td><a href="employee_view.php?id=<?= $value['emp_id'] ?>" class="btn btn-default" title='Details' data-toggle="tooltip" target="_blank"><i class="fa fa-eye"></i></a></td>
                    </tr>
                  <?php endforeach ?>
                <?php endif; ?>
              </tbody>
            </table>
        </div>
    </div>
</body>
    <script src="datatable/js/dataTables.bootstrap.min.js"></script>
    <script src="datatable/js/jquery.dataTables.min.js"></script>
    <script src="datatable/js/dataTables.buttons.min.js"></script>
    <script src="datatable/js/jszip.min.js"></script>
    <script src="datatable/js/buttons.html5.min.js"></script>
    <script src="datatable/js/buttons.print.min.js"></script>
</html>

<script type="text/javascript">

$(document).ready(function(){

    $('#userTable').DataTable({
        dom: 'lBfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'print'
        ]
    });

});



</script>
