<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'tms';
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the 'id' parameter exists in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch main category data
    $result = $conn->query("SELECT * FROM snid_card_main_data WHERE id = $id");
    if ($result->num_rows > 0) {
        $mainCategory = $result->fetch_assoc();
    } else {
        die("Main category not found.");
    }

    // Fetch subcategories for the main category
    $subcategories = $conn->query("SELECT * FROM snid_card_subcategory_data WHERE main_category_id = $id");

    // Fetch items for each subcategory and store them
    $subcategory_items = [];  // Initialize as an empty array
    $subcategory_names = [];
    while ($subcategory = $subcategories->fetch_assoc()) {
        $subcategory_id = $subcategory['id'];
        $subcategory_names[$subcategory_id] = $subcategory['subcategory_name'];
        $items_result = $conn->query("SELECT * FROM snid_card_item_data WHERE subcategory_id = $subcategory_id");

        if ($items_result) {
            $subcategory_items[$subcategory_id] = $items_result->fetch_all(MYSQLI_ASSOC);
        } else {
            $subcategory_items[$subcategory_id] = [];
        }
    }
} else {
    die("Invalid request: Missing category ID.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>বিস্তারিত বিবরণ এবং গ্রাফ</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            margin-top: 0px;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }

        h2, h3 {
            color: #2c3e50;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: left;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 12px 25px;
            background-color: #e74c3c;
            border: none;
            border-radius: 30px;
            color: #fff;
            cursor: pointer;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background-color: #c0392b;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .table th, .table td {
            font-size: 16px;
            font-weight: bold;
            text-align: left;
            vertical-align: middle;
            padding: 12px 15px;
        }

        .table th {
            background-color: #2980b9;
            color: #fff;
            text-transform: uppercase;
        }
        .hidden-element {
    display: none;
}
<?php if ($condition_to_hide) { ?>
    <style>
        .element-to-hide { display: none; }
    </style>
<?php } ?>


        .table tbody tr {
            background-color: #fff;
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background-color: #ecf0f1;
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .table-bordered {
            border: 1px solid #ddd;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .card {
            background: linear-gradient(135deg, #3498db, #2ecc71);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 15px;
            color: #fff;
        }

        @media print {
            body {
                font-size: 12px;
            }
            header, .btn-custom, h2 {
                display: none;
            }
            .container {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
            }
            .table {
                width: 45%;
                margin-right: 30px;
            }
            #itemChart {
                width: 50%;
                height: 400px !important;
            }
        }

        .btn-custom {
            margin-bottom: 30px;
        }

        .table td {
            font-weight: bold;
            color: #000;
        }

        #itemChart {
            width: 70% !important;
            height: 350px !important;
            margin: 0 auto;
            display: block;
        }
    </style>
</head>
<body>

<header>
    <!-- Include your header content if necessary -->
</header>

<div class="container">
    <div style="width: 100%; text-align: center;">
        <h2>বিস্তারিত বিবরণ এবং গ্রাফ</h2>
        
        
        <div class="text-center">
            <button class="btn btn-primary btn-custom" onclick="printTable()">প্রিন্ট করুন</button>
        </div>

        <!-- Display main category details -->
        <div class="card">
            <br>
            <h3>মূল শ্রেণী: <?= isset($mainCategory['category_name']) ? htmlspecialchars($mainCategory['category_name']) : 'N/A'; ?></h3>
        </div>

        <!-- Display subcategories and items in table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>সাব ক্যাটাগরি নাম</th>
                    <th>বিবরণ</th>
                    <th>মোট সংখ্যা</th>
                    <th>আইটেমসমূহ</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($subcategory_items)): ?>
                    <?php foreach ($subcategory_items as $subcategory_id => $items): ?>
                        <?php
                            // Fetch subcategory details
                            $subcategory_query = $conn->query("SELECT * FROM snid_card_subcategory_data WHERE id = $subcategory_id");
                            $subcategory = $subcategory_query->fetch_assoc();
                        ?>
                        <tr>
                            <td><?= isset($subcategory['subcategory_name']) ? htmlspecialchars($subcategory['subcategory_name']) : 'N/A'; ?></td>
                            <td><?= isset($subcategory['description']) ? htmlspecialchars($subcategory['description']) : 'N/A'; ?></td>
                            <td><?= isset($subcategory['subcategory_total']) ? $subcategory['subcategory_total'] : 'N/A'; ?></td>
                            <td>
                                <ul>
                                    <?php foreach ($items as $item): ?>
                                        <li><?= isset($item['item_name']) ? htmlspecialchars($item['item_name']) : 'N/A'; ?> (<?= isset($item['item_count']) ? htmlspecialchars($item['item_count']) : '0'; ?>)</li>
                                    <?php endforeach; ?>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">No subcategories found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Graph for top 10 individual items as Pie Chart -->
    <div style="width: 100%; margin-top: 30px; text-align: center;">
        <canvas id="itemChart"></canvas>
        <script>
            var ctx = document.getElementById('itemChart').getContext('2d');
            var itemChart = new Chart(ctx, {
                type: 'pie', // Change chart type to pie
                data: {
                    labels: <?php
                        // Limit to top 10 items or fewer based on item_count
                        $all_items = [];
                        foreach ($subcategory_items as $subcategory_id => $items) {
                            foreach ($items as $item) {
                                $all_items[] = [
                                    'name' => $item['item_name'] . " (" . $subcategory_names[$subcategory_id] . ")",
                                    'count' => $item['item_count']
                                ];
                            }
                        }

                        // Sort items by count in descending order
                        usort($all_items, function($a, $b) {
                            return $b['count'] - $a['count'];
                        });

                        // Get the top 10 items
                        $top_items = array_slice($all_items, 0, 10);
                        $item_labels = array_map(function($item) { return $item['name']; }, $top_items);
                        $item_counts = array_map(function($item) { return $item['count']; }, $top_items);

                        echo json_encode($item_labels);
                    ?>,
                    datasets: [{
                        label: 'আইটেম সংখ্যা',
                        data: <?php echo json_encode($item_counts); ?>,
                        backgroundColor: ['#3498db', '#2ecc71', '#f1c40f', '#e74c3c', '#9b59b6', '#34495e', '#16a085', '#f39c12', '#1abc9c', '#d35400'], // Colors for each segment
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return tooltipItem.label + ': ' + tooltipItem.raw + ' আইটেম';
                                }
                            }
                        }
                    }
                }
            });
        </script>

<script>
    function printTable() {
        var printWindow = window.open('', '', 'height=700,width=1000');
        printWindow.document.write('<html><head><title>Smartcards Print</title>');
        printWindow.document.write('<style>');
        printWindow.document.write('body { font-family: Arial, sans-serif; font-size: 14px; text-align: center; }');
        printWindow.document.write('table { width: 100%; border-collapse: collapse; margin-top: 20px; }');
        printWindow.document.write('th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }');
        printWindow.document.write('th { background-color: #f4f4f4; }');
        printWindow.document.write('canvas { display: block; margin: 20px auto; max-width: 500px; }');
        printWindow.document.write('</style></head><body>');
        printWindow.document.write('<img src="logo.png" alt="ECS Logo" style="display:block; margin:auto; width:100px;"/>');
        printWindow.document.write('<h4>স্মার্টকার্ডের সামগ্রিক তথ্যাদি</h4>');
        printWindow.document.write(document.querySelector('.table').outerHTML);
        var canvas = document.getElementById('itemChart');
        var image = canvas.toDataURL();
        printWindow.document.write('<img src="' + image + '"/>');
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
</script>

    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>
