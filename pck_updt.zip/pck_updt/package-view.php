<?php
session_start();
include('includes/config.php');

// Initialize error and message variables
$error = '';
$msg = '';

// Initialize search variable
$search = '';

// Handle search functionality
if (isset($_POST['search'])) {
    $search = trim($_POST['search']);
}

// Code for deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    $packageId = intval($_GET['id']);
    try {
        $sql = "DELETE FROM package_overview WHERE id=:id";
        $query = $dbh->prepare($sql);
        $query->bindParam(':id', $packageId, PDO::PARAM_INT);
        $query->execute();

        if ($query->rowCount()) {
            $msg = "Package Deleted Successfully";
        } else {
            $error = "Something went wrong. Please try again";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>NCSMS Package | Manage Packages</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <style>
        /* Custom styles */
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            box-shadow: 0 1px 1px rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            box-shadow: 0 1px 1px rgba(0,0,0,.1);
        }
        .container {
            margin-top: 20px;
        }
        table.table-bordered {
            margin: 20px 0;
            border-collapse: collapse;
            width: 100%;
        }
        table.table-bordered th, table.table-bordered td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table.table-bordered thead th {
            background-color: #007bff;
            color: white;
            border-bottom: 2px solid #ddd;
        }
        table.table-bordered tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table.table-bordered tbody tr:hover {
            background-color: #e2e2e2;
        }
        .search-form {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-form input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 300px;
        }
        .search-form input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        .search-form input[type="submit"]:hover {
            background: #0056b3;
        }
        .stage-marked {
            background-color: #dff0d8;
        }
        .stage-upcoming {
            background-color: #d4edda; /* Green */
        }
        .stage-passed {
            background-color: #f2dede; /* Red */
        }
        @media print {
            body * {
                visibility: hidden;
            }
            .print-area, .print-area * {
                visibility: visible;
            }
            .print-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
            }
        }
    </style>
    <script>
        function printPage() {
            window.print();
        }
    </script>
</head> 
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php include('includes/header.php');?>
                <div class="clearfix"> </div>  
            </div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="main.php">হোম</a><i class="fa fa-angle-right"></i>ম্যানেজ প্যাকেজ</li>
            </ol>
            <div class="container">
                <h2>স্পেসিফিকেশন কমিটি দ্বারা তৈরী স্পেসিফিকেশন, যাচাই কমিটিতে প্রেরণের তারিখ এবং ক্রয় (ম্যানেজ ওভারভিউ):</h2>
                
                <!-- Search Form -->
                <div class="search-form">
                    <form method="POST" action="">
                        <input type="text" name="search" placeholder="প্যাকেজ খুজুন..." value="<?php echo htmlspecialchars($search); ?>">
                        <input type="submit" value="সার্চ">
                    </form>
                </div>
                
                <?php if ($error) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
                <?php } else if ($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
                <?php } ?>

                <!-- Print Button -->
                <div class="text-center">
                    <button onclick="printPage()">প্রিন্ট</button>
                </div>

                <div class="print-area">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>প্যাকেজ নং</th>
                                <th>বিস্তারিত</th>
                                <th>ক্রয়পদ্ধতি</th>
                                <th>স্পেসিফিকেশনের লক্ষ্যমাত্রা</th>
                                <th>স্পেসিফিকেশন চূড়ান্তকরণ প্রাপ্তির তারিখ</th>
                                <th>স্পেসিফিকেশন প্রকিউরমেন্টে পাঠানোর তারিখ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            try {
                                $sql = "SELECT * FROM package_overview";
                                if (!empty($search)) {
                                    $sql .= " WHERE package_no LIKE :search 
   OR details LIKE :search 
   OR current_condition LIKE :search 
   OR specification_target LIKE :search
   OR specification_date_transmission_verification LIKE :search 
   OR specification_date_dispatch_procurement LIKE :search
";
                                }
                                $query = $dbh->prepare($sql);
                                if (!empty($search)) {
                                    $query->bindValue(':search', '%' . $search . '%');
                                }
                                $query->execute();
                                $results = $query->fetchAll(PDO::FETCH_OBJ);
                                $cnt = 1;
                                foreach ($results as $result) {
                                    // Determine the status of the dates
                                    $currentDate = date('Y-m-d'); // Get today's date
                                    $specVerificationDate = $result->specification_date_transmission_verification;
                                    $specProcurementDate = $result->specification_date_dispatch_procurement;

                                    // Status for Verification Date
                                    if ($specVerificationDate < $currentDate) {
                                        $verificationStatus = 'তারিখ সম্পন্ন';
                                        $verificationClass = 'stage-passed'; // Red for closed
                                    } elseif ($specVerificationDate == $currentDate) {
                                        $verificationStatus = 'Current Stage';
                                        $verificationClass = 'stage-marked'; // Neutral
                                    } else {
                                        $verificationStatus = 'তারিখ আসন্ন';
                                        $verificationClass = 'stage-upcoming'; // Green for upcoming
                                    }

                                    // Status for Procurement Date
                                    if ($specProcurementDate < $currentDate) {
                                        $procurementStatus = 'তারিখ সম্পন্ন';
                                        $procurementClass = 'stage-passed'; // Red for closed
                                    } elseif ($specProcurementDate == $currentDate) {
                                        $procurementStatus = 'Current Stage';
                                        $procurementClass = 'stage-marked'; // Neutral
                                    } else {
                                        $procurementStatus = 'তারিখ আসন্ন';
                                        $procurementClass = 'stage-upcoming'; // Green for upcoming
                                    }
                            ?>
                            <tr>
                                <td><?php echo htmlentities($cnt); ?></td>
                                <td><?php echo htmlentities($result->package_no); ?></td>
                                <td><?php echo htmlentities($result->details); ?></td>
                                <td><?php echo htmlentities($result->current_condition); ?></td>
                                <td><?php echo htmlentities($result->specification_target); ?></td>
                                <td class="<?php echo $verificationClass; ?>"><?php echo htmlentities($specVerificationDate); ?> - <?php echo $verificationStatus; ?></td>
                                <td class="<?php echo $procurementClass; ?>"><?php echo htmlentities($specProcurementDate); ?> - <?php echo $procurementStatus; ?></td>
                            </tr>
                            <?php 
                                    $cnt++; 
                                }
                            } catch (PDOException $e) {
                                echo '<tr><td colspan="6">Error: ' . $e->getMessage() . '</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <script>
            $(document).ready(function() {
                var navOffset = $(".header-main").offset().top;
                $(window).scroll(function() {
                    var scrollPos = $(window).scrollTop(); 
                    if(scrollPos >= navOffset) {
                        $(".header-main").addClass("fixed");
                    } else {
                        $(".header-main").removeClass("fixed");
                    }
                });
            });
            </script>
            <div class="inner-block"></div>
           
        </div>
        <div class="clearfix"></div>     
    </div>
    <script>
    var toggle = true;
    $(".sidebar-icon").click(function() {                
      if (toggle) {
        $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
        $("#menu span").css({"position":"absolute"}); 
      } else {
        $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
        setTimeout(function() {
          $("#menu span").css({"position":"relative"}); 
        }, 400);
      }
      toggle = !toggle;
    });
    </script>
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 
