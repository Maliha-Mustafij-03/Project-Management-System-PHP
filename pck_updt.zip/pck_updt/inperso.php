<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/sidebarmenu.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {
    header('location:index.php');
    exit;
}

// Fetch data for the specific record
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch parent record
    $sql = "SELECT * FROM smart_nid_print_distribution WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    $parentRecord = $query->fetch(PDO::FETCH_ASSOC);

    // Fetch associated subcategories
    $sqlSubCategory = "SELECT * FROM smart_nid_print_details WHERE parent_id = :parent_id";
    $querySubCategory = $dbh->prepare($sqlSubCategory);
    $querySubCategory->bindParam(':parent_id', $id, PDO::PARAM_INT);
    $querySubCategory->execute();
    $subCategories = $querySubCategory->fetchAll(PDO::FETCH_ASSOC);

    // Fetch associated counts and additional info
    $sqlMoreDetails = "SELECT * FROM smart_nid_print_more_details WHERE parent_id = :parent_id";
    $queryMoreDetails = $dbh->prepare($sqlMoreDetails);
    $queryMoreDetails->bindParam(':parent_id', $id, PDO::PARAM_INT);
    $queryMoreDetails->execute();
    $moreDetails = $queryMoreDetails->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>ডিটেলস - স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</title>
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/font-awesome.css" rel="stylesheet"> 
    <script src="js/jquery-2.1.4.min.js"></script>
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <script src="js/bootstrap.min.js"></script>

    <style>
        /* Remove extra space above the breadcrumb */
        body, .page-container {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .mother-grid-inner {
            padding-bottom: 100px; /* Allow some space for footer */
        }

        .page-container {
            max-height: 100vh;
            overflow-y: auto;
        }

        .form-control1 {
            font-size: 16px;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .detail-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .detail-row input {
            margin-right: 10px;
        }

        .btn-container {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .btn-container button {
            margin-right: 10px;
        }

        /* Make the body scrollable */
        body {
            overflow-y: auto;
        }

        /* Header style */
        .header-main.fixed {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .grid-form1 {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .breadcrumb {
            background-color: #f1f1f1;
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .breadcrumb-item a {
            color: #007bff;
        }

        .breadcrumb-item a:hover {
            text-decoration: underline;
        }

        .form-control[readonly], .form-control[disabled] {
            background-color: #e9ecef;
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .header-main {
            background-color: #003366;
            color: white;
            padding: 10px;
            font-size: 18px;
            font-weight: bold;
        }

        .grid-form h3 {
            color: #003366;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .succWrap {
            padding: 10px;
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        /* Disable Update Button */
        .btn-primary {
            background-color: #007bff;
            border: none;
            cursor: not-allowed;
        }

        .btn-primary:disabled {
            background-color: #cccccc;
        }
    </style>
</head>
<body>
<div class="page-container">
    <div class="left-content">
        <div class="mother-grid-inner">
            <?php include('includes/header.php'); ?>
            <div class="clearfix"></div>
        </div>
        
       

        <div class="grid-form">
            <div class="grid-form1">
                <h3>ডিটেলস - স্মার্ট জাতীয় পরিচয়পত্র মুদ্রণ এবং বিতরণ</h3>
                <?php if ($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?></div>
                <?php } ?>

                <form class="form-horizontal" name="view_smart_nid_form" method="post">
                    <!-- Category Field -->
                    <div class="form-group">
                        <label for="category" class="col-sm-2 control-label">বিবরণ</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="category" id="category" 
                                value="<?php echo htmlentities($parentRecord['category']); ?>" readonly>
                        </div>
                    </div>

                    <!-- Subcategory Section -->
                    <?php foreach ($subCategories as $index => $subCategory) { ?>
                        <div class="form-group">
                            <label for="sub_category" class="col-sm-2 control-label">সাব ক্যাটাগরী</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="sub_category[]" 
                                    value="<?php echo htmlentities($subCategory['sub_category']); ?>" readonly>
                                <input type="hidden" name="sub_category_id[]" value="<?php echo $subCategory['id']; ?>" />
                            </div>
                        </div>

                        <!-- Additional Info and Count -->
                        <?php foreach ($moreDetails as $detail) { 
                            if ($detail['sub_category'] === $subCategory['sub_category']) { ?>
                                <div class="form-group">
                                    <label for="additional_info" class="col-sm-2 control-label">বিস্তারিত তথ্য</label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" name="additional_info_<?php echo $index; ?>[]" readonly><?php echo htmlentities($detail['additional_info']); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="count" class="col-sm-2 control-label">পরিমান</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" name="count_<?php echo $index; ?>[]" 
                                            value="<?php echo htmlentities($detail['count']); ?>" readonly>
                                    </div>
                                </div>
                            <?php }
                        } ?>
                    <?php } ?>

                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-2">
                            <!-- The update button is now hidden and disabled -->
                           
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
