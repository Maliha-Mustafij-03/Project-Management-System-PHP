<?php
ob_start();  // Start output buffering
session_start(); // Start session here, at the very top of this file
error_reporting(E_ALL); // Enable error reporting
ini_set('display_errors', 1); // Display errors on the page

include('includes/config.php');

?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Project Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
   
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    
    
    <style>
/* General body styling */
body {
    font-family: 'Open Sans', sans-serif;
    font-size: 16px;
    color: #333;
    background-color: #f8f9fa;
}

/* Header */
.header {
    background-color: #003d5b;
    color: #ffffff;
    padding: 15px 0;
    text-align: center;
}

.header h1 {
    margin: 0;
    font-size: 36px;
}

/* Navigation links */
.nav-links {
    background-color: #ffffff;
    border-bottom: 1px solid #e1e1e1;
    padding: 10px;
}

.nav-links a {
    color: #003d5b;
    text-decoration: none;
    margin: 0 15px;
    font-weight: bold;
}

.nav-links a:hover {
    text-decoration: underline;
}

/* Carousel */
.carousel-inner {
    height: 30vh; /* Set height to 30% of the viewport height */
}

.carousel-item {
    height: 100%; /* Ensure the carousel item fills the carousel-inner */
}

.carousel-item img {
    width: 100%; /* Full width of the carousel item */
    height: 100%; /* Full height of the carousel item */
    object-fit: cover; /* Ensure the image covers the area without distortion */
}

/* Button styling */
.btn-primary {
    background-color: #003d5b;
    border: none;
    color: #fff;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    text-decoration: none;
}

.btn-primary:hover {
    background-color: #002a45;
}

/* Container and rows */
.container-fluid {
    padding: 20px;
}

.row {
    margin-bottom: 20px;
}

.col-md-3, .col-md-6 {
    margin-bottom: 20px;
}

/* Table styling */
.holiday-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

.holiday-table th, .holiday-table td {
    padding: 10px;
    border: 1px solid #e1e1e1;
}

.holiday-table th {
    background-color: #003d5b;
    color: #ffffff;
}

/* Marquee Styles */
.marquee {
    background-color: #003d5b;
    color: #ffffff;
    padding: 30px;
    overflow: hidden;
    white-space: nowrap;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
    font-size: 25px; /* Adjust font size as needed */
    line-height: 0.5; /* Adjust line height for better readability */
}

.marquee span {
    display: inline-block;
    white-space: nowrap; /* Ensure no line breaks in the marquee */
    position: absolute; /* Make sure it can move left/right */
}

.marquee a {
    color: #ffffff;
    text-decoration: none;
    padding-right: 15px;
}

.marquee a:hover {
    text-decoration: underline;
    color: #ffffff; /* Keep color white on hover */
}

@keyframes scroll-marquee {
    0% {
        transform: translateY(100%);
    }
    100% {
        transform: translateY(-100%);
    }
}

/* Footer */
.footer {
    background-color: #003d5b;
    color: #ffffff;
    padding: 15px 0;
    text-align: center;
}


/* Latest News Section */
.latest-news {
    background-color: #f7f9fc;
    border: 1px solid #e1e1e1;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    height: 800px; /* Adjust height as needed */
    overflow: hidden;
    position: relative;
}

/* The container that holds the actual items */
.latest-news-content {
    overflow: hidden; /* Hide overflow content */
    position: relative;
    height: 800px; /* Adjust as needed */
}

/* Items inside the scrolling container */
.latest-news-items {
    position: absolute;
    top: 0%; /* Start position up the container */
    left: 0;
    width: 100%;
    animation: scroll-up 35s linear infinite; /* Continuous scroll animation */
}

/* Pausing the scroll animation when mouse hovers over the container */
.latest-news:hover .latest-news-items {
    animation-play-state: paused; /* Pause the animation when the mouse hovers */
}

/* Keyframes for the scrolling effect */
@keyframes scroll-up {
    0% {
        top: 0%;
    }
    100% {
        top: -100%; /* Scrolls to the top of the container */
    }
}

/* Latest News Item Styles */
.latest-news-item {
    padding: 18px 0;
    border-bottom: 1px solid #e1e1e1;
    font-weight: bold; /* Default to bold text */
    color: navy; /* Default text color */
    transition: color 0.3s ease, text-decoration 0.3s ease; /* Smooth transition for color and underline */
}

/* Optional: Ensure titles and descriptions are properly styled */
.latest-news-item h5 {
    font-size: 16px; /* Set title font size */
    font-weight: bold; /* Default to bold text */
    line-height: 1.5; /* Set line height for title */
    margin: 0; /* Remove default margin */
}

.latest-news-item p {
    font-size: 16px; /* Set description font size */
    font-weight: bold; /* Default to bold text */
    line-height: 1.5; /* Set line height for description */
    margin: 5px 0 0; /* Add margin for spacing */
}

.latest-news-item a {
    text-decoration: none; /* Remove underline by default */
}

.latest-news-item a:hover {
    color: red;
    text-decoration: underline; /* Underline on hover */
}

        /* Blinking effect with alternating background colors */
.blinking-link {
    position: relative;
    display: inline-block;
    padding: 10px;
    color: #ffffff; /* White text */
    font-weight: bold;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease, color 0.3s ease;
}

.blinking-link.package-overview {
    background-color: #006400; /* Bottle green background */
    color: #ffffff; /* White text */
}

.blinking-link.all-news {
    background-color: #006400; /* Bottle green background */
    color: #ffffff; /* White text */
}

.blinking-link.package-overview:hover {
    background-color: #006400; /* Maintain bottle green background */
    color: #ffffff; /* Maintain white text */
}

.blinking-link.all-news:hover {
    background-color: #006400; /* Maintain bottle green background */
    color: #ffffff; /* Maintain white text */
}

.blinking-link:hover {
    /* Stop blinking on hover */
    animation: none;
}

/* Package Overview Section */
.package-overview {
    background-color: #cce4f6; 
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 5px;
    color: #ffffff; /* White text */
}

.package-overview:hover {
    background-color: #cce4f6;
}

.package-overview h3 {
    margin-top: 0;
    color: #ffffff; /* White text for heading */
    font-weight: bold;
    font-size: 22px;
}

/* Hot Balloon Section */
.hot-balloon {
    background-color: #d4edda; /* Light green background color */
    color: #00000000; /* White text for heading */
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.wall {
    background-color: #000000; /* Black background */
    color: #ffffff; /* White text */
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input {
            width: calc(100% - 120px);
            padding: 10px;
            font-size: 16px;
        }

        .search-container button {
            width: 100px;
            padding: 10px;
            background-color: #003d5b;
            border: none;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .search-container button:hover {
            background-color: #002a45;
        }
         /* Pagination Styling */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            font-size: 16px;
            font-weight: bold;
            margin: 0 5px;
            text-decoration: none;
            padding: 10px 15px;
            background-color: #003d5b;
            color: white;
            border-radius: 5px;
        }
        .pagination a.active {
            background-color: #006400;
            color: white;
        }
        .pagination a:hover {
            background-color: #002a45;
        }
        .blinking-link {
    position: relative;
    display: inline-block;
    padding: 10px;
    color: #FFFF00; /* Yellow text color */
    font-weight: bold;
    text-decoration: none;
    border-radius: 5px;
    background-color: #006400; /* Bottle green background color */
    transition: background-color 0.3s ease, color 0.3s ease;
    animation: blink 1s infinite alternate; /* Make it blink */
}

.blinking-link:hover {
    animation: none; /* Stop blinking on hover */
    background-color: #006400; /* Maintain bottle green background */
    color: #FFFF00; /* Maintain yellow text */
}

/* Blink animation */
@keyframes blink {
    0% {
        opacity: 0.7; /* Slightly faded at 0% */
    }
    100% {
        opacity: 1; /* Fully opaque at 100% */
    }
}




    </style>
</head>
<body>
    <!-- Your HTML content here -->
</body>
</html>

   <?php include('includes/header.php'); ?>

        

<div class="marquee">
    <span>
        <?php 
            try {
              // Modify the SQL query to include sorting and the liveorclose condition
    $sql = "SELECT PackageId, Details FROM tbltenderpackages 
            WHERE liveorclose = 'চলমান' 
            ORDER BY PackageId ASC"; // Change 'PackageId' to any column you want to sort by (e.g., 'Details')
                $query = $dbh->prepare($sql);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                if ($query->rowCount() > 0) {
                    foreach ($results as $result) {
                        echo '<a href="print.php?pkgid=' . htmlentities($result->PackageId) . '">' . htmlentities($result->Details) . '</a> &bull; ';
                    }
                } else {
                    echo 'No packages found.';
                }
            } catch (PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
        ?>
    </span>
</div>

<script>

$(document).ready(function() {
    const marquee = $('.marquee span');
    const parentWidth = $('.marquee').width();  // Width of the parent container (the viewport)
    const padding = parseInt($('.marquee').css('padding-left')) + parseInt($('.marquee').css('padding-right'));  // Total padding

    // Function to animate the marquee
    function animateMarquee() {
        const marqueeWidth = marquee.outerWidth() + padding;  // Total width including padding
        const animationDuration = marqueeWidth * 10;  // Speed calculation based on width (adjust multiplier for speed)

        // Start the animation with the marquee positioned outside to the right
        marquee.css({ left: parentWidth });

        // Animate marquee from right to left
        marquee.animate({ left: -marqueeWidth }, animationDuration, 'linear', function() {
            // After the animation is complete, reset position to the right and restart animation
            marquee.css({ left: parentWidth });
            animateMarquee();  // Call the function recursively for a continuous loop
        });
    }

    animateMarquee();  // Start the marquee animation when the document is ready
});



    $(document).ready(function() {
    const newsContainer = $('.latest-news-items');
    const newsItemHeight = $('.latest-news-item').outerHeight();
    const totalNewsHeight = $('.latest-news-item').length * newsItemHeight;

    // Set the height of the news container based on total news items
    newsContainer.css({ height: totalNewsHeight });

    // Function to animate the latest news
    function animateNews() {
        newsContainer.animate({ top: -totalNewsHeight }, {
            duration: totalNewsHeight * 50, // Adjust speed based on total height
            easing: 'linear',
            complete: function() {
                // Reset position for next loop
                newsContainer.css({ top: '50%' });
                animateNews(); // Loop the animation
            }
        });
    }

    animateNews(); // Start the animation
});

</script>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item active">
            <h1 class="wow zoomIn animated" data-wow-delay=".5s" style="text-align: center;">Welcome to Project Management System</h1>
            <img src="images/slider1.jpg" alt="Banner 1">
        </div></div>
      <!-- Blinking Reminder for Specification Forwarding Date -->
    <div class="package-overview hot-balloon" style="margin-top: 10px;">
        <h3 style="color: #006400;">Reminder</h3>
        <ul>
        <?php
        try {
            // Get today's date, tomorrow's date, and the day after tomorrow's date
            $today = date('Y-m-d');
            $nextDay = date('Y-m-d', strtotime('+1 day'));
            $nextNextDay = date('Y-m-d', strtotime('+2 days'));

            // SQL query to fetch packages
            $sql = "SELECT PackageId, PackageNo, Details FROM tbltenderpackages ORDER BY PackageId ASC";
            $query = $dbh->prepare($sql);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);

            if ($query->rowCount() > 0) {
                foreach ($results as $result) {
                    // Fetch package details for each package
                    $sqlDetails = "SELECT Detail, DetailPart2, Status, ActualCompletedDate FROM tblpackagedetails WHERE PackageId = :pid";
                    $queryDetails = $dbh->prepare($sqlDetails);
                    $queryDetails->bindParam(':pid', $result->PackageId, PDO::PARAM_INT);
                    $queryDetails->execute();
                    $details = $queryDetails->fetch(PDO::FETCH_ASSOC);

                    // Initialize reminder date to 'Not Available' or any default
                    $reminderDate = 'Not Available';

                    // If ActualCompletedDate exists and is after DetailPart2, update the reminder date
                    if (isset($details['ActualCompletedDate']) && strtotime($details['ActualCompletedDate']) > strtotime($details['DetailPart2'])) {
                        $reminderDate = $details['ActualCompletedDate'];
                    }

                    // Check if reminderDate is today, tomorrow, or the day after tomorrow
                    if ($reminderDate !== 'Not Available' && in_array($reminderDate, [$today, $nextDay, $nextNextDay])) {
                        // Output each matching package as a reminder if the reminder date matches
                        echo '<li><a href="print.php?pkgid=' . htmlentities($result->PackageId) . '" class="blinking-link">' 
                             . htmlentities($result->PackageNo) . ' - ' . htmlentities($result->Details) . ' (Reminder Date: ' 
                             . htmlentities($reminderDate) . ')</a></li>';
                    }
                }
            } else {
                echo '<li>No upcoming packages with reminders.</li>';
            }
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
        ?>
    </ul>
</div>

    </ul>
</div>

    </ul>
</div>

    </ul>
</div>

    </ul>
</div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <div class="package-overview hot-balloon">
               
                <ul>
                    
                    <li><a href="viewprobas.php"class="blinking-link package-overview">Expatriate NID Services</a></li>
                    
                    <li><a href="viewstatefront.php"class="blinking-link package-overview">Smart Card Statistics</a></li>
                    <li><a href="viewasset.php"class="blinking-link package-overview">Asset Inventory Module</a></li>
                    <li><a href="viewadmin.php"class="blinking-link package-overview">Admin Module</a></li>
                    <li><a href="viewtrainingtotal.php"class="blinking-link package-overview">Training Module</a></li>
                    <li><a href="Report.php"class="blinking-link package-overview">Financial Report</a></li>
                    <li><a href="schedule.php" class="blinking-link all-news">Schedule an Event</a></li>
                    
                    
                </ul>
            </div>
            
            
        </div>
        <div class="col-md-6">
    <div class="holiday">
        <h3><strong style="color: #006400; font-size: 24px;">NCS/GD Tender Packages</strong></h3>
        <!-- Search form -->
        <div class="search-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Packages" value="<?php echo isset($_GET['search']) ? htmlentities($_GET['search']) : ''; ?>">
                <button type="submit">Search</button>
            </form>

        </div>
        <!-- Package table -->
        <table class="holiday-table">
            <thead>
                <tr>
                    <th>Package No</th>
                    <th>Details</th>
                    <th>Contract Agreement Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
    try {
        // Get current page or default to 1
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $recordsPerPage = 8;
        $offset = ($page - 1) * $recordsPerPage;

        // Search parameter
        $search = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '%';

        // SQL query to select records with LIMIT and OFFSET for pagination
        $sql = "SELECT PackageId, PackageNo, Details, SpecificationForwardingDate, PurchaseMethodType, EstimatedExpenditure, ResponsiblePerson, Consultant, liveorclose 
                FROM tbltenderpackages
                WHERE PackageNo LIKE :search 
                   OR Details LIKE :search 
                   OR PackageId LIKE :search
                   OR SpecificationForwardingDate LIKE :search
                   OR PurchaseMethodType LIKE :search
                   OR EstimatedExpenditure LIKE :search
                   OR ResponsiblePerson LIKE :search
                   OR Consultant LIKE :search
                   OR liveorclose LIKE :search
                ORDER BY PackageId ASC  /* Change this line for ascending order */
                LIMIT :offset, :recordsPerPage";
        
        $query = $dbh->prepare($sql);
        $query->bindValue(':search', $search, PDO::PARAM_STR);
        $query->bindValue(':offset', $offset, PDO::PARAM_INT);
        $query->bindValue(':recordsPerPage', $recordsPerPage, PDO::PARAM_INT);
        $query->execute();

        $results = $query->fetchAll(PDO::FETCH_OBJ);

        if ($query->rowCount() > 0) {
            foreach ($results as $result) {
                ?>
                <tr>
                    <td><?php echo htmlentities($result->PackageNo); ?></td>
                    <td><?php echo htmlentities($result->Details); ?></td>
                    <td><?php echo htmlentities($result->SpecificationForwardingDate); ?></td>
                    <td><a href="print.php?pkgid=<?php echo htmlentities($result->PackageId); ?>" class="btn-btn-primary">View</a></td>
                </tr>
                <?php
            }
        } else {
            echo '<tr><td colspan="4">No records found.</td></tr>';
        }

        // Get total number of records to calculate total pages
        $countQuery = $dbh->prepare("SELECT COUNT(*) FROM tbltenderpackages
            WHERE PackageNo LIKE :search 
            OR Details LIKE :search 
            OR PackageId LIKE :search
            OR SpecificationForwardingDate LIKE :search
            OR PurchaseMethodType LIKE :search
            OR EstimatedExpenditure LIKE :search
            OR ResponsiblePerson LIKE :search
            OR Consultant LIKE :search
            OR liveorclose LIKE :search");
        $countQuery->bindValue(':search', $search, PDO::PARAM_STR);
        $countQuery->execute();
        $totalRecords = $countQuery->fetchColumn();
        $totalPages = ceil($totalRecords / $recordsPerPage);

    } catch (PDOException $e) {
        echo '<tr><td colspan="4">Error: ' . $e->getMessage() . '</td></tr>';
    }
?>
</tbody>
</table>

<!-- Pagination Links -->
<div class="pagination">
    <?php if ($page > 1) { ?>
        <a href="?page=1">First</a>
        <a href="?page=<?php echo $page - 1; ?>">Prev</a>
    <?php } ?>

    <!-- Loop through pages -->
    <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
        <a href="?page=<?php echo $i; ?>" 
            <?php if ($i == $page) echo 'class="active"'; ?>>
            <?php echo $i; ?>
        </a>
    <?php } ?>

    <?php if ($page < $totalPages) { ?>
        <a href="?page=<?php echo $page + 1; ?>">Next</a>
        <a href="?page=<?php echo $totalPages; ?>">Last</a>
    <?php } ?>
</div></div></div>



        <div class="col-md-3">
    <h3><strong style="color: #006400;">PD Sir's Today's Commitment</strong></h3>
    <div class="latest-news">
        <h4></h4>
        <div class="latest-news-content">
            <div class="latest-news-items">
                <?php 
                try {
                    // SQL query to fetch today's news based on 'created_at' timestamp field
                    $sql = "SELECT id, title, description FROM urgent_news WHERE DATE(created_at) = CURDATE() ORDER BY created_at DESC";
                    $query = $dbh->prepare($sql);
                    $query->execute();
                    $results = $query->fetchAll(PDO::FETCH_OBJ);

                    // Check if any news is found
                    if ($query->rowCount() > 0) {
                        foreach ($results as $result) {
                            ?>
                            <div class="latest-news-item">
                                <a href="news-details.php?id=<?php echo htmlentities($result->id); ?>">
                                    <h5><?php echo htmlentities($result->title); ?></h5>
                                    <p><?php echo htmlentities($result->description); ?></p>
                                </a>
                            </div>
                            <?php 
                        }
                    } else {
                        echo '<div class="latest-news-item">No Commitment Entried Today.</div>';
                    }
                } catch (PDOException $e) {
                    echo 'Error: ' . $e->getMessage();
                }
                ?>
            </div>
    </div>
</div>

        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#myCarousel').carousel({
        interval: 2000 // Set the interval for auto-slide (in milliseconds)
    });
});
</script>


</div>

 <!--- /rooms ---->
    <!-- footer-top -->
    <?php include('includes/footer.php');?>
    <!-- signup -->
    <?php include('includes/signup.php');?>            
    <!-- signin -->
    <?php include('includes/signin.php');?>            
    <!-- write us -->
    <?php include('includes/write-us.php');?>
</body>
