$(document).ready(function() {
    $('.book').click(function() {
        $(this).toggleClass('flipped');
    });
});
