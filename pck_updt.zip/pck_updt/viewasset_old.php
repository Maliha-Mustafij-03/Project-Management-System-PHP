<?php 
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/header.php');

// Check if user is logged in
if (strlen($_SESSION['alogin']) == 0 && strlen($_SESSION['userlogin']) == 0) {    
    header('location:index.php');
    exit;
}

// Delete functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM tblassets WHERE AssetID = :delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    $msg = "Asset Deleted Successfully";
}

// Search functionality
$search = "";
if (isset($_POST['search'])) {
    $search = $_POST['search_query'];
    $sql = "SELECT * FROM tblassets WHERE 
                SLNumber LIKE :search_query OR 
                OfficeName LIKE :search_query OR 
                OfficeDivision LIKE :search_query OR 
                OfficeZilla LIKE :search_query OR 
                ItemName LIKE :search_query OR 
                VendorName LIKE :search_query OR 
                BrandName LIKE :search_query OR 
                DeliveredQuantity LIKE :search_query OR 
                CurrentQuantity LIKE :search_query OR 
                Condition1 LIKE :search_query OR 
                Condition2 LIKE :search_query OR 
                ReceivedBy LIKE :search_query OR 
                Position LIKE :search_query OR 
                ConditionDate LIKE :search_query";
    $query = $dbh->prepare($sql);
    $query->bindValue(':search_query', '%' . $search . '%');
    $query->execute();
} else {
    // Fetch all assets from the database if no search is done
    $sql = "SELECT * FROM tblassets";
    $query = $dbh->prepare($sql);
    $query->execute();
}

$assets = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCS | Manage Assets</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <style>
        /* Global Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f6f9;
            color: #333;
            font-size: 16px;
            margin: 0;
            padding: 0;
        }

        h1 {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            background-color: #007bff;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            position: relative;
            top: 0;
        }

        /* Search Bar */
        .search-bar {
            text-align: center;
            margin-bottom: 30px;
        }

        .search-bar input[type="text"] {
            padding: 12px 20px;
            font-size: 16px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }

        .search-bar button {
            font-size: 16px;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #218838;
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            font-size: 16px;
        }

        .table th, .table td {
            padding: 12px;
            text-align: center;
            vertical-align: middle;
            border: 1px solid #ddd;
        }

        .table th {
            background-color: #007bff;
            color: white;
            font-weight: 700;
        }

        .table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tr:hover {
            background-color: #f1f1f1;
        }

        /* Action Buttons */
        .action-buttons a {
            font-size: 16px;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin: 0 5px;
            color: #fff;
            transition: all 0.3s ease;
        }

        .action-buttons a.btn-warning {
            background-color: #ffc107;
        }

        .action-buttons a.btn-danger {
            background-color: #dc3545;
        }

        .action-buttons a:hover {
            opacity: 0.8;
        }

        .alert {
            font-size: 18px;
            color: #28a745;
            text-align: center;
            margin-bottom: 20px;
        }

        .btn-custom {
            font-size: 18px;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .search-bar input[type="text"] {
                width: 100%;
                margin-bottom: 10px;
            }

            .search-bar button {
                width: 100%;
            }

            .table {
                font-size: 14px;
            }

            .table th, .table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>এ্যাসেট ম্যানেজমেন্ট</h1>

        <!-- Search Form -->
        <div class="search-bar">
            <form method="POST" class="form-inline">
                <input type="text" name="search_query" class="form-control" value="<?php echo htmlentities($search); ?>" placeholder="Search by any data">
                <button type="submit" name="search" class="btn btn-primary ml-2 btn-custom">Search</button>
            </form>
        </div>

        <?php if(isset($msg)) { ?>
            <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
        <?php } ?>

        <!-- Assets Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ক্রম নং</th>
                        <th>অফিসের নাম</th>
                        <th>অফিসের বিভাগের নাম</th>
                        <th>অফিসের জেলা</th>
                        <th>আইটেমের নাম</th>
                        <th>ভেন্ডরের নাম</th>
                        <th>ব্র্যান্ডের নাম</th>
                        <th>ডেলিভারী পরিমাণ</th>
                        <th>বর্তমান পরিমাণ</th>
                      
                        <th>পরিমাণ(ভালো)</th>
                       
                        <th>পরিমাণ(নষ্ট)</th>
                        <th>গ্রহণকারী</th>
                        <th>পদবী</th>
                        <th>গ্রহনের তারিখ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($assets as $asset) { ?>
                        <tr>
                            <td><?php echo htmlentities($asset['SLNumber']); ?></td>
                            <td><?php echo htmlentities($asset['OfficeName']); ?></td>
                            <td><?php echo htmlentities($asset['OfficeDivision']); ?></td>
                            <td><?php echo htmlentities($asset['OfficeZilla']); ?></td>
                            <td><?php echo htmlentities($asset['ItemName']); ?></td>
                            <td><?php echo htmlentities($asset['VendorName']); ?></td>
                            <td><?php echo htmlentities($asset['BrandName']); ?></td>
                            <td><?php echo htmlentities($asset['DeliveredQuantity']); ?></td>
                            <td><?php echo htmlentities($asset['CurrentQuantity']); ?></td>
                            <!-- <td><?php echo htmlentities($asset['Condition1']); ?></td> -->
                            <td><?php echo htmlentities($asset['Quantity1']); ?></td>
                            <!-- <td><?php echo htmlentities($asset['Condition2']); ?></td> -->
                            <td><?php echo htmlentities($asset['Quantity2']); ?></td>
                            <td><?php echo htmlentities($asset['ReceivedBy']); ?></td>
                            <td><?php echo htmlentities($asset['Position']); ?></td>
                            <td><?php echo htmlentities($asset['ConditionDate']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
